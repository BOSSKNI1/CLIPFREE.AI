package com.example.video

import android.content.Context
import android.net.Uri
import com.example.data.local.GeneratedClipEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.TranscriptSegmentEntity
import com.example.data.model.AspectRatioOption
import com.example.data.model.CaptionStyleConfig
import com.example.data.model.ClipEditTimeline
import com.example.data.model.DeviceCapabilities
import com.example.data.model.ExportResolution
import java.util.Locale

enum class CheckSeverity { ERROR, WARNING }

data class QualityCheckIssue(
    val severity: CheckSeverity,
    val title: String,
    val detail: String,
    val suggestedFix: String
)

object ExportQualityChecker {

    fun runChecks(
        context: Context,
        project: ProjectEntity,
        clip: GeneratedClipEntity,
        timeline: ClipEditTimeline,
        captionStyle: CaptionStyleConfig,
        resolution: ExportResolution,
        transcript: List<TranscriptSegmentEntity>,
        deviceCaps: DeviceCapabilities
    ): List<QualityCheckIssue> {
        val issues = mutableListOf<QualityCheckIssue>()

        if (!VideoInspector.isUriAccessible(context, project.sourceUri)) {
            issues.add(
                QualityCheckIssue(
                    severity = CheckSeverity.ERROR,
                    title = "Missing source video",
                    detail = "The original video URI can no longer be read.",
                    suggestedFix = "Open Projects and relink the original source video."
                )
            )
        }

        val effectiveDurationMs = (timeline.trimEndMs.takeIf { it > 0L } ?: clip.endMs) -
            timeline.trimStartMs.coerceAtLeast(clip.startMs)
        if (effectiveDurationMs < 1000L) {
            issues.add(
                QualityCheckIssue(
                    severity = CheckSeverity.ERROR,
                    title = "Invalid clip duration",
                    detail = "Trimmed clip duration must be at least 1.0 second.",
                    suggestedFix = "Widen the trim handles on the timeline."
                )
            )
        }

        if (resolution == ExportResolution.RES_4K &&
            (!deviceCaps.supports4kEncode || maxOf(project.width, project.height) < 2160)
        ) {
            issues.add(
                QualityCheckIssue(
                    severity = CheckSeverity.WARNING,
                    title = "4K resolution unsupported",
                    detail = "Either the source video is below 4K or this device lacks a 4K hardware encoder.",
                    suggestedFix = "Switch export resolution to 1080p Full HD."
                )
            )
        }

        if (captionStyle.enabled && (captionStyle.positionYFraction < 0.14f || captionStyle.positionYFraction > 0.88f)) {
            issues.add(
                QualityCheckIssue(
                    severity = CheckSeverity.WARNING,
                    title = "Captions outside social safe zone",
                    detail = "Captions near the top or bottom edge may be covered by TikTok/Reels UI overlays.",
                    suggestedFix = "Move caption vertical position between 20% and 82%."
                )
            )
        }

        if (!project.hasAudio) {
            issues.add(
                QualityCheckIssue(
                    severity = CheckSeverity.WARNING,
                    title = "No source audio track",
                    detail = "The imported video has no audio track.",
                    suggestedFix = "Add background music in the Audio tab if desired."
                )
            )
        } else if (timeline.audioGain > 2.2f) {
            issues.add(
                QualityCheckIssue(
                    severity = CheckSeverity.WARNING,
                    title = "Potential audio clipping",
                    detail = "Audio gain (${String.format(Locale.US, "%.1fx", timeline.audioGain)}) may distort loud peaks.",
                    suggestedFix = "Enable Normalize Audio or keep gain below 1.8x."
                )
            )
        }

        if (timeline.audioGain < 0.2f && timeline.bgmUri == null) {
            issues.add(
                QualityCheckIssue(
                    severity = CheckSeverity.WARNING,
                    title = "Very low audio volume",
                    detail = "Voice volume is below 20% with no background audio.",
                    suggestedFix = "Increase audio gain to 1.0x."
                )
            )
        }

        val activeAspect = AspectRatioOption.fromId(clip.aspectRatio)
        if (project.width > project.height && activeAspect == AspectRatioOption.RATIO_9_16) {
            // Valid reframe, informational check only if crop offset not reviewed
        }

        val clipSegments = transcript.filter { !it.isRemoved && it.endMs > clip.startMs && it.startMs < clip.endMs }
        val hasOverlap = clipSegments.zipWithNext().any { (a, b) -> a.endMs > b.startMs + 150L }
        if (hasOverlap) {
            issues.add(
                QualityCheckIssue(
                    severity = CheckSeverity.WARNING,
                    title = "Overlapping subtitle timestamps",
                    detail = "Two caption segments overlap by more than 150ms.",
                    suggestedFix = "Adjust segment timing in the Captions tab."
                )
            )
        }

        if (deviceCaps.availableStorageBytes < 120L * 1024L * 1024L) {
            issues.add(
                QualityCheckIssue(
                    severity = CheckSeverity.ERROR,
                    title = "Low device storage",
                    detail = "Less than 120 MB free storage remains on device.",
                    suggestedFix = "Clear temporary cache in Profile -> Storage Management."
                )
            )
        }

        return issues
    }
}
