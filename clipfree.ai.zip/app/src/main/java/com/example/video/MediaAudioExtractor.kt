package com.example.video

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import com.example.data.model.TimeRangeMs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.sqrt

object MediaAudioExtractor {

    /**
     * Streams the audio track out of a video URI into a compact M4A file using
     * MediaExtractor + MediaMuxer without loading the full video into memory.
     * Caps output size to stay safely below Gemini 20MB inline media limits.
     */
    suspend fun extractAudioTrackForAi(
        context: Context,
        uri: Uri,
        maxDurationMs: Long = 10 * 60 * 1000L,
        maxBytes: Long = 6_000_000L
    ): File? = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        val outFile = File(context.cacheDir, "ai_audio_${System.currentTimeMillis()}.m4a")
        try {
            extractor.setDataSource(context, uri, null)
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }
            if (audioTrackIndex == -1 || audioFormat == null) return@withContext null

            extractor.selectTrack(audioTrackIndex)
            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerTrackIndex = muxer.addTrack(audioFormat)
            muxer.start()

            val maxSampleSize = if (audioFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtLeast(64 * 1024)
            } else {
                256 * 1024
            }
            val buffer = ByteBuffer.allocate(maxSampleSize)
            val bufferInfo = MediaCodec.BufferInfo()
            var writtenBytes = 0L

            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs > maxDurationMs * 1000L) break
                if (writtenBytes + sampleSize > maxBytes) break

                bufferInfo.offset = 0
                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = sampleTimeUs
                val sampleFlags = extractor.sampleFlags
                var codecFlags = 0
                if (sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) {
                    codecFlags = codecFlags or MediaCodec.BUFFER_FLAG_KEY_FRAME
                }
                if (sampleFlags and MediaExtractor.SAMPLE_FLAG_PARTIAL_FRAME != 0) {
                    codecFlags = codecFlags or MediaCodec.BUFFER_FLAG_PARTIAL_FRAME
                }
                bufferInfo.flags = codecFlags
                muxer.writeSampleData(muxerTrackIndex, buffer, bufferInfo)
                writtenBytes += sampleSize
                extractor.advance()
            }

            muxer.stop()
            if (outFile.exists() && outFile.length() > 0L) outFile else null
        } catch (_: Exception) {
            runCatching { outFile.delete() }
            null
        } finally {
            runCatching { muxer?.release() }
            runCatching { extractor.release() }
        }
    }

    /**
     * Performs genuine local PCM amplitude analysis via MediaExtractor + MediaCodec
     * to detect pauses / silence intervals (>= minSilenceMs) in Local Mode or AI Mode.
     */
    suspend fun detectSilenceRangesLocally(
        context: Context,
        uri: Uri,
        minSilenceMs: Long = 900L,
        rmsThreshold: Double = 320.0
    ): List<TimeRangeMs> = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        val silences = mutableListOf<TimeRangeMs>()
        try {
            extractor.setDataSource(context, uri, null)
            var audioIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    audioIndex = i
                    format = f
                    break
                }
            }
            if (audioIndex == -1 || format == null) return@withContext emptyList()
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return@withContext emptyList()
            extractor.selectTrack(audioIndex)

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var isInputDone = false
            var isOutputDone = false
            var silenceStartMs: Long? = null
            var lastPtsMs = 0L

            while (!isOutputDone) {
                if (!isInputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000L)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx) ?: continue
                        val sampleSize = extractor.readSampleData(inBuf, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(
                                inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            isInputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(info, 10_000L)
                if (outIdx >= 0) {
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        isOutputDone = true
                    }
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && info.size > 0) {
                        val ptsMs = info.presentationTimeUs / 1000L
                        lastPtsMs = ptsMs
                        outBuf.position(info.offset)
                        outBuf.limit(info.offset + info.size)
                        val shortCount = info.size / 2
                        var sumSquares = 0.0
                        for (s in 0 until shortCount) {
                            val sample = outBuf.short.toDouble()
                            sumSquares += sample * sample
                        }
                        val rms = if (shortCount > 0) sqrt(sumSquares / shortCount) else 0.0
                        if (rms < rmsThreshold) {
                            if (silenceStartMs == null) silenceStartMs = ptsMs
                        } else {
                            val start = silenceStartMs
                            if (start != null && ptsMs - start >= minSilenceMs) {
                                silences.add(TimeRangeMs(start, ptsMs, "Detected silence"))
                            }
                            silenceStartMs = null
                        }
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                }
            }

            val trailingStart = silenceStartMs
            if (trailingStart != null && lastPtsMs - trailingStart >= minSilenceMs) {
                silences.add(TimeRangeMs(trailingStart, lastPtsMs, "Trailing silence"))
            }
        } catch (_: Exception) {
            // Gracefully return any detected ranges if codec fails on unusual container
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
        silences
    }
}
