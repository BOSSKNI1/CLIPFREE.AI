package com.example.video

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Log
import androidx.core.content.FileProvider
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Crop
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.data.local.GeneratedClipEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.TranscriptSegmentEntity
import com.example.data.model.AspectRatioOption
import com.example.data.model.CaptionAnimationStyle
import com.example.data.model.CaptionStyleConfig
import com.example.data.model.ClipEditTimeline
import com.example.data.model.ExportResolution
import com.example.data.model.TimeRangeMs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.sin

data class ExportOutcome(
    val outputFile: File,
    val fileSizeBytes: Long,
    val durationMs: Long,
    val mediaStoreUri: Uri? = null
)

object VideoExportEngine {

    private val activeTransformerRef = AtomicReference<Transformer?>(null)

    @androidx.annotation.OptIn(UnstableApi::class)
    fun cancelActiveExport() {
        val mainHandler = Handler(Looper.getMainLooper())
        mainHandler.post {
            activeTransformerRef.getAndSet(null)?.cancel()
        }
    }

    fun computeOutputDimensions(
        aspect: AspectRatioOption,
        resolution: ExportResolution
    ): Pair<Int, Int> {
        val shortSide = resolution.shortSidePx
        return when {
            aspect.widthRatio < aspect.heightRatio -> {
                val h = (shortSide * aspect.heightRatio / aspect.widthRatio)
                shortSide to (h - (h % 2))
            }
            aspect.widthRatio > aspect.heightRatio -> {
                val w = (shortSide * aspect.widthRatio / aspect.heightRatio)
                (w - (w % 2)) to shortSide
            }
            else -> shortSide to shortSide
        }
    }

    fun estimateFileSizeBytes(durationMs: Long, resolution: ExportResolution): Long {
        val bitsPerSec = when (resolution) {
            ExportResolution.RES_720P -> 4_500_000L
            ExportResolution.RES_1080P -> 8_500_000L
            ExportResolution.RES_4K -> 22_000_000L
        }
        return ((durationMs.coerceAtLeast(1000L) / 1000.0) * (bitsPerSec / 8.0)).toLong()
    }

    /**
     * Computes kept sub-ranges within [clipStartMs..clipEndMs] after subtracting any
     * excluded time ranges (from Text-Based Video Editing or Silence Removal).
     */
    fun computeKeptSegments(
        clipStartMs: Long,
        clipEndMs: Long,
        excludedRanges: List<TimeRangeMs>
    ): List<Pair<Long, Long>> {
        if (clipEndMs <= clipStartMs) return emptyList()
        val sortedExclusions = excludedRanges
            .map { maxOf(clipStartMs, it.startMs) to minOf(clipEndMs, it.endMs) }
            .filter { it.second > it.first }
            .sortedBy { it.first }

        if (sortedExclusions.isEmpty()) return listOf(clipStartMs to clipEndMs)

        val kept = mutableListOf<Pair<Long, Long>>()
        var cursor = clipStartMs
        for ((exStart, exEnd) in sortedExclusions) {
            if (exStart > cursor + 150L) {
                kept.add(cursor to exStart)
            }
            cursor = maxOf(cursor, exEnd)
        }
        if (clipEndMs > cursor + 150L) {
            kept.add(cursor to clipEndMs)
        }
        return if (kept.isEmpty()) listOf(clipStartMs to clipEndMs) else kept
    }

    @androidx.annotation.OptIn(UnstableApi::class)
    suspend fun exportClipToMp4(
        context: Context,
        project: ProjectEntity,
        clip: GeneratedClipEntity,
        timeline: ClipEditTimeline,
        captionStyle: CaptionStyleConfig,
        transcript: List<TranscriptSegmentEntity>,
        resolution: ExportResolution,
        onProgress: (Int) -> Unit
    ): Result<ExportOutcome> = withContext(Dispatchers.Main) {
        val sourceUri = Uri.parse(project.sourceUri)
        if (!VideoInspector.isUriAccessible(context, project.sourceUri)) {
            return@withContext Result.failure(
                IllegalStateException("Source video cannot be accessed. Please relink the video in Projects.")
            )
        }

        val effectiveStartMs = timeline.trimStartMs.takeIf { it >= 0L } ?: clip.startMs
        val effectiveEndMs = timeline.trimEndMs.takeIf { it > effectiveStartMs } ?: clip.endMs
        val keptSegments = computeKeptSegments(effectiveStartMs, effectiveEndMs, timeline.excludedRanges)

        val aspect = AspectRatioOption.fromId(clip.aspectRatio)
        val (outW, outH) = computeOutputDimensions(aspect, resolution)

        val exportDir = File(context.filesDir, "exports").apply { mkdirs() }
        val safeTitle = clip.title.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(32).ifBlank { "clip" }
        val outputFile = File(exportDir, "${safeTitle}_${System.currentTimeMillis()}.mp4")
        if (outputFile.exists()) outputFile.delete()

        val videoEffects = buildVideoEffects(
            outW = outW,
            outH = outH,
            timeline = timeline,
            captionStyle = captionStyle,
            transcript = transcript,
            keptSegments = keptSegments
        )

        val audioProcessors: List<AudioProcessor> = if (
            abs(timeline.audioGain - 1.0f) > 0.05f || timeline.normalizeAudio || timeline.voiceEnhancement
        ) {
            val effectiveGain = when {
                timeline.normalizeAudio -> timeline.audioGain.coerceIn(0.8f, 1.6f)
                timeline.voiceEnhancement -> (timeline.audioGain * 1.25f).coerceAtMost(2.2f)
                else -> timeline.audioGain
            }
            listOf(GainAudioProcessor(effectiveGain))
        } else {
            emptyList()
        }

        val itemEffects = Effects(audioProcessors, videoEffects)
        val editedItems = keptSegments.map { (segStart, segEnd) ->
            val mediaItem = MediaItem.Builder()
                .setUri(sourceUri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(segStart)
                        .setEndPositionMs(segEnd)
                        .build()
                )
                .build()
            EditedMediaItem.Builder(mediaItem)
                .setRemoveAudio(!project.hasAudio || timeline.audioGain <= 0.01f)
                .setEffects(itemEffects)
                .build()
        }

        val mainSequence = EditedMediaItemSequence.withAudioAndVideoFrom(editedItems)
        val sequences = mutableListOf(mainSequence)

        val bgmUriStr = timeline.bgmUri
        if (!bgmUriStr.isNullOrBlank() && VideoInspector.isUriAccessible(context, bgmUriStr)) {
            val bgmGain = if (timeline.bgmDucking) (timeline.bgmVolume * 0.55f) else timeline.bgmVolume
            val bgmItem = EditedMediaItem.Builder(MediaItem.fromUri(Uri.parse(bgmUriStr)))
                .setEffects(Effects(listOf(GainAudioProcessor(bgmGain)), emptyList()))
                .build()
            val bgmSequence = EditedMediaItemSequence.withAudioFrom(listOf(bgmItem))
                .buildUpon()
                .setIsLooping(true)
                .build()
            sequences.add(bgmSequence)
        }

        val composition = Composition.Builder(sequences).build()

        val exportResult = suspendCancellableCoroutine<Result<ExportOutcome>> { continuation ->
            val mainHandler = Handler(Looper.getMainLooper())
            val progressHolder = ProgressHolder()
            var finished = false

            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    if (finished) return
                    finished = true
                    activeTransformerRef.set(null)
                    onProgress(100)
                    val validated = validateOutputFile(outputFile)
                    if (validated.isSuccess) {
                        val validDuration = validated.getOrDefault(0L)
                        continuation.resume(
                            Result.success(
                                ExportOutcome(
                                    outputFile = outputFile,
                                    fileSizeBytes = outputFile.length(),
                                    durationMs = validDuration
                                )
                            )
                        )
                    } else {
                        continuation.resume(
                            Result.failure(
                                validated.exceptionOrNull() ?: IllegalStateException("Invalid exported MP4.")
                            )
                        )
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    if (finished) return
                    finished = true
                    activeTransformerRef.set(null)
                    Log.e("VideoExportEngine", "Export failed: ${exportException.errorCodeName}", exportException)
                    runCatching { outputFile.delete() }
                    continuation.resume(Result.failure(exportException))
                }
            }

            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()

            activeTransformerRef.set(transformer)

            continuation.invokeOnCancellation {
                mainHandler.post {
                    activeTransformerRef.getAndSet(null)?.cancel()
                    runCatching { outputFile.delete() }
                }
            }

            try {
                transformer.start(composition, outputFile.absolutePath)
                mainHandler.post(object : Runnable {
                    override fun run() {
                        if (finished) return
                        val state = transformer.getProgress(progressHolder)
                        if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                            onProgress(progressHolder.progress.coerceIn(0, 99))
                        }
                        if (state != Transformer.PROGRESS_STATE_NOT_STARTED && !finished) {
                            mainHandler.postDelayed(this, 350L)
                        }
                    }
                })
            } catch (e: Exception) {
                finished = true
                activeTransformerRef.set(null)
                continuation.resume(Result.failure(e))
            }
        }

        exportResult
    }

    @androidx.annotation.OptIn(UnstableApi::class)
    private fun buildVideoEffects(
        outW: Int,
        outH: Int,
        timeline: ClipEditTimeline,
        captionStyle: CaptionStyleConfig,
        transcript: List<TranscriptSegmentEntity>,
        keptSegments: List<Pair<Long, Long>>
    ): List<Effect> {
        val effects = mutableListOf<Effect>()

        if (timeline.rotationDegrees != 0 || abs(timeline.zoomScale - 1.0f) > 0.02f) {
            effects.add(
                ScaleAndRotateTransformation.Builder()
                    .setRotationDegrees(timeline.rotationDegrees.toFloat())
                    .setScale(timeline.zoomScale, timeline.zoomScale)
                    .build()
            )
        }

        if (abs(timeline.cropOffsetX) > 0.02f || abs(timeline.cropOffsetY) > 0.02f) {
            val panX = timeline.cropOffsetX.coerceIn(-0.4f, 0.4f)
            val panY = timeline.cropOffsetY.coerceIn(-0.4f, 0.4f)
            val left = (-1f + maxOf(0f, panX)).coerceIn(-1f, -0.2f)
            val right = (1f + minOf(0f, panX)).coerceIn(0.2f, 1f)
            val bottom = (-1f + maxOf(0f, panY)).coerceIn(-1f, -0.2f)
            val top = (1f + minOf(0f, panY)).coerceIn(0.2f, 1f)
            effects.add(Crop(left, right, bottom, top))
        }

        if (timeline.autoZoomEnabled && timeline.autoZoomIntensity > 0.01f) {
            val intensity = timeline.autoZoomIntensity.coerceIn(0.02f, 0.25f)
            effects.add(
                MatrixTransformation { presentationTimeUs ->
                    val sec = presentationTimeUs / 1_000_000f
                    val pulse = 1f + intensity * ((sin(sec * 0.9f) + 1f) * 0.5f)
                    Matrix().apply { setScale(pulse, pulse) }
                }
            )
        }

        effects.add(
            Presentation.createForWidthAndHeight(
                outW,
                outH,
                Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
            )
        )

        val needsOverlay = captionStyle.enabled ||
            timeline.textOverlay.isNotBlank() ||
            timeline.watermarkText.isNotBlank() ||
            timeline.introText.isNotBlank() ||
            timeline.outroText.isNotBlank()

        if (needsOverlay) {
            val overlay = DynamicCaptionBitmapOverlay(
                outW = outW,
                outH = outH,
                captionStyle = captionStyle,
                timeline = timeline,
                transcript = transcript.filter { !it.isRemoved },
                keptSegments = keptSegments
            )
            effects.add(OverlayEffect(listOf(overlay)))
        }

        return effects
    }

    private fun validateOutputFile(file: File): Result<Long> {
        if (!file.exists() || file.length() < 1024L) {
            return Result.failure(IllegalStateException("Exported MP4 file is empty or missing."))
        }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val duration = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L
            if (duration <= 0L) {
                Result.failure(IllegalStateException("Exported file failed playback validation."))
            } else {
                Result.success(duration)
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("Export validation error: ${e.localizedMessage}"))
        } finally {
            runCatching { retriever.release() }
        }
    }

    suspend fun saveToDeviceGallery(context: Context, sourceFile: File, title: String): Result<Uri> =
        withContext(Dispatchers.IO) {
            runCatching {
                val displayName = "${title.replace(Regex("[^a-zA-Z0-9_-]"), "_")}_${System.currentTimeMillis()}.mp4"
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/CLIPFREE.AI")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                val resolver = context.contentResolver
                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                }
                val uri = resolver.insert(collection, values)
                    ?: throw IllegalStateException("Could not create MediaStore entry.")

                resolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(sourceFile).use { input ->
                        input.copyTo(out)
                    }
                } ?: throw IllegalStateException("Could not open output stream.")

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                }
                uri
            }
        }

    fun createShareVideoIntent(context: Context, file: File, captionText: String): Intent {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            if (captionText.isNotBlank()) {
                putExtra(Intent.EXTRA_TEXT, captionText)
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun createShareFileIntent(context: Context, file: File, mimeType: String): Intent {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}

@UnstableApi
private class GainAudioProcessor(private val gain: Float) : BaseAudioProcessor() {
    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != androidx.media3.common.C.ENCODING_PCM_16BIT) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val out = replaceOutputBuffer(remaining)
        while (inputBuffer.hasRemaining()) {
            val sample = inputBuffer.short
            val scaled = (sample * gain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            out.putShort(scaled.toShort())
        }
        out.flip()
    }
}

@UnstableApi
private class DynamicCaptionBitmapOverlay(
    private val outW: Int,
    private val outH: Int,
    private val captionStyle: CaptionStyleConfig,
    private val timeline: ClipEditTimeline,
    private val transcript: List<TranscriptSegmentEntity>,
    private val keptSegments: List<Pair<Long, Long>>
) : BitmapOverlay() {

    private val bitmap: Bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
    private val canvas = Canvas(bitmap)
    private var lastRenderedBucket = -1L

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        // Render at ~10fps caption granularity to stay fast on mid-range GPUs
        val bucket = presentationTimeUs / 100_000L
        if (bucket == lastRenderedBucket) return bitmap
        lastRenderedBucket = bucket

        bitmap.eraseColor(Color.TRANSPARENT)
        val outputMs = presentationTimeUs / 1000L
        val originalSourceMs = mapOutputMsToSourceMs(outputMs)
        val totalOutputMs = keptSegments.sumOf { (it.second - it.first).coerceAtLeast(0L) }

        // Watermark
        if (timeline.watermarkText.isNotBlank()) {
            val wmPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(170, 255, 255, 255)
                textSize = outW * 0.032f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                setShadowLayer(4f, 1f, 2f, Color.argb(160, 0, 0, 0))
            }
            canvas.drawText(timeline.watermarkText, outW * 0.06f, outH * 0.065f, wmPaint)
        }

        // Intro / Outro / Persistent Text Overlay
        val activeOverlayText = when {
            timeline.introText.isNotBlank() && outputMs < timeline.introDurationMs.coerceAtLeast(1800L) ->
                timeline.introText
            timeline.outroText.isNotBlank() && totalOutputMs > 2000L &&
                outputMs > totalOutputMs - timeline.outroDurationMs.coerceAtLeast(1800L) ->
                timeline.outroText
            timeline.textOverlay.isNotBlank() -> timeline.textOverlay
            else -> null
        }

        if (!activeOverlayText.isNullOrBlank()) {
            drawBannerText(activeOverlayText, outH * 0.16f, Color.parseColor("#7652E8"), Color.WHITE)
        }

        // Time-synced captions
        if (captionStyle.enabled) {
            val activeSeg = transcript.firstOrNull {
                originalSourceMs in it.startMs..it.endMs
            }
            if (activeSeg != null && activeSeg.text.isNotBlank()) {
                val style = CaptionAnimationStyle.fromId(captionStyle.styleId)
                val displayText = when (style) {
                    CaptionAnimationStyle.WORD_BY_WORD -> {
                        val words = activeSeg.text.trim().split(Regex("\\s+"))
                        val frac = ((originalSourceMs - activeSeg.startMs).toFloat() /
                            (activeSeg.endMs - activeSeg.startMs).coerceAtLeast(1L)).coerceIn(0f, 0.999f)
                        val idx = (frac * words.size).toInt().coerceIn(0, (words.size - 1).coerceAtLeast(0))
                        words.getOrElse(idx) { activeSeg.text }
                    }
                    else -> activeSeg.text.trim()
                }

                val textColor = if (style == CaptionAnimationStyle.SPEAKER_COLORED) {
                    val speakerHex = captionStyle.speakerColors[activeSeg.speakerLabel] ?: captionStyle.textColorHex
                    runCatching { Color.parseColor(speakerHex) }.getOrDefault(Color.WHITE)
                } else {
                    runCatching { Color.parseColor(captionStyle.textColorHex) }.getOrDefault(Color.WHITE)
                }
                val bgBase = runCatching { Color.parseColor(captionStyle.backgroundColorHex) }
                    .getOrDefault(0xFF17151F.toInt())
                val bgAlpha = (captionStyle.backgroundAlpha.coerceIn(0f, 1f) * 255).toInt()
                val bgColor = Color.argb(bgAlpha, Color.red(bgBase), Color.green(bgBase), Color.blue(bgBase))

                val scale = outW / 360f
                val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = textColor
                    textSize = (captionStyle.fontSizeSp * scale).coerceIn(28f, 96f)
                    typeface = Typeface.create(
                        Typeface.DEFAULT,
                        if (style == CaptionAnimationStyle.MINIMAL) Typeface.NORMAL else Typeface.BOLD
                    )
                    setShadowLayer(6f, 0f, 3f, Color.argb(200, 0, 0, 0))
                }
                val maxTextWidth = (outW * 0.84f).toInt().coerceAtLeast(100)
                val layout = StaticLayout.Builder.obtain(
                    displayText, 0, displayText.length, textPaint, maxTextWidth
                )
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setLineSpacing(0f, captionStyle.lineSpacingMultiplier)
                    .build()

                val centerY = outH * captionStyle.positionYFraction.coerceIn(0.15f, 0.88f)
                val topY = (centerY - layout.height / 2f).coerceIn(outH * 0.1f, outH - layout.height - 32f)
                val leftX = (outW - maxTextWidth) / 2f

                if (bgAlpha > 10 && style != CaptionAnimationStyle.MINIMAL) {
                    val padH = 24f
                    val padV = 14f
                    val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bgColor }
                    canvas.drawRoundRect(
                        RectF(leftX - padH, topY - padV, leftX + maxTextWidth + padH, topY + layout.height + padV),
                        24f, 24f, bgPaint
                    )
                }

                canvas.save()
                canvas.translate(leftX, topY)
                layout.draw(canvas)
                canvas.restore()
            }
        }

        return bitmap
    }

    private fun drawBannerText(text: String, topY: Float, bgColor: Int, textColor: Int) {
        val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor
            textSize = outW * 0.045f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val maxW = (outW * 0.8f).toInt().coerceAtLeast(100)
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, textPaint, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .build()
        val left = (outW - maxW) / 2f
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bgColor }
        canvas.drawRoundRect(
            RectF(left - 24f, topY - 14f, left + maxW + 24f, topY + layout.height + 14f),
            20f, 20f, bgPaint
        )
        canvas.save()
        canvas.translate(left, topY)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun mapOutputMsToSourceMs(outputMs: Long): Long {
        var remaining = outputMs
        for ((segStart, segEnd) in keptSegments) {
            val segDur = (segEnd - segStart).coerceAtLeast(0L)
            if (remaining <= segDur) {
                return segStart + remaining
            }
            remaining -= segDur
        }
        return keptSegments.lastOrNull()?.second ?: outputMs
    }
}
