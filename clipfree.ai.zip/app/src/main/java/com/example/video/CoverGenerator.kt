package com.example.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.data.model.AspectRatioOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class CoverLayoutStyle(val label: String) {
    GRADIENT_BOTTOM("Bottom Gradient"),
    CENTER_BADGE("Center Impact Badge"),
    TOP_BANNER("Top Creator Header")
}

object CoverGenerator {

    suspend fun extractFrameBitmap(
        context: Context,
        videoUri: Uri,
        timestampMs: Long
    ): Bitmap? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, videoUri)
            retriever.getFrameAtTime(
                timestampMs.coerceAtLeast(0L) * 1000L,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            )
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    fun renderCoverBitmap(
        frameBitmap: Bitmap,
        title: String,
        subtitle: String,
        aspectRatio: AspectRatioOption,
        layoutStyle: CoverLayoutStyle,
        accentColorHex: String,
        textColorHex: String = "#FFFFFF"
    ): Bitmap {
        val width = aspectRatio.targetWidth1080
        val height = aspectRatio.targetHeight1080
        val out = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)

        // Center-crop source frame to target cover aspect ratio
        val srcRatio = frameBitmap.width.toFloat() / frameBitmap.height.toFloat()
        val dstRatio = width.toFloat() / height.toFloat()
        val drawRect = if (srcRatio > dstRatio) {
            val scaledW = height * srcRatio
            val left = (width - scaledW) / 2f
            RectF(left, 0f, left + scaledW, height.toFloat())
        } else {
            val scaledH = width / srcRatio
            val top = (height - scaledH) / 2f
            RectF(0f, top, width.toFloat(), top + scaledH)
        }
        canvas.drawBitmap(frameBitmap, null, drawRect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))

        val accentColor = runCatching { Color.parseColor(accentColorHex) }.getOrDefault(0xFF7652E8.toInt())
        val textColor = runCatching { Color.parseColor(textColorHex) }.getOrDefault(Color.WHITE)

        when (layoutStyle) {
            CoverLayoutStyle.GRADIENT_BOTTOM -> {
                val grad = Paint().apply {
                    shader = LinearGradient(
                        0f, height * 0.45f, 0f, height.toFloat(),
                        Color.TRANSPARENT, Color.argb(230, 18, 15, 31),
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(0f, height * 0.45f, width.toFloat(), height.toFloat(), grad)
                drawCoverTexts(canvas, title, subtitle, width, height * 0.68f, accentColor, textColor, false)
            }
            CoverLayoutStyle.CENTER_BADGE -> {
                val dimPaint = Paint().apply { color = Color.argb(95, 18, 15, 31) }
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)
                drawCoverTexts(canvas, title, subtitle, width, height * 0.40f, accentColor, textColor, true)
            }
            CoverLayoutStyle.TOP_BANNER -> {
                val bannerPaint = Paint().apply { color = accentColor }
                canvas.drawRoundRect(
                    RectF(48f, 64f, width - 48f, 260f),
                    32f, 32f, bannerPaint
                )
                drawCoverTexts(canvas, title, subtitle, width, 96f, accentColor, textColor, false)
            }
        }
        return out
    }

    private fun drawCoverTexts(
        canvas: Canvas,
        title: String,
        subtitle: String,
        canvasWidth: Int,
        startY: Float,
        accentColor: Int,
        textColor: Int,
        drawPill: Boolean
    ) {
        val horizontalMargin = 72
        val textWidth = (canvasWidth - horizontalMargin * 2).coerceAtLeast(200)
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor
            textSize = 72f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(10f, 0f, 4f, Color.argb(180, 0, 0, 0))
        }
        val titleLayout = StaticLayout.Builder.obtain(
            title.ifBlank { "CLIPFREE.AI" }, 0, title.ifBlank { "CLIPFREE.AI" }.length, titlePaint, textWidth
        ).setAlignment(Layout.Alignment.ALIGN_CENTER).build()

        if (drawPill) {
            val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor }
            val pad = 32f
            canvas.drawRoundRect(
                RectF(
                    horizontalMargin - pad,
                    startY - pad,
                    canvasWidth - horizontalMargin + pad,
                    startY + titleLayout.height + pad
                ),
                36f, 36f, pillPaint
            )
        }

        canvas.save()
        canvas.translate(horizontalMargin.toFloat(), startY)
        titleLayout.draw(canvas)
        canvas.restore()

        if (subtitle.isNotBlank()) {
            val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(230, 235, 230, 255)
                textSize = 40f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            }
            val subLayout = StaticLayout.Builder.obtain(
                subtitle, 0, subtitle.length, subPaint, textWidth
            ).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
            canvas.save()
            canvas.translate(horizontalMargin.toFloat(), startY + titleLayout.height + 24f)
            subLayout.draw(canvas)
            canvas.restore()
        }
    }

    suspend fun saveCoverImage(context: Context, bitmap: Bitmap, title: String): File =
        withContext(Dispatchers.IO) {
            val dir = File(context.filesDir, "covers").apply { mkdirs() }
            val clean = title.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "cover" }
            val file = File(dir, "${clean}_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
            }
            file
        }
}
