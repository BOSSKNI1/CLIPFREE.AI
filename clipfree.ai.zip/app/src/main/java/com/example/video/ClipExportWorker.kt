package com.example.video

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.local.ClipFreeDatabase
import com.example.data.local.ExportStatus
import com.example.data.local.LibraryAssetEntity
import com.example.data.model.CaptionStyleConfig
import com.example.data.model.ClipEditTimeline
import com.example.data.model.ExportResolution
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

class ClipExportWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    private val json = Json { ignoreUnknownKeys = true }

    @OptIn(UnstableApi::class)
    override suspend fun doWork(): Result {
        val clipId = inputData.getLong(KEY_CLIP_ID, -1L)
        val resolutionId = inputData.getString(KEY_RESOLUTION) ?: ExportResolution.RES_1080P.id
        val saveToGallery = inputData.getBoolean(KEY_SAVE_TO_GALLERY, true)
        if (clipId <= 0L) return Result.failure()

        val db = ClipFreeDatabase.getInstance(applicationContext)
        val clip = db.clipDao().getClipById(clipId) ?: return Result.failure()
        val project = db.projectDao().getProjectById(clip.projectId) ?: return Result.failure()
        val transcript = db.transcriptDao().getTranscript(project.id)

        val timeline = runCatching {
            json.decodeFromString<ClipEditTimeline>(clip.editTimelineJson)
        }.getOrDefault(ClipEditTimeline(trimStartMs = clip.startMs, trimEndMs = clip.endMs))

        val captionStyle = runCatching {
            json.decodeFromString<CaptionStyleConfig>(clip.captionStyleJson)
        }.getOrDefault(CaptionStyleConfig())

        db.clipDao().updateClip(
            clip.copy(
                exportStatus = ExportStatus.EXPORTING,
                exportProgress = 0,
                exportError = null,
                updatedAt = System.currentTimeMillis()
            )
        )

        val progressScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        var lastProgress = -1
        var lastDbProgress = -5
        val outcomeResult = try {
            VideoExportEngine.exportClipToMp4(
                context = applicationContext,
                project = project,
                clip = clip,
                timeline = timeline,
                captionStyle = captionStyle,
                transcript = transcript,
                resolution = ExportResolution.fromId(resolutionId),
                onProgress = { pct ->
                    if (pct != lastProgress) {
                        lastProgress = pct
                        setProgressAsync(Data.Builder().putInt(KEY_PROGRESS, pct).build())
                        if (pct - lastDbProgress >= 5 || pct >= 99) {
                            lastDbProgress = pct
                            progressScope.launch {
                                db.clipDao().updateClip(
                                    clip.copy(
                                        exportStatus = ExportStatus.EXPORTING,
                                        exportProgress = pct,
                                        updatedAt = System.currentTimeMillis()
                                    )
                                )
                            }
                        }
                    }
                }
            )
        } finally {
            progressScope.cancel()
        }

        return outcomeResult.fold(
            onSuccess = { outcome ->
                val savedUri = if (saveToGallery) {
                    VideoExportEngine.saveToDeviceGallery(
                        applicationContext,
                        outcome.outputFile,
                        clip.title
                    ).getOrNull()?.toString()
                } else null

                db.clipDao().updateClip(
                    clip.copy(
                        exportedFilePath = outcome.outputFile.absolutePath,
                        exportedUri = savedUri,
                        exportStatus = ExportStatus.COMPLETED,
                        exportProgress = 100,
                        exportError = null,
                        updatedAt = System.currentTimeMillis()
                    )
                )

                db.libraryAssetDao().insert(
                    LibraryAssetEntity(
                        projectId = project.id,
                        assetType = "EXPORTED_VIDEO",
                        title = "${clip.title}.mp4",
                        filePathOrUri = outcome.outputFile.absolutePath,
                        mimeType = "video/mp4",
                        durationMs = outcome.durationMs,
                        sizeBytes = outcome.fileSizeBytes
                    )
                )

                Result.success(
                    Data.Builder()
                        .putString(KEY_OUTPUT_PATH, outcome.outputFile.absolutePath)
                        .build()
                )
            },
            onFailure = { err ->
                val isCancelled = isStopped
                db.clipDao().updateClip(
                    clip.copy(
                        exportStatus = if (isCancelled) ExportStatus.CANCELLED else ExportStatus.FAILED,
                        exportError = if (isCancelled) "Export cancelled by user." else (err.localizedMessage ?: "Export failed."),
                        updatedAt = System.currentTimeMillis()
                    )
                )
                if (isCancelled) Result.success() else Result.failure()
            }
        )
    }

    companion object {
        const val KEY_CLIP_ID = "clip_id"
        const val KEY_RESOLUTION = "resolution"
        const val KEY_SAVE_TO_GALLERY = "save_to_gallery"
        const val KEY_PROGRESS = "progress"
        const val KEY_OUTPUT_PATH = "output_path"

        fun enqueueClipExport(
            context: Context,
            clipId: Long,
            resolution: ExportResolution,
            saveToGallery: Boolean = true
        ) {
            val request = OneTimeWorkRequestBuilder<ClipExportWorker>()
                .setInputData(
                    Data.Builder()
                        .putLong(KEY_CLIP_ID, clipId)
                        .putString(KEY_RESOLUTION, resolution.id)
                        .putBoolean(KEY_SAVE_TO_GALLERY, saveToGallery)
                        .build()
                )
                .addTag("clip_export_$clipId")
                .addTag("clipfree_export_queue")
                .build()

            // Sequential queue policy avoids running too many simultaneous hardware encoders
            WorkManager.getInstance(context).enqueueUniqueWork(
                "clipfree_export_serial",
                ExistingWorkPolicy.APPEND_OR_REPLACE,
                request
            )
        }

        fun cancelClipExport(context: Context, clipId: Long) {
            WorkManager.getInstance(context).cancelAllWorkByTag("clip_export_$clipId")
        }
    }
}
