package com.example.video

import android.content.Context
import com.example.core.TimeUtils
import com.example.data.local.TranscriptSegmentEntity
import java.io.File

enum class SubtitleFormat(val ext: String, val mimeType: String, val label: String) {
    SRT("srt", "application/x-subrip", "SubRip (.srt)"),
    VTT("vtt", "text/vtt", "WebVTT (.vtt)"),
    TXT("txt", "text/plain", "Plain Text (.txt)")
}

object SubtitleExporter {

    fun buildSrt(segments: List<TranscriptSegmentEntity>, offsetStartMs: Long = 0L): String {
        val active = segments.filter { !it.isRemoved }.sortedBy { it.startMs }
        val sb = StringBuilder()
        active.forEachIndexed { idx, seg ->
            val start = (seg.startMs - offsetStartMs).coerceAtLeast(0L)
            val end = (seg.endMs - offsetStartMs).coerceAtLeast(start + 200L)
            sb.append(idx + 1).append('\n')
            sb.append(TimeUtils.formatSrtTimestamp(start))
                .append(" --> ")
                .append(TimeUtils.formatSrtTimestamp(end))
                .append('\n')
            sb.append(seg.text.trim()).append("\n\n")
        }
        return sb.toString().trimEnd()
    }

    fun buildVtt(segments: List<TranscriptSegmentEntity>, offsetStartMs: Long = 0L): String {
        val active = segments.filter { !it.isRemoved }.sortedBy { it.startMs }
        val sb = StringBuilder("WEBVTT\n\n")
        active.forEach { seg ->
            val start = (seg.startMs - offsetStartMs).coerceAtLeast(0L)
            val end = (seg.endMs - offsetStartMs).coerceAtLeast(start + 200L)
            sb.append(TimeUtils.formatVttTimestamp(start))
                .append(" --> ")
                .append(TimeUtils.formatVttTimestamp(end))
                .append('\n')
            sb.append("[${seg.speakerLabel}] ${seg.text.trim()}").append("\n\n")
        }
        return sb.toString().trimEnd()
    }

    fun buildPlainText(segments: List<TranscriptSegmentEntity>): String {
        return segments.filter { !it.isRemoved }
            .sortedBy { it.startMs }
            .joinToString("\n") { seg ->
                "[${TimeUtils.formatDuration(seg.startMs)}] ${seg.speakerLabel}: ${seg.text.trim()}"
            }
    }

    fun parseSrt(srtContent: String, projectId: Long): List<TranscriptSegmentEntity> {
        val blocks = srtContent.trim().split(Regex("\\r?\\n\\r?\\n"))
        val result = mutableListOf<TranscriptSegmentEntity>()
        val timeRegex = Regex("""(\d{2}:\d{2}:\d{2}[,\.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,\.]\d{3})""")
        for (block in blocks) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.size < 2) continue
            val timeLineIdx = lines.indexOfFirst { timeRegex.containsMatchIn(it) }
            if (timeLineIdx == -1) continue
            val match = timeRegex.find(lines[timeLineIdx]) ?: continue
            val startMs = parseTimestampMs(match.groupValues[1])
            val endMs = parseTimestampMs(match.groupValues[2])
            val text = lines.drop(timeLineIdx + 1).joinToString(" ")
            if (text.isNotBlank() && endMs > startMs) {
                result.add(
                    TranscriptSegmentEntity(
                        projectId = projectId,
                        startMs = startMs,
                        endMs = endMs,
                        text = text
                    )
                )
            }
        }
        return result
    }

    fun saveToAppFiles(
        context: Context,
        fileName: String,
        format: SubtitleFormat,
        content: String
    ): File {
        val dir = File(context.filesDir, "subtitles").apply { mkdirs() }
        val cleanName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val file = File(dir, "${cleanName}.${format.ext}")
        file.writeText(content, Charsets.UTF_8)
        return file
    }

    private fun parseTimestampMs(raw: String): Long {
        val normalized = raw.replace(',', '.')
        val parts = normalized.split(':')
        if (parts.size != 3) return 0L
        val h = parts[0].toLongOrNull() ?: 0L
        val m = parts[1].toLongOrNull() ?: 0L
        val secParts = parts[2].split('.')
        val s = secParts.getOrNull(0)?.toLongOrNull() ?: 0L
        val ms = secParts.getOrNull(1)?.toLongOrNull() ?: 0L
        return h * 3_600_000L + m * 60_000L + s * 1000L + ms
    }
}
