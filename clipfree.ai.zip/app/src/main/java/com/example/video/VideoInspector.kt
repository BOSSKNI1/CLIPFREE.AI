package com.example.video

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.OpenableColumns
import com.example.data.model.DeviceCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

data class InspectedVideoMetadata(
    val displayName: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val rotationDegrees: Int,
    val hasAudio: Boolean,
    val fileSizeBytes: Long,
    val thumbnailPath: String?
)

object VideoInspector {

    suspend fun inspectVideo(context: Context, uri: Uri): Result<InspectedVideoMetadata> =
        withContext(Dispatchers.IO) {
            runCatching {
                val displayName = resolveDisplayName(context, uri)
                val fileSize = resolveFileSize(context, uri)
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, uri)
                    val durationMs = retriever.extractMetadata(
                        MediaMetadataRetriever.METADATA_KEY_DURATION
                    )?.toLongOrNull() ?: 0L
                    if (durationMs <= 0L) {
                        throw IllegalArgumentException("Video has invalid or zero duration.")
                    }
                    val rawWidth = retriever.extractMetadata(
                        MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH
                    )?.toIntOrNull() ?: 0
                    val rawHeight = retriever.extractMetadata(
                        MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT
                    )?.toIntOrNull() ?: 0
                    val rotation = retriever.extractMetadata(
                        MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
                    )?.toIntOrNull() ?: 0
                    val hasAudio = retriever.extractMetadata(
                        MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO
                    )?.equals("yes", ignoreCase = true) ?: false

                    if (rawWidth <= 0 || rawHeight <= 0) {
                        throw IllegalArgumentException("Unsupported or corrupt video stream.")
                    }

                    val (width, height) = if (rotation == 90 || rotation == 270) {
                        rawHeight to rawWidth
                    } else {
                        rawWidth to rawHeight
                    }

                    val thumbDir = File(context.filesDir, "thumbnails").apply { mkdirs() }
                    val thumbFile = File(thumbDir, "thumb_${System.currentTimeMillis()}.jpg")
                    val frameTimeUs = min(durationMs * 1000L / 5L, 2_000_000L)
                    val frame = retriever.getFrameAtTime(
                        frameTimeUs,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                    )
                    val thumbPath = if (frame != null) {
                        val scaled = scaleBitmapMaxDim(frame, 640)
                        FileOutputStream(thumbFile).use { out ->
                            scaled.compress(Bitmap.CompressFormat.JPEG, 85, out)
                        }
                        if (scaled !== frame) scaled.recycle()
                        frame.recycle()
                        thumbFile.absolutePath
                    } else {
                        null
                    }

                    InspectedVideoMetadata(
                        displayName = displayName,
                        durationMs = durationMs,
                        width = width,
                        height = height,
                        rotationDegrees = rotation,
                        hasAudio = hasAudio,
                        fileSizeBytes = fileSize,
                        thumbnailPath = thumbPath
                    )
                } finally {
                    runCatching { retriever.release() }
                }
            }
        }

    suspend fun extractClipThumbnail(
        context: Context,
        uri: Uri,
        timestampMs: Long,
        fileNamePrefix: String = "clip_thumb"
    ): String? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val bitmap = retriever.getFrameAtTime(
                timestampMs.coerceAtLeast(0L) * 1000L,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            ) ?: return@withContext null
            val scaled = scaleBitmapMaxDim(bitmap, 480)
            val dir = File(context.filesDir, "thumbnails").apply { mkdirs() }
            val outFile = File(dir, "${fileNamePrefix}_${System.currentTimeMillis()}.jpg")
            FileOutputStream(outFile).use { out ->
                scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
            }
            if (scaled !== bitmap) scaled.recycle()
            bitmap.recycle()
            outFile.absolutePath
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    suspend fun extractKeyframes(
        context: Context,
        uri: Uri,
        durationMs: Long,
        count: Int = 8,
        maxDimension: Int = 512
    ): List<Pair<Long, Bitmap>> = withContext(Dispatchers.IO) {
        if (durationMs <= 0L || count <= 0) return@withContext emptyList()
        val retriever = MediaMetadataRetriever()
        val frames = mutableListOf<Pair<Long, Bitmap>>()
        try {
            retriever.setDataSource(context, uri)
            val step = durationMs / (count + 1).toFloat()
            for (i in 1..count) {
                val timeMs = (step * i).toLong().coerceIn(0L, durationMs)
                val raw = retriever.getFrameAtTime(
                    timeMs * 1000L,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                )
                if (raw != null) {
                    val scaled = scaleBitmapMaxDim(raw, maxDimension)
                    if (scaled !== raw) raw.recycle()
                    frames.add(timeMs to scaled)
                }
            }
        } catch (_: Exception) {
            // Return whatever valid frames were captured
        } finally {
            runCatching { retriever.release() }
        }
        frames
    }

    fun isUriAccessible(context: Context, uriString: String): Boolean {
        return try {
            val uri = Uri.parse(uriString)
            if (uri.scheme == "file") {
                val path = uri.path ?: return false
                val file = File(path)
                return file.exists() && file.canRead()
            }
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { true } ?: false
        } catch (_: Exception) {
            false
        }
    }

    fun detectDeviceCapabilities(context: Context): DeviceCapabilities {
        var supports4k = false
        var supportsHevc = false
        var maxWidth = 1920
        var maxHeight = 1080

        try {
            val codecList = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            for (info in codecList.codecInfos) {
                if (!info.isEncoder) continue
                for (type in info.supportedTypes) {
                    if (type.equals(MediaFormat.MIMETYPE_VIDEO_AVC, ignoreCase = true) ||
                        type.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, ignoreCase = true)
                    ) {
                        if (type.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, ignoreCase = true)) {
                            supportsHevc = true
                        }
                        val caps = info.getCapabilitiesForType(type)?.videoCapabilities ?: continue
                        val widths = caps.supportedWidths
                        val heights = caps.supportedHeights
                        maxWidth = max(maxWidth, widths.upper)
                        maxHeight = max(maxHeight, heights.upper)
                        if (caps.isSizeSupported(3840, 2160) || caps.isSizeSupported(2160, 3840)) {
                            supports4k = true
                        }
                    }
                }
            }
        } catch (_: Exception) {
            // Keep conservative defaults on restricted environments
        }

        val statFs = StatFs(context.filesDir.absolutePath)
        val availableBytes = statFs.availableBytes

        return DeviceCapabilities(
            supports4kEncode = supports4k,
            supportsHevc = supportsHevc,
            maxSupportedWidth = maxWidth,
            maxSupportedHeight = maxHeight,
            availableStorageBytes = availableBytes
        )
    }

    fun resolveDisplayName(context: Context, uri: Uri): String {
        if (uri.scheme == "content") {
            runCatching {
                context.contentResolver.query(
                    uri,
                    arrayOf(OpenableColumns.DISPLAY_NAME),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) {
                            val name = cursor.getString(idx)
                            if (!name.isNullOrBlank()) return name
                        }
                    }
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "Imported Video"
    }

    fun resolveFileSize(context: Context, uri: Uri): Long {
        if (uri.scheme == "content") {
            runCatching {
                context.contentResolver.query(
                    uri,
                    arrayOf(OpenableColumns.SIZE),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (idx >= 0) return cursor.getLong(idx)
                    }
                }
            }
        }
        return runCatching {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
        }.getOrDefault(0L)
    }

    private fun scaleBitmapMaxDim(source: Bitmap, maxDim: Int): Bitmap {
        val w = source.width
        val h = source.height
        if (w <= maxDim && h <= maxDim) return source
        val scale = min(maxDim.toFloat() / w, maxDim.toFloat() / h)
        val targetW = max(1, (w * scale).toInt())
        val targetH = max(1, (h * scale).toInt())
        return Bitmap.createScaledBitmap(source, targetW, targetH, true)
    }
}
