package com.example

import android.content.Context
import com.example.ai.AiOrchestrator
import com.example.core.PreferencesManager
import com.example.core.SecureVault
import com.example.data.ClipFreeRepository
import com.example.data.cloud.CloudSyncRepository
import com.example.data.local.ClipFreeDatabase
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class ClipFreeAppContainer(context: Context) {
    private val appContext = context.applicationContext
    val database: ClipFreeDatabase by lazy { ClipFreeDatabase.getInstance(appContext) }
    val preferences: PreferencesManager by lazy { PreferencesManager(appContext) }
    val vault: SecureVault by lazy { SecureVault(appContext) }
    val firestoreDb: FirebaseFirestore by lazy {
        if (FirebaseApp.getApps(appContext).isEmpty()) {
            FirebaseApp.initializeApp(appContext)
        }
        FirebaseFirestore.getInstance(appContext.getString(R.string.firestore_database_id))
    }
    val cloudSyncRepository: CloudSyncRepository by lazy {
        CloudSyncRepository(
            db = firestoreDb,
            context = appContext,
            localDb = database,
            preferences = preferences
        )
    }
    val aiOrchestrator: AiOrchestrator by lazy {
        AiOrchestrator(database.aiProviderDao(), vault, preferences)
    }
    val repository: ClipFreeRepository by lazy {
        ClipFreeRepository(
            context = appContext,
            db = database,
            preferences = preferences,
            vault = vault,
            aiOrchestrator = aiOrchestrator,
            cloudSync = cloudSyncRepository
        )
    }

    companion object {
        @Volatile
        private var INSTANCE: ClipFreeAppContainer? = null

        fun get(context: Context): ClipFreeAppContainer {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ClipFreeAppContainer(context).also { INSTANCE = it }
            }
        }
    }
}
