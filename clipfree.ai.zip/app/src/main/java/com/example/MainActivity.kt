package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.AddCircleOutline
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.core.AppPreferences
import com.example.core.QuotaMode
import com.example.core.configureAppCheck
import com.example.data.model.AspectRatioOption
import com.example.data.model.DurationPreset
import com.example.data.model.SocialPlatform
import com.example.ui.auth.authStateFlow
import com.example.ui.auth.signOutUser
import com.example.ui.components.rememberVideoImportLaunchers
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CreateScreen
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ProjectsScreen
import com.example.ui.theme.ClipFreeTheme
import com.example.ui.viewmodel.CreateAndProjectsViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ProfileUiState
import com.example.video.VideoInspector
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

@Serializable object RouteHome
@Serializable object RouteProjects
@Serializable object RouteCreate
@Serializable object RouteLibrary
@Serializable object RouteProfile
@Serializable data class RouteEditor(val projectId: Long, val clipId: Long? = null)

private data class TopTabItem(
    val route: Any,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val TOP_TABS = listOf(
    TopTabItem(RouteHome, "Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
    TopTabItem(RouteProjects, "Projects", Icons.Filled.Folder, Icons.Outlined.Folder, "nav_projects"),
    TopTabItem(RouteCreate, "Create", Icons.Filled.AddCircle, Icons.Outlined.AddCircleOutline, "nav_create"),
    TopTabItem(RouteLibrary, "Library", Icons.Filled.VideoLibrary, Icons.Outlined.VideoLibrary, "nav_library"),
    TopTabItem(RouteProfile, "Profile", Icons.Filled.Person, Icons.Outlined.Person, "nav_profile")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        // Configure Firebase App Check before Compose UI or ViewModels initialize
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            ClipFreeAuthGate()
        }
    }
}

@Composable
fun ClipFreeAuthGate(auth: FirebaseAuth = Firebase.auth) {
    val context = LocalContext.current
    val appContainer = remember(context) { ClipFreeAppContainer.get(context) }
    val appPreferences by appContainer.preferences.preferencesFlow.collectAsStateWithLifecycle(
        initialValue = AppPreferences()
    )
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    var skipAutoSignIn by remember { mutableStateOf(false) }

    val user = currentUser
    if (user == null) {
        ClipFreeTheme(
            themeMode = appPreferences.themeMode,
            dynamicColor = appPreferences.dynamicColor
        ) {
            AuthScreen(
                skipAutoSignIn = skipAutoSignIn,
                onAuthSuccess = {
                    skipAutoSignIn = false
                }
            )
        }
    } else {
        key(user.uid) {
            ClipFreeAppRoot(
                currentUserId = user.uid,
                currentUser = user,
                onLoggedOut = {
                    skipAutoSignIn = true
                }
            )
        }
    }
}

@Composable
fun ClipFreeAppRoot(
    currentUserId: String,
    currentUser: FirebaseUser? = null,
    onLoggedOut: () -> Unit = {}
) {
    val mainViewModel: MainViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val container = ClipFreeAppContainer.get(app)
                MainViewModel(
                    repository = container.repository,
                    cloudSync = container.cloudSyncRepository,
                    currentUserId = currentUserId,
                    currentUser = currentUser,
                    capabilitiesProvider = { VideoInspector.detectDeviceCapabilities(app) }
                )
            }
        }
    )
    val createViewModel: CreateAndProjectsViewModel = viewModel(
        key = "create_$currentUserId",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val container = ClipFreeAppContainer.get(app)
                CreateAndProjectsViewModel(repository = container.repository)
            }
        }
    )

    val preferences by mainViewModel.preferences.collectAsStateWithLifecycle()
    val projects by mainViewModel.projects.collectAsStateWithLifecycle()
    val allClips by mainViewModel.allClips.collectAsStateWithLifecycle()
    val brandKits by mainViewModel.brandKits.collectAsStateWithLifecycle()
    val templates by mainViewModel.templates.collectAsStateWithLifecycle()
    val providers by mainViewModel.providers.collectAsStateWithLifecycle()
    val libraryAssets by mainViewModel.libraryAssets.collectAsStateWithLifecycle()
    val failoverSnapshot by mainViewModel.failoverSnapshot.collectAsStateWithLifecycle()
    val deviceCapabilities by mainViewModel.deviceCapabilities.collectAsStateWithLifecycle()
    val storageUsage by mainViewModel.storageUsage.collectAsStateWithLifecycle()
    val testingProviderId by mainViewModel.testingProviderId.collectAsStateWithLifecycle()
    val cloudSyncStatus by mainViewModel.cloudSyncStatus.collectAsStateWithLifecycle()
    val userProfileState by mainViewModel.userProfileState.collectAsStateWithLifecycle()
    val autoCreateState by createViewModel.autoCreateState.collectAsStateWithLifecycle()

    val cloudProfile = (userProfileState as? ProfileUiState.Success)?.data
    val displayName = cloudProfile?.displayName?.takeIf { it.isNotBlank() }
        ?: currentUser?.displayName?.takeIf { it.isNotBlank() }
        ?: currentUser?.email?.substringBefore('@')
        ?: "Creator"
    val userEmail = cloudProfile?.email ?: currentUser?.email
    val userPhotoUrl = cloudProfile?.photoUrl ?: currentUser?.photoUrl?.toString()

    val context = LocalContext.current
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    var isLoggingOut by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        mainViewModel.toastMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    ClipFreeTheme(
        themeMode = preferences.themeMode,
        dynamicColor = preferences.dynamicColor
    ) {
        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentDestination = navBackStackEntry?.destination
        val isEditorScreen = currentDestination?.hasRoute<RouteEditor>() == true

        fun navigateTopTab(route: Any) {
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        }

        val (launchSafFromHome, _) = rememberVideoImportLaunchers { uri ->
            createViewModel.importVideoUri(
                uri = uri,
                aspectRatio = AspectRatioOption.fromId(preferences.defaultAspectRatio),
                platform = SocialPlatform.YOUTUBE_SHORTS,
                durationPreset = DurationPreset.fromId(preferences.defaultDurationPreset)
            )
            navigateTopTab(RouteCreate)
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp && !isEditorScreen

            Scaffold(
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!isEditorScreen && !useRail) {
                        NavigationBar {
                            TOP_TABS.forEach { tab ->
                                val selected = when (tab.route) {
                                    RouteHome -> currentDestination?.hasRoute<RouteHome>() == true
                                    RouteProjects -> currentDestination?.hasRoute<RouteProjects>() == true
                                    RouteCreate -> currentDestination?.hasRoute<RouteCreate>() == true
                                    RouteLibrary -> currentDestination?.hasRoute<RouteLibrary>() == true
                                    RouteProfile -> currentDestination?.hasRoute<RouteProfile>() == true
                                    else -> false
                                }
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTopTab(tab.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail) {
                        NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
                            TOP_TABS.forEach { tab ->
                                val selected = when (tab.route) {
                                    RouteHome -> currentDestination?.hasRoute<RouteHome>() == true
                                    RouteProjects -> currentDestination?.hasRoute<RouteProjects>() == true
                                    RouteCreate -> currentDestination?.hasRoute<RouteCreate>() == true
                                    RouteLibrary -> currentDestination?.hasRoute<RouteLibrary>() == true
                                    RouteProfile -> currentDestination?.hasRoute<RouteProfile>() == true
                                    else -> false
                                }
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTopTab(tab.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = RouteHome,
                        modifier = Modifier.weight(1f)
                    ) {
                        composable<RouteHome> {
                            HomeScreen(
                                projects = projects,
                                recentClips = allClips,
                                failoverSnapshot = failoverSnapshot,
                                onImportVideoClick = launchSafFromHome,
                                onAutoCreateClick = { navigateTopTab(RouteCreate) },
                                onOpenProject = { projId ->
                                    val proj = projects.firstOrNull { it.id == projId }
                                    val hasClips = allClips.any { it.projectId == projId }
                                    if (proj != null && !hasClips) {
                                        createViewModel.selectExistingProjectForCreate(proj)
                                        navigateTopTab(RouteCreate)
                                    } else {
                                        navController.navigate(RouteEditor(projectId = projId))
                                    }
                                },
                                onOpenClipEditor = { projId, clipId ->
                                    navController.navigate(RouteEditor(projectId = projId, clipId = clipId))
                                },
                                onOpenProfileProviders = { navigateTopTab(RouteProfile) },
                                onSwitchLocalMode = { mainViewModel.setQuotaMode(QuotaMode.LOCAL_MODE) },
                                onViewAllProjects = { navigateTopTab(RouteProjects) }
                            )
                        }

                        composable<RouteProjects> {
                            ProjectsScreen(
                                projects = projects,
                                allClips = allClips,
                                onCreateNewProject = { navigateTopTab(RouteCreate) },
                                onOpenProject = { projId ->
                                    navController.navigate(RouteEditor(projectId = projId))
                                },
                                onResumeInCreate = { proj ->
                                    createViewModel.selectExistingProjectForCreate(proj)
                                    navigateTopTab(RouteCreate)
                                },
                                onRenameProject = { proj, name -> createViewModel.renameProject(proj, name) },
                                onDuplicateProject = { proj -> createViewModel.duplicateProject(proj) },
                                onDeleteProject = { id -> createViewModel.deleteProject(id) },
                                onRelinkSource = { id, uri -> createViewModel.relinkSource(id, uri) }
                            )
                        }

                        composable<RouteCreate> {
                            CreateScreen(
                                uiState = autoCreateState,
                                preferences = preferences,
                                failoverSnapshot = failoverSnapshot,
                                templates = templates,
                                onImportVideo = { uri, aspect, plat, dur, capStyle ->
                                    createViewModel.importVideoUri(uri, aspect, plat, dur, capStyle)
                                },
                                onStartAutoCreate = { proj, minS, maxS, aspect, plat, capStyle, lang ->
                                    createViewModel.startAutoCreate(proj, minS, maxS, aspect, plat, capStyle, lang)
                                },
                                onCancelProcessing = { proj -> createViewModel.cancelProcessing(proj) },
                                onCreateManualClip = { proj, aspect, capStyle ->
                                    createViewModel.createManualLocalClipAndOpen(proj, aspect, capStyle) { pid ->
                                        navController.navigate(RouteEditor(projectId = pid))
                                    }
                                },
                                onOpenGeneratedProject = { pid ->
                                    createViewModel.resetCreateFlow()
                                    navController.navigate(RouteEditor(projectId = pid))
                                },
                                onGrantAiConsent = { mainViewModel.setAiUploadConsent(true) },
                                onResetFlow = { createViewModel.resetCreateFlow() },
                                onOpenProfileProviders = { navigateTopTab(RouteProfile) },
                                onSwitchLocalMode = { mainViewModel.setQuotaMode(QuotaMode.LOCAL_MODE) }
                            )
                        }

                        composable<RouteLibrary> {
                            LibraryScreen(
                                clips = allClips,
                                projects = projects,
                                assets = libraryAssets,
                                brandKits = brandKits,
                                templates = templates,
                                onOpenClipEditor = { projId, clipId ->
                                    navController.navigate(RouteEditor(projectId = projId, clipId = clipId))
                                },
                                onDeleteClip = { id -> mainViewModel.deleteClip(id) },
                                onDeleteAsset = { asset -> mainViewModel.deleteLibraryAsset(asset) },
                                onSaveBrandKit = { kit -> mainViewModel.saveBrandKit(kit) },
                                onDeleteBrandKit = { id -> mainViewModel.deleteBrandKit(id) },
                                onSaveTemplate = { tpl -> mainViewModel.saveCustomTemplate(tpl) },
                                onDeleteTemplate = { id -> mainViewModel.deleteCustomTemplate(id) }
                            )
                        }

                        composable<RouteProfile> {
                            ProfileScreen(
                                preferences = preferences,
                                failoverSnapshot = failoverSnapshot,
                                providers = providers,
                                testingProviderId = testingProviderId,
                                deviceCapabilities = deviceCapabilities,
                                storageUsage = storageUsage,
                                getMaskedKey = { id -> mainViewModel.getMaskedKey(id) },
                                onSetThemeMode = { mainViewModel.setThemeMode(it) },
                                onSetDynamicColor = { mainViewModel.setDynamicColor(it) },
                                onSetLanguage = { mainViewModel.setPreferredLanguage(it) },
                                onSetDefaultResolution = { mainViewModel.setDefaultResolution(it) },
                                onSetDefaultAspect = { mainViewModel.setDefaultAspectRatio(it) },
                                onSetQuotaMode = { mainViewModel.setQuotaMode(it) },
                                onSetAiConsent = { mainViewModel.setAiUploadConsent(it) },
                                onSetAutosave = { mainViewModel.setAutosaveEnabled(it) },
                                onTestProvider = { mainViewModel.testProviderConnection(it) },
                                onSelectActiveProvider = { mainViewModel.selectActiveProvider(it) },
                                onToggleProviderEnabled = { p, en -> mainViewModel.toggleProviderEnabled(p, en) },
                                onMoveProviderPriority = { p, d -> mainViewModel.updateProviderPriority(p, d) },
                                onSaveProvider = { id, type, name, model, url, prio, key ->
                                    mainViewModel.addOrUpdateAiProvider(id, type, name, model, url, prio, key)
                                },
                                onDeleteProvider = { mainViewModel.deleteProvider(it) },
                                onClearAllKeys = { mainViewModel.clearAllStoredKeys() },
                                onClearCache = { mainViewModel.clearCache() },
                                userDisplayName = displayName,
                                userEmail = userEmail,
                                userPhotoUrl = userPhotoUrl,
                                cloudSyncStatus = cloudSyncStatus,
                                isLoggingOut = isLoggingOut,
                                onSyncNow = { mainViewModel.syncNow() },
                                onSignOut = {
                                    isLoggingOut = true
                                    signOutUser(
                                        credentialManager = credentialManager,
                                        scope = coroutineScope,
                                        onBeforeSignOut = {
                                            onLoggedOut()
                                            mainViewModel.prepareSignOut()
                                        },
                                        onSignOutComplete = {
                                            isLoggingOut = false
                                        }
                                    )
                                }
                            )
                        }

                        composable<RouteEditor> { backStackEntry ->
                            val args = backStackEntry.toRoute<RouteEditor>()
                            EditorScreen(
                                projectId = args.projectId,
                                initialClipId = args.clipId,
                                brandKits = brandKits,
                                templates = templates,
                                deviceCapabilities = deviceCapabilities,
                                defaultResolutionId = preferences.defaultResolution,
                                onNavigateBack = { navController.popBackStack() },
                                onShowMessage = { msg ->
                                    coroutineScope.launch { snackbarHostState.showSnackbar(msg) }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
