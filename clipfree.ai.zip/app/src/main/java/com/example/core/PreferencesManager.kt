package com.example.core

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "clipfree_prefs")

enum class QuotaMode(val label: String, val description: String) {
    SMART_AI("Smart AI Mode", "Uses best available configured AI, caches results, and switches on limit."),
    LOCAL_MODE("Local Mode", "100% offline device editing and MP4 export without network AI calls."),
    RETRY_AI("Retry AI Mode", "Retries unfinished AI tasks using preserved project edits when AI is back.")
}

data class AppPreferences(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = false,
    val preferredLanguage: String = "English",
    val defaultResolution: String = "1080p",
    val defaultAspectRatio: String = "9:16",
    val defaultDurationPreset: String = "30-45s",
    val aiUploadConsentGranted: Boolean = false,
    val quotaMode: QuotaMode = QuotaMode.SMART_AI,
    val autosaveEnabled: Boolean = true
)

class PreferencesManager(private val context: Context) {

    val preferencesFlow: Flow<AppPreferences> = context.dataStore.data.map { prefs ->
        AppPreferences(
            themeMode = runCatching {
                ThemeMode.valueOf(prefs[KEY_THEME_MODE] ?: ThemeMode.SYSTEM.name)
            }.getOrDefault(ThemeMode.SYSTEM),
            dynamicColor = prefs[KEY_DYNAMIC_COLOR] ?: false,
            preferredLanguage = prefs[KEY_LANGUAGE] ?: "English",
            defaultResolution = prefs[KEY_DEFAULT_RESOLUTION] ?: "1080p",
            defaultAspectRatio = prefs[KEY_DEFAULT_ASPECT] ?: "9:16",
            defaultDurationPreset = prefs[KEY_DEFAULT_DURATION] ?: "30-45s",
            aiUploadConsentGranted = prefs[KEY_AI_CONSENT] ?: false,
            quotaMode = runCatching {
                QuotaMode.valueOf(prefs[KEY_QUOTA_MODE] ?: QuotaMode.SMART_AI.name)
            }.getOrDefault(QuotaMode.SMART_AI),
            autosaveEnabled = prefs[KEY_AUTOSAVE] ?: true
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[KEY_THEME_MODE] = mode.name }
    }

    suspend fun setDynamicColor(enabled: Boolean) {
        context.dataStore.edit { it[KEY_DYNAMIC_COLOR] = enabled }
    }

    suspend fun setPreferredLanguage(language: String) {
        context.dataStore.edit { it[KEY_LANGUAGE] = language }
    }

    suspend fun setDefaultResolution(resolution: String) {
        context.dataStore.edit { it[KEY_DEFAULT_RESOLUTION] = resolution }
    }

    suspend fun setDefaultAspectRatio(aspect: String) {
        context.dataStore.edit { it[KEY_DEFAULT_ASPECT] = aspect }
    }

    suspend fun setDefaultDurationPreset(preset: String) {
        context.dataStore.edit { it[KEY_DEFAULT_DURATION] = preset }
    }

    suspend fun setAiUploadConsent(granted: Boolean) {
        context.dataStore.edit { it[KEY_AI_CONSENT] = granted }
    }

    suspend fun setQuotaMode(mode: QuotaMode) {
        context.dataStore.edit { it[KEY_QUOTA_MODE] = mode.name }
    }

    suspend fun setAutosaveEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_AUTOSAVE] = enabled }
    }

    companion object {
        private val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        private val KEY_DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        private val KEY_LANGUAGE = stringPreferencesKey("preferred_language")
        private val KEY_DEFAULT_RESOLUTION = stringPreferencesKey("default_resolution")
        private val KEY_DEFAULT_ASPECT = stringPreferencesKey("default_aspect")
        private val KEY_DEFAULT_DURATION = stringPreferencesKey("default_duration")
        private val KEY_AI_CONSENT = booleanPreferencesKey("ai_upload_consent")
        private val KEY_QUOTA_MODE = stringPreferencesKey("quota_mode")
        private val KEY_AUTOSAVE = booleanPreferencesKey("autosave_enabled")
    }
}
