package com.example.core

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores user-configured third-party AI provider credentials encrypted with
 * Android Keystore AES-256-GCM. Keys are never logged, exported, or displayed
 * in plaintext in the UI.
 */
open class SecureVault(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            ANDROID_KEYSTORE
        )
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    open fun saveApiKey(providerId: String, rawKey: String) {
        val trimmed = rawKey.trim()
        if (trimmed.isEmpty()) {
            removeApiKey(providerId)
            return
        }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(trimmed.toByteArray(Charsets.UTF_8))
        val payload = Base64.encodeToString(iv, Base64.NO_WRAP) + ":" +
            Base64.encodeToString(encrypted, Base64.NO_WRAP)
        prefs.edit().putString(keyPrefix(providerId), payload).apply()
    }

    open fun getApiKey(providerId: String): String? {
        val stored = prefs.getString(keyPrefix(providerId), null) ?: return null
        return try {
            val parts = stored.split(":")
            if (parts.size != 2) return null
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val encrypted = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }

    open fun hasApiKey(providerId: String): Boolean = !getApiKey(providerId).isNullOrBlank()

    open fun getMaskedKeyLabel(providerId: String): String {
        val key = getApiKey(providerId) ?: return "Not configured"
        return if (key.length <= 8) {
            "••••••••"
        } else {
            "${key.take(4)}••••${key.takeLast(4)}"
        }
    }

    open fun removeApiKey(providerId: String) {
        prefs.edit().remove(keyPrefix(providerId)).apply()
    }

    open fun clearAllKeys() {
        prefs.edit().clear().apply()
    }

    private fun keyPrefix(providerId: String) = "cred_$providerId"

    companion object {
        private const val PREFS_NAME = "clipfree_secure_vault"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "clipfree_ai_cred_master_key"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
