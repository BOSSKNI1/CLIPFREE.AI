package com.example.ui.screens

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ai.AiOverallHealth
import com.example.ai.FailoverSnapshot
import com.example.core.AppPreferences
import com.example.core.QuotaMode
import com.example.core.TimeUtils
import com.example.data.local.CreatorTemplateEntity
import com.example.data.local.ProjectEntity
import com.example.data.model.AspectRatioOption
import com.example.data.model.CaptionAnimationStyle
import com.example.data.model.CaptionStyleConfig
import com.example.data.model.DurationPreset
import com.example.data.model.SocialPlatform
import com.example.ui.components.AiHealthStatusPill
import com.example.ui.components.QuotaExhaustedBanner
import com.example.ui.components.VideoThumbnailImage
import com.example.ui.components.rememberVideoImportLaunchers
import com.example.ui.viewmodel.AutoCreateUiState
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateScreen(
    uiState: AutoCreateUiState,
    preferences: AppPreferences,
    failoverSnapshot: FailoverSnapshot,
    templates: List<CreatorTemplateEntity>,
    onImportVideo: (Uri, AspectRatioOption, SocialPlatform, DurationPreset, String) -> Unit,
    onStartAutoCreate: (ProjectEntity, Int, Int, AspectRatioOption, SocialPlatform, CaptionStyleConfig, String) -> Unit,
    onCancelProcessing: (ProjectEntity) -> Unit,
    onCreateManualClip: (ProjectEntity, AspectRatioOption, CaptionStyleConfig) -> Unit,
    onOpenGeneratedProject: (Long) -> Unit,
    onGrantAiConsent: () -> Unit,
    onResetFlow: () -> Unit,
    onOpenProfileProviders: () -> Unit = {},
    onSwitchLocalMode: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedDurationPreset by remember(preferences.defaultDurationPreset) {
        mutableStateOf(DurationPreset.fromId(preferences.defaultDurationPreset))
    }
    var customSeconds by remember { mutableFloatStateOf(40f) }
    var selectedPlatform by remember { mutableStateOf(SocialPlatform.YOUTUBE_SHORTS) }
    var selectedAspect by remember(preferences.defaultAspectRatio) {
        mutableStateOf(AspectRatioOption.fromId(preferences.defaultAspectRatio))
    }
    var selectedCaptionStyle by remember { mutableStateOf(CaptionAnimationStyle.BOLD_CREATOR) }
    var selectedTemplate by remember { mutableStateOf<CreatorTemplateEntity?>(null) }
    var showConsentDialog by remember { mutableStateOf<ProjectEntity?>(null) }

    val (launchSaf, launchPhotoPicker) = rememberVideoImportLaunchers { uri ->
        onImportVideo(uri, selectedAspect, selectedPlatform, selectedDurationPreset, selectedCaptionStyle.id)
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Auto Create Shorts",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    AiHealthStatusPill(
                        snapshot = failoverSnapshot,
                        onClick = onOpenProfileProviders
                    )
                    if (!failoverSnapshot.lastSwitchingEvent.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                        ) {
                            Text(
                                text = "API Status: ${failoverSnapshot.lastSwitchingEvent}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            if (failoverSnapshot.health == AiOverallHealth.QUOTA_EXHAUSTED) {
                item {
                    QuotaExhaustedBanner(
                        onOpenProviders = onOpenProfileProviders,
                        onSwitchLocalMode = onSwitchLocalMode
                    )
                }
            }

            when (uiState) {
                is AutoCreateUiState.Idle -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(22.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.FileUpload,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(44.dp)
                                )
                                Text(
                                    text = "Step 1: Import a Long Video",
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Text(
                                    text = "Select any MP4, MOV, or MKV from your device. Your original video stays untouched on-device.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Button(
                                        onClick = launchSaf,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("create_pick_saf_button")
                                    ) {
                                        Icon(Icons.Rounded.FileUpload, null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Browse Files")
                                    }
                                    OutlinedButton(
                                        onClick = launchPhotoPicker,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("create_pick_gallery_button")
                                    ) {
                                        Icon(Icons.Rounded.PhotoLibrary, null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Gallery Picker")
                                    }
                                }
                            }
                        }
                    }
                }

                is AutoCreateUiState.Importing -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(20.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(28.dp))
                                Spacer(Modifier.width(14.dp))
                                Text(uiState.message, style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                }

                is AutoCreateUiState.ReadyToGenerate -> {
                    val project = uiState.project
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                VideoThumbnailImage(
                                    thumbnailPath = project.thumbnailPath,
                                    contentDescription = project.title,
                                    modifier = Modifier.size(width = 96.dp, height = 72.dp)
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(project.title, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        text = "${TimeUtils.formatDuration(project.durationMs)} • ${project.width}×${project.height} • ${TimeUtils.formatFileSize(project.fileSizeBytes)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = if (project.hasAudio) "Audio track detected" else "No audio track (visual analysis)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                TextButton(onClick = onResetFlow) { Text("Change") }
                            }
                        }
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Text("Step 2: Clip Duration", style = MaterialTheme.typography.titleMedium)
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    DurationPreset.entries.forEach { preset ->
                                        FilterChip(
                                            selected = selectedDurationPreset == preset,
                                            onClick = { selectedDurationPreset = preset },
                                            label = { Text(preset.label) }
                                        )
                                    }
                                }
                                if (selectedDurationPreset == DurationPreset.CUSTOM) {
                                    Column {
                                        Text(
                                            text = "Target length: ~${customSeconds.roundToInt()} seconds",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Slider(
                                            value = customSeconds,
                                            onValueChange = { customSeconds = it },
                                            valueRange = 10f..120f
                                        )
                                    }
                                }

                                Text("Step 3: Platform & Aspect Ratio", style = MaterialTheme.typography.titleMedium)
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    SocialPlatform.entries.forEach { plat ->
                                        FilterChip(
                                            selected = selectedPlatform == plat,
                                            onClick = {
                                                selectedPlatform = plat
                                                if (plat != SocialPlatform.CUSTOM) {
                                                    selectedAspect = plat.recommendedAspect
                                                }
                                            },
                                            label = { Text(plat.label) }
                                        )
                                    }
                                }
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AspectRatioOption.entries.forEach { ratio ->
                                        FilterChip(
                                            selected = selectedAspect == ratio,
                                            onClick = { selectedAspect = ratio },
                                            label = { Text(ratio.label) }
                                        )
                                    }
                                }

                                Text("Step 4: Caption Style & Creator Template", style = MaterialTheme.typography.titleMedium)
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    CaptionAnimationStyle.entries.forEach { style ->
                                        FilterChip(
                                            selected = selectedCaptionStyle == style,
                                            onClick = { selectedCaptionStyle = style },
                                            label = { Text(style.label) }
                                        )
                                    }
                                }

                                if (templates.isNotEmpty()) {
                                    Text("Optional Template Preset", style = MaterialTheme.typography.labelLarge)
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        templates.take(6).forEach { tpl ->
                                            FilterChip(
                                                selected = selectedTemplate?.id == tpl.id,
                                                onClick = {
                                                    selectedTemplate = if (selectedTemplate?.id == tpl.id) null else tpl
                                                    selectedTemplate?.let {
                                                        selectedCaptionStyle = CaptionAnimationStyle.fromId(it.captionStyleId)
                                                        selectedAspect = AspectRatioOption.fromId(it.aspectRatio)
                                                    }
                                                },
                                                label = { Text(tpl.name) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        val minSec = if (selectedDurationPreset == DurationPreset.CUSTOM) {
                            (customSeconds.roundToInt() - 10).coerceAtLeast(10)
                        } else selectedDurationPreset.minSeconds
                        val maxSec = if (selectedDurationPreset == DurationPreset.CUSTOM) {
                            (customSeconds.roundToInt() + 10).coerceAtMost(150)
                        } else selectedDurationPreset.maxSeconds

                        val captionConfig = CaptionStyleConfig(
                            styleId = selectedCaptionStyle.id,
                            fontName = selectedTemplate?.fontName ?: "Space Grotesk",
                            highlightColorHex = selectedTemplate?.accentColorHex ?: "#9878FF"
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (preferences.quotaMode != QuotaMode.LOCAL_MODE) {
                                Button(
                                    onClick = {
                                        if (preferences.aiUploadConsentGranted) {
                                            onStartAutoCreate(
                                                project, minSec, maxSec, selectedAspect,
                                                selectedPlatform, captionConfig, preferences.preferredLanguage
                                            )
                                        } else {
                                            showConsentDialog = project
                                        }
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp)
                                        .testTag("start_auto_create_button")
                                ) {
                                    Icon(Icons.Rounded.AutoAwesome, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Auto Create AI Clips")
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    onCreateManualClip(project, selectedAspect, captionConfig)
                                },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("manual_local_clip_button")
                            ) {
                                Icon(Icons.Rounded.ContentCut, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Edit & Clip Locally (No AI Quota Used)")
                            }
                        }
                    }
                }

                is AutoCreateUiState.Processing -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "Processing \"${uiState.project.title}\"",
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Text(
                                    text = uiState.step.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                LinearProgressIndicator(
                                    progress = { uiState.step.fraction },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                )
                                OutlinedButton(
                                    onClick = { onCancelProcessing(uiState.project) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.Close, null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Cancel Processing")
                                }
                            }
                        }
                    }
                }

                is AutoCreateUiState.Completed -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer
                            ),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Rounded.CheckCircle,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "${uiState.clipCount} Short Clip(s) Ready!",
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                }
                                Text(
                                    text = "Clips were analyzed, timestamp-validated, and saved locally. Preview, edit captions, reframe, and export MP4s now.",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Button(
                                        onClick = { onOpenGeneratedProject(uiState.projectId) },
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("Preview & Edit Clips")
                                    }
                                    TextButton(onClick = onResetFlow) {
                                        Text("New Video")
                                    }
                                }
                            }
                        }
                    }
                }

                is AutoCreateUiState.Error -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer
                            ),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.ErrorOutline, null, tint = MaterialTheme.colorScheme.onErrorContainer)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "Processing Interrupted",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                                Text(
                                    text = uiState.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val proj = uiState.project
                                    if (proj != null && uiState.canRetryAi) {
                                        Button(
                                            onClick = {
                                                onStartAutoCreate(
                                                    proj,
                                                    selectedDurationPreset.minSeconds,
                                                    selectedDurationPreset.maxSeconds,
                                                    selectedAspect,
                                                    selectedPlatform,
                                                    CaptionStyleConfig(styleId = selectedCaptionStyle.id),
                                                    preferences.preferredLanguage
                                                )
                                            }
                                        ) {
                                            Icon(Icons.Rounded.Refresh, null, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Retry AI")
                                        }
                                        OutlinedButton(onClick = onOpenProfileProviders) {
                                            Text("Add / Switch API")
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                onCreateManualClip(
                                                    proj,
                                                    selectedAspect,
                                                    CaptionStyleConfig(styleId = selectedCaptionStyle.id)
                                                )
                                            }
                                        ) {
                                            Text("Edit Locally")
                                        }
                                    } else {
                                        OutlinedButton(onClick = onResetFlow) {
                                            Text("Try Another Video")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    showConsentDialog?.let { pendingProject ->
        AlertDialog(
            onDismissRequest = { showConsentDialog = null },
            icon = { Icon(Icons.Rounded.PrivacyTip, contentDescription = null) },
            title = { Text("Cloud AI Media Processing") },
            text = { Text(stringResource(R.string.privacy_ai_disclosure)) },
            confirmButton = {
                Button(
                    onClick = {
                        onGrantAiConsent()
                        showConsentDialog = null
                        val minSec = if (selectedDurationPreset == DurationPreset.CUSTOM) {
                            (customSeconds.roundToInt() - 10).coerceAtLeast(10)
                        } else selectedDurationPreset.minSeconds
                        val maxSec = if (selectedDurationPreset == DurationPreset.CUSTOM) {
                            (customSeconds.roundToInt() + 10).coerceAtMost(150)
                        } else selectedDurationPreset.maxSeconds
                        onStartAutoCreate(
                            pendingProject,
                            minSec,
                            maxSec,
                            selectedAspect,
                            selectedPlatform,
                            CaptionStyleConfig(
                                styleId = selectedCaptionStyle.id,
                                fontName = selectedTemplate?.fontName ?: "Space Grotesk",
                                highlightColorHex = selectedTemplate?.accentColorHex ?: "#9878FF"
                            ),
                            preferences.preferredLanguage
                        )
                    }
                ) { Text("Allow & Analyze") }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showConsentDialog = null
                        onCreateManualClip(
                            pendingProject,
                            selectedAspect,
                            CaptionStyleConfig(styleId = selectedCaptionStyle.id)
                        )
                    }
                ) { Text("Keep Local Only") }
            }
        )
    }
}
