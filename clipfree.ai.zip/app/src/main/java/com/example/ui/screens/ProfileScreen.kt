package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudSync
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.NetworkCheck
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.ai.FailoverSnapshot
import com.example.ai.ProviderStatus
import com.example.ai.ProviderType
import com.example.core.AppPreferences
import com.example.core.QuotaMode
import com.example.core.TimeUtils
import com.example.data.cloud.CloudSyncStatus
import com.example.data.local.AiProviderConfigEntity
import com.example.data.model.AspectRatioOption
import com.example.data.model.DeviceCapabilities
import com.example.data.model.ExportResolution
import com.example.ui.components.AiHealthStatusPill
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.ThemeMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val SUPPORTED_LANGUAGES = listOf(
    "English", "Hindi", "Marathi", "Tamil", "Telugu", "Bengali", "Spanish"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    preferences: AppPreferences,
    failoverSnapshot: FailoverSnapshot,
    providers: List<AiProviderConfigEntity>,
    testingProviderId: String?,
    deviceCapabilities: DeviceCapabilities,
    storageUsage: Pair<Long, Long>,
    getMaskedKey: (String) -> String,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSetDynamicColor: (Boolean) -> Unit,
    onSetLanguage: (String) -> Unit,
    onSetDefaultResolution: (String) -> Unit,
    onSetDefaultAspect: (String) -> Unit,
    onSetQuotaMode: (QuotaMode) -> Unit,
    onSetAiConsent: (Boolean) -> Unit,
    onSetAutosave: (Boolean) -> Unit,
    onTestProvider: (AiProviderConfigEntity) -> Unit,
    onSelectActiveProvider: (String) -> Unit,
    onToggleProviderEnabled: (AiProviderConfigEntity, Boolean) -> Unit,
    onMoveProviderPriority: (AiProviderConfigEntity, Int) -> Unit,
    onSaveProvider: (String?, ProviderType, String, String, String, Int, String?) -> Unit,
    onDeleteProvider: (String) -> Unit,
    onClearAllKeys: () -> Unit,
    onClearCache: () -> Unit,
    userDisplayName: String = "Creator",
    userEmail: String? = null,
    userPhotoUrl: String? = null,
    cloudSyncStatus: CloudSyncStatus = CloudSyncStatus.Idle,
    isLoggingOut: Boolean = false,
    onSyncNow: () -> Unit = {},
    onSignOut: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showAddProviderDialog by remember { mutableStateOf(false) }
    var editingProvider by remember { mutableStateOf<AiProviderConfigEntity?>(null) }
    var showGithubGuideDialog by remember { mutableStateOf(false) }
    var showSignOutDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
                .testTag("profile_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("Profile & Studio Settings", style = MaterialTheme.typography.headlineMedium)
            }

            // Creator Google Account & Cloud Backup Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("account_card")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.cloud_sync_title),
                            style = MaterialTheme.typography.titleLarge
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            if (!userPhotoUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = userPhotoUrl,
                                    contentDescription = "Google account avatar",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(52.dp)
                                        .clip(CircleShape)
                                )
                            } else {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = CircleShape,
                                    modifier = Modifier.size(52.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.AccountCircle,
                                            contentDescription = "Creator account",
                                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = userDisplayName.ifBlank { "Creator" },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (!userEmail.isNullOrBlank()) {
                                    Text(
                                        text = userEmail,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = "Google Sign-In Active",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusSuccess
                                )
                            }
                        }

                        HorizontalDivider()

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CloudDone,
                                contentDescription = null,
                                tint = when (cloudSyncStatus) {
                                    is CloudSyncStatus.Error -> MaterialTheme.colorScheme.error
                                    is CloudSyncStatus.Synced -> StatusSuccess
                                    else -> MaterialTheme.colorScheme.primary
                                },
                                modifier = Modifier.size(18.dp)
                            )
                            val statusText = when (cloudSyncStatus) {
                                is CloudSyncStatus.Idle -> "Projects, clips, brand kits & templates sync automatically."
                                is CloudSyncStatus.Syncing -> "Syncing studio metadata with Firebase Firestore..."
                                is CloudSyncStatus.Synced -> {
                                    val timeStr = remember(cloudSyncStatus.syncedAtMs) {
                                        SimpleDateFormat("HH:mm", Locale.getDefault())
                                            .format(Date(cloudSyncStatus.syncedAtMs))
                                    }
                                    "Synced ${cloudSyncStatus.projectsCount} projects & ${cloudSyncStatus.clipsCount} clips at $timeStr"
                                }
                                is CloudSyncStatus.Error -> "Sync issue: ${cloudSyncStatus.message}"
                            }
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (cloudSyncStatus is CloudSyncStatus.Error) {
                                    MaterialTheme.colorScheme.error
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = onSyncNow,
                                enabled = cloudSyncStatus !is CloudSyncStatus.Syncing,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("sync_now_button")
                            ) {
                                if (cloudSyncStatus is CloudSyncStatus.Syncing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(Icons.Rounded.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                                }
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.sync_now))
                            }
                            OutlinedButton(
                                onClick = { showSignOutDialog = true },
                                enabled = !isLoggingOut,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("sign_out_button")
                            ) {
                                if (isLoggingOut) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                } else {
                                    Icon(
                                        Icons.AutoMirrored.Rounded.Logout,
                                        contentDescription = stringResource(R.string.sign_out),
                                        modifier = Modifier.size(18.dp),
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = if (isLoggingOut) "Logging out..." else stringResource(R.string.sign_out),
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            // AI Provider & Smart Failover Dashboard
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("AI API Management & Failover", style = MaterialTheme.typography.titleLarge)
                            TextButton(
                                onClick = {
                                    editingProvider = null
                                    showAddProviderDialog = true
                                },
                                modifier = Modifier.testTag("add_ai_provider_button")
                            ) {
                                Icon(Icons.Rounded.Add, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Add API")
                            }
                        }

                        AiHealthStatusPill(snapshot = failoverSnapshot)

                        Text(
                            text = "Active: ${failoverSnapshot.activeProviderName} (${failoverSnapshot.activeModelName})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        failoverSnapshot.lastSwitchingEvent?.let { evt ->
                            Text(
                                text = "Last switch event: $evt",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        HorizontalDivider()
                        Text("Smart AI Quota Manager", style = MaterialTheme.typography.titleSmall)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            QuotaMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = preferences.quotaMode == mode,
                                    onClick = { onSetQuotaMode(mode) },
                                    label = { Text(mode.label) }
                                )
                            }
                        }
                        Text(
                            text = preferences.quotaMode.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        HorizontalDivider()
                        val configuredBackupCount = providers.count {
                            it.isEnabled && (it.providerType == ProviderType.FIREBASE_AI_LOGIC.id || getMaskedKey(it.id) != "Not configured")
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (configuredBackupCount <= 1) {
                                    "Only 1 AI API is active. Tap \"Add API\" to add a backup key (Gemini, Groq, OpenRouter, or OpenAI-compatible) so CLIPFREE.AI automatically selects it and continues when API points run out."
                                } else {
                                    "Auto-failover armed across $configuredBackupCount enabled APIs. When the active API runs out of points or hits limits, the next priority API is automatically selected to continue."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                        Text("Configured Providers (${providers.size})", style = MaterialTheme.typography.titleSmall)

                        providers.forEach { provider ->
                            val statusColor = when (provider.status) {
                                ProviderStatus.AVAILABLE -> StatusSuccess
                                ProviderStatus.LIMITED -> StatusWarning
                                ProviderStatus.QUOTA_EXHAUSTED, ProviderStatus.UNAUTHORIZED -> StatusError
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(provider.displayName, style = MaterialTheme.typography.titleSmall)
                                                if (provider.isActive) {
                                                    Spacer(Modifier.width(6.dp))
                                                    Icon(
                                                        Icons.Rounded.CheckCircle,
                                                        contentDescription = "Active provider",
                                                        tint = StatusSuccess,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                            Text(
                                                text = "Model: ${provider.modelName} • Priority #${provider.priority + 1}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = buildString {
                                                    append("Status: ${provider.status}")
                                                    if (provider.providerType != ProviderType.FIREBASE_AI_LOGIC.id) {
                                                        append(" • Key: ${getMaskedKey(provider.id)}")
                                                    }
                                                },
                                                style = MaterialTheme.typography.labelSmall,
                                                color = statusColor
                                            )
                                            if (!provider.rateLimitRemaining.isNullOrBlank()) {
                                                Text(
                                                    text = "Provider-reported remaining: ${provider.rateLimitRemaining} (Reset: ${provider.rateLimitReset ?: "N/A"})",
                                                    style = MaterialTheme.typography.labelSmall
                                                )
                                            }
                                            provider.lastError?.let { err ->
                                                Text(
                                                    text = err,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                            }
                                        }
                                        Switch(
                                            checked = provider.isEnabled,
                                            onCheckedChange = { onToggleProviderEnabled(provider, it) }
                                        )
                                    }

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = { onTestProvider(provider) },
                                            enabled = testingProviderId != provider.id,
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            if (testingProviderId == provider.id) {
                                                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                            } else {
                                                Icon(Icons.Rounded.NetworkCheck, null, modifier = Modifier.size(16.dp))
                                            }
                                            Spacer(Modifier.width(4.dp))
                                            Text("Test")
                                        }
                                        if (!provider.isActive) {
                                            TextButton(onClick = { onSelectActiveProvider(provider.id) }) {
                                                Text("Set Active")
                                            }
                                        }
                                        IconButton(onClick = { onMoveProviderPriority(provider, -1) }) {
                                            Icon(Icons.Rounded.ArrowUpward, contentDescription = "Increase priority")
                                        }
                                        IconButton(onClick = { onMoveProviderPriority(provider, 1) }) {
                                            Icon(Icons.Rounded.ArrowDownward, contentDescription = "Decrease priority")
                                        }
                                        if (provider.id != "builtin_firebase_ai") {
                                            IconButton(
                                                onClick = {
                                                    editingProvider = provider
                                                    showAddProviderDialog = true
                                                }
                                            ) {
                                                Icon(
                                                    Icons.Rounded.Edit,
                                                    contentDescription = "Edit API key or model"
                                                )
                                            }
                                            IconButton(onClick = { onDeleteProvider(provider.id) }) {
                                                Icon(
                                                    Icons.Rounded.DeleteOutline,
                                                    contentDescription = "Remove provider",
                                                    tint = MaterialTheme.colorScheme.error
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Theme Settings
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Appearance & Theme", style = MaterialTheme.typography.titleMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ThemeMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = preferences.themeMode == mode,
                                    onClick = { onSetThemeMode(mode) },
                                    label = { Text(mode.label) },
                                    modifier = Modifier.testTag("theme_chip_${mode.name.lowercase()}")
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Dynamic Wallpaper Colors (Android 12+)", modifier = Modifier.weight(1f))
                            Switch(
                                checked = preferences.dynamicColor,
                                onCheckedChange = onSetDynamicColor
                            )
                        }
                    }
                }
            }

            // Language & Export Settings
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Language & Default Export Settings", style = MaterialTheme.typography.titleMedium)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            SUPPORTED_LANGUAGES.forEach { lang ->
                                FilterChip(
                                    selected = preferences.preferredLanguage == lang,
                                    onClick = { onSetLanguage(lang) },
                                    label = { Text(lang) }
                                )
                            }
                        }
                        Text("Default Resolution", style = MaterialTheme.typography.titleSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ExportResolution.entries.forEach { res ->
                                val supported = res != ExportResolution.RES_4K || deviceCapabilities.supports4kEncode
                                FilterChip(
                                    selected = preferences.defaultResolution == res.id,
                                    enabled = supported,
                                    onClick = { onSetDefaultResolution(res.id) },
                                    label = {
                                        Text(if (supported) res.label else "${res.label} (Unsupported)")
                                    }
                                )
                            }
                        }
                        Text("Default Aspect Ratio", style = MaterialTheme.typography.titleSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AspectRatioOption.entries.forEach { ratio ->
                                FilterChip(
                                    selected = preferences.defaultAspectRatio == ratio.id,
                                    onClick = { onSetDefaultAspect(ratio.id) },
                                    label = { Text(ratio.label) }
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Autosave & Crash Recovery", modifier = Modifier.weight(1f))
                            Switch(
                                checked = preferences.autosaveEnabled,
                                onCheckedChange = onSetAutosave
                            )
                        }
                    }
                }
            }

            // Storage & Privacy
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Storage, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("Storage & Device Capabilities", style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            text = "App Exports & Thumbnails: ${TimeUtils.formatFileSize(storageUsage.second)} • Temp Cache: ${TimeUtils.formatFileSize(storageUsage.first)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Free Device Storage: ${TimeUtils.formatFileSize(deviceCapabilities.availableStorageBytes)} • Hardware Max: ${deviceCapabilities.maxSupportedWidth}×${deviceCapabilities.maxSupportedHeight} • 4K Encode: ${if (deviceCapabilities.supports4kEncode) "Supported" else "Not Supported"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(onClick = onClearCache) {
                            Text("Clear Temporary Cache")
                        }

                        HorizontalDivider()
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Security, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("Privacy & Security", style = MaterialTheme.typography.titleMedium)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Allow Cloud AI Media Analysis", modifier = Modifier.weight(1f))
                            Switch(
                                checked = preferences.aiUploadConsentGranted,
                                onCheckedChange = onSetAiConsent
                            )
                        }
                        Text(
                            text = stringResource(R.string.privacy_ai_disclosure),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(onClick = onClearAllKeys) {
                            Text("Clear Stored Third-Party API Keys")
                        }
                    }
                }
            }

            // Help, Disclaimers & Cloud APK Guide
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.HelpOutline, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("About CLIPFREE.AI & Cloud APK Builds", style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            text = stringResource(R.string.virality_disclaimer),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Switching AI providers routes requests to another valid connection you configured; it does not reset any provider's quota.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(onClick = { showGithubGuideDialog = true }) {
                            Text("How to Download APK via Mobile Browser")
                        }
                    }
                }
            }
        }
    }

    if (showAddProviderDialog) {
        val initialType = editingProvider?.let { ep ->
            ProviderType.entries.firstOrNull { it.id == ep.providerType }
        } ?: ProviderType.GEMINI_REST
        var selectedType by remember(showAddProviderDialog, editingProvider) { mutableStateOf(initialType) }
        var name by remember(showAddProviderDialog, editingProvider) { mutableStateOf(editingProvider?.displayName ?: "") }
        var model by remember(showAddProviderDialog, editingProvider) {
            mutableStateOf(editingProvider?.modelName ?: initialType.defaultModel)
        }
        var endpoint by remember(showAddProviderDialog, editingProvider) {
            mutableStateOf(editingProvider?.endpointUrl ?: initialType.defaultEndpoint)
        }
        var apiKey by remember(showAddProviderDialog, editingProvider) { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = {
                showAddProviderDialog = false
                editingProvider = null
            },
            title = {
                Text(if (editingProvider == null) "Configure AI Provider Connection" else "Update AI Provider & Key")
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ProviderType.entries.filter { it != ProviderType.FIREBASE_AI_LOGIC }.forEach { pt ->
                            FilterChip(
                                selected = selectedType == pt,
                                onClick = {
                                    selectedType = pt
                                    if (name.isBlank()) name = pt.label
                                    model = pt.defaultModel
                                    endpoint = pt.defaultEndpoint
                                },
                                label = { Text(pt.label) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Connection Name") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        label = { Text("Model Name") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = endpoint,
                        onValueChange = { endpoint = it },
                        label = { Text("Base Endpoint URL") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { apiKey = it },
                        label = { Text("API Key (Stored in Android Keystore)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveProvider(
                            editingProvider?.id,
                            selectedType,
                            name.ifBlank { selectedType.label },
                            model.ifBlank { selectedType.defaultModel },
                            endpoint.ifBlank { selectedType.defaultEndpoint },
                            editingProvider?.priority ?: providers.size,
                            apiKey
                        )
                        showAddProviderDialog = false
                        editingProvider = null
                    }
                ) { Text("Save Securely") }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showAddProviderDialog = false
                        editingProvider = null
                    }
                ) { Text("Cancel") }
            }
        )
    }

    if (showGithubGuideDialog) {
        AlertDialog(
            onDismissRequest = { showGithubGuideDialog = false },
            title = { Text("Download APK from GitHub Actions") },
            text = {
                Text(
                    "1. Push this project to a GitHub repository.\n" +
                        "2. Open the repository in your Android phone's browser and sign in to GitHub.\n" +
                        "3. Tap the \"Actions\" tab and select \"CLIPFREE.AI Android CI\".\n" +
                        "4. Open the latest green workflow run and scroll down to \"Artifacts\".\n" +
                        "5. Tap \"CLIPFREE-AI-debug-apk\" to download the ZIP, extract the .apk in your Files app, and tap to install."
                )
            },
            confirmButton = {
                TextButton(onClick = { showGithubGuideDialog = false }) { Text("Got It") }
            }
        )
    }

    if (showSignOutDialog) {
        AlertDialog(
            onDismissRequest = { showSignOutDialog = false },
            title = { Text("Log Out of CLIPFREE.AI?") },
            text = {
                Text("This clears your active Firebase session and returns you to the sign-in screen. Your cloud backups and local exported MP4 files remain safe.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSignOutDialog = false
                        onSignOut()
                    },
                    modifier = Modifier.testTag("confirm_sign_out_button")
                ) {
                    Text(stringResource(R.string.sign_out))
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
