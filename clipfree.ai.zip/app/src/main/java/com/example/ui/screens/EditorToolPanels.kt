package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CallSplit
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Merge
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ai.BRollSuggestionDto
import com.example.ai.MetadataAndHooksResult
import com.example.ai.RepeatedTakeSuggestionDto
import com.example.core.TimeUtils
import com.example.data.local.BrandKitEntity
import com.example.data.local.CreatorTemplateEntity
import com.example.data.local.ExportStatus
import com.example.data.local.GeneratedClipEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.TranscriptSegmentEntity
import com.example.data.model.AspectRatioOption
import com.example.data.model.CaptionAnimationStyle
import com.example.data.model.CaptionStyleConfig
import com.example.data.model.ClipEditTimeline
import com.example.data.model.TimeRangeMs
import com.example.data.model.VideoChapter
import com.example.ui.components.ViralityScoreBadge
import com.example.video.CoverLayoutStyle
import com.example.video.SubtitleFormat
import com.example.video.VideoExportEngine
import java.io.File
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClipsEditorTab(
    project: ProjectEntity,
    clips: List<GeneratedClipEntity>,
    selectedClip: GeneratedClipEntity?,
    hooksResult: MetadataAndHooksResult?,
    isAiBusy: Boolean,
    onSelectClip: (GeneratedClipEntity) -> Unit,
    onCreateDefaultClip: () -> Unit,
    onCreateManualClip: (String, Long, Long) -> Unit,
    onDeleteClip: () -> Unit,
    onMergeWithNext: () -> Unit,
    onGenerateHooks: () -> Unit,
    onUpdateClipTitleAndCaption: (String, String) -> Unit
) {
    val context = LocalContext.current
    var showCreateDialog by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Candidate Clips (${clips.size})", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextButton(onClick = { showCreateDialog = true }) {
                    Icon(Icons.Rounded.Add, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Manual Clip")
                }
                TextButton(onClick = onGenerateHooks, enabled = !isAiBusy) {
                    Icon(Icons.Rounded.AutoAwesome, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("AI Hooks")
                }
            }
        }

        if (clips.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("No clips in this project yet", style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = "Create a manual clip segment to start trimming, captioning, and exporting MP4s.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onCreateDefaultClip) {
                            Icon(Icons.Rounded.Add, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Create 30s Clip")
                        }
                        OutlinedButton(onClick = { showCreateDialog = true }) {
                            Text("Custom Range")
                        }
                    }
                }
            }
        }

        clips.forEach { clip ->
            val isSelected = clip.id == selectedClip?.id
            Card(
                onClick = { onSelectClip(clip) },
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
                    else MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = clip.title,
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.weight(1f)
                        )
                        ViralityScoreBadge(clip.viralityScore, clip.isAiGenerated)
                    }
                    Text(
                        text = "${TimeUtils.formatDuration(clip.startMs)} – ${TimeUtils.formatDuration(clip.endMs)} (${TimeUtils.formatDuration(clip.endMs - clip.startMs)}) • ${clip.speakerLabel}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (clip.openingHook.isNotBlank()) {
                        Text(
                            text = "Hook: ${clip.openingHook}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    if (clip.scoreExplanation.isNotBlank()) {
                        Text(
                            text = clip.scoreExplanation,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (clip.exportStatus == ExportStatus.EXPORTING || clip.exportStatus == ExportStatus.QUEUED) {
                        LinearProgressIndicator(
                            progress = { (clip.exportProgress / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        if (selectedClip != null) {
            var editableTitle by remember(selectedClip.id) { mutableStateOf(selectedClip.title) }
            var editableCaption by remember(selectedClip.id) { mutableStateOf(selectedClip.suggestedCaption) }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Title, Caption & Actions", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(
                        value = editableTitle,
                        onValueChange = { editableTitle = it },
                        label = { Text("Clip Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editableCaption,
                        onValueChange = { editableCaption = it },
                        label = { Text("Social Caption & Hashtags") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onUpdateClipTitleAndCaption(editableTitle, editableCaption) }) {
                            Text("Save Copy")
                        }
                        OutlinedButton(onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("Caption", "$editableTitle\n\n$editableCaption"))
                        }) {
                            Icon(Icons.Rounded.ContentCopy, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Copy")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onMergeWithNext) {
                            Icon(Icons.Rounded.Merge, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Merge Next")
                        }
                        TextButton(onClick = onDeleteClip) {
                            Icon(Icons.Rounded.DeleteOutline, null, tint = MaterialTheme.colorScheme.error)
                            Spacer(Modifier.width(4.dp))
                            Text("Delete", color = MaterialTheme.colorScheme.error)
                        }
                    }
                    Text(
                        text = stringResource(R.string.virality_disclaimer),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        hooksResult?.let { hooks ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("AI Hook & Title Suggestions", style = MaterialTheme.typography.titleSmall)
                    hooks.hooks.forEach { h ->
                        Text("• [${h.category}] ${h.hookText}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (hooks.hashtags.isNotEmpty()) {
                        Text(hooks.hashtags.joinToString(" "), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var title by remember { mutableStateOf("Manual Clip") }
        var range by remember { mutableStateOf(0f..minOf(project.durationMs.toFloat(), 30_000f)) }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create Manual Clip") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Clip Title") })
                    Text("${TimeUtils.formatDuration(range.start.toLong())} – ${TimeUtils.formatDuration(range.endInclusive.toLong())}")
                    RangeSlider(
                        value = range,
                        onValueChange = { range = it },
                        valueRange = 0f..project.durationMs.toFloat().coerceAtLeast(1000f)
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onCreateManualClip(title, range.start.toLong(), range.endInclusive.toLong())
                    showCreateDialog = false
                }) { Text("Add Clip") }
            },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun TimelineEditorTab(
    project: ProjectEntity,
    timeline: ClipEditTimeline,
    playheadMs: Long,
    brandKits: List<BrandKitEntity>,
    templates: List<CreatorTemplateEntity>,
    onUpdateTimeline: ((ClipEditTimeline) -> ClipEditTimeline) -> Unit,
    onSplitAtPlayhead: () -> Unit,
    onApplyBrandKit: (BrandKitEntity) -> Unit,
    onApplyTemplate: (CreatorTemplateEntity) -> Unit
) {
    val maxDur = project.durationMs.toFloat().coerceAtLeast(1000f)
    val trimStart = timeline.trimStartMs.toFloat().coerceIn(0f, maxDur - 500f)
    val trimEnd = timeline.trimEndMs.takeIf { it > trimStart }?.toFloat()?.coerceIn(trimStart + 500f, maxDur) ?: maxDur

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Trim Window: ${TimeUtils.formatPreciseTimecode(trimStart.toLong())} – ${TimeUtils.formatPreciseTimecode(trimEnd.toLong())}",
                    style = MaterialTheme.typography.titleSmall
                )
                RangeSlider(
                    value = trimStart..trimEnd,
                    onValueChange = { newRange ->
                        onUpdateTimeline {
                            it.copy(
                                trimStartMs = newRange.start.toLong(),
                                trimEndMs = newRange.endInclusive.toLong()
                            )
                        }
                    },
                    valueRange = 0f..maxDur
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onSplitAtPlayhead) {
                        Icon(Icons.Rounded.CallSplit, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Split @ ${TimeUtils.formatDuration(playheadMs)}")
                    }
                    OutlinedButton(onClick = {
                        onUpdateTimeline { it.copy(rotationDegrees = (it.rotationDegrees + 90) % 360) }
                    }) {
                        Icon(Icons.Rounded.RotateRight, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Rotate (${timeline.rotationDegrees}°)")
                    }
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Automatic Zoom & Emphasis", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    Switch(
                        checked = timeline.autoZoomEnabled,
                        onCheckedChange = { enabled -> onUpdateTimeline { it.copy(autoZoomEnabled = enabled) } }
                    )
                }
                if (timeline.autoZoomEnabled) {
                    Text("Zoom Intensity: ${(timeline.autoZoomIntensity * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                    Slider(
                        value = timeline.autoZoomIntensity,
                        onValueChange = { v -> onUpdateTimeline { it.copy(autoZoomIntensity = v) } },
                        valueRange = 0.02f..0.24f
                    )
                }
                OutlinedTextField(
                    value = timeline.textOverlay,
                    onValueChange = { txt -> onUpdateTimeline { it.copy(textOverlay = txt) } },
                    label = { Text("Persistent Headline Overlay") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = timeline.introText,
                    onValueChange = { txt -> onUpdateTimeline { it.copy(introText = txt) } },
                    label = { Text("Intro Card Text (First 2s)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = timeline.outroText,
                    onValueChange = { txt -> onUpdateTimeline { it.copy(outroText = txt) } },
                    label = { Text("Outro / CTA Text (Last 2s)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = timeline.watermarkText,
                    onValueChange = { txt -> onUpdateTimeline { it.copy(watermarkText = txt) } },
                    label = { Text("Brand Watermark") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        if (brandKits.isNotEmpty() || templates.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Quick Brand Kits & Templates", style = MaterialTheme.typography.titleSmall)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        brandKits.forEach { kit ->
                            FilterChip(selected = timeline.brandKitId == kit.id, onClick = { onApplyBrandKit(kit) }, label = { Text("Kit: ${kit.name}") })
                        }
                        templates.take(5).forEach { tpl ->
                            FilterChip(selected = false, onClick = { onApplyTemplate(tpl) }, label = { Text(tpl.name) })
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CaptionsEditorTab(
    captionStyle: CaptionStyleConfig,
    onUpdateStyle: ((CaptionStyleConfig) -> CaptionStyleConfig) -> Unit,
    onExportSubtitles: (SubtitleFormat) -> Unit,
    onImportSrt: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Burned-in Animated Captions", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    Switch(
                        checked = captionStyle.enabled,
                        onCheckedChange = { en -> onUpdateStyle { it.copy(enabled = en) } }
                    )
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CaptionAnimationStyle.entries.forEach { style ->
                        FilterChip(
                            selected = captionStyle.styleId == style.id,
                            onClick = { onUpdateStyle { it.copy(styleId = style.id) } },
                            label = { Text(style.label) }
                        )
                    }
                }
                Text("Font Size: ${captionStyle.fontSizeSp.toInt()}sp", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = captionStyle.fontSizeSp,
                    onValueChange = { v -> onUpdateStyle { it.copy(fontSizeSp = v) } },
                    valueRange = 14f..36f
                )
                Text("Vertical Position: ${(captionStyle.positionYFraction * 100).toInt()}% (Safe zone: 20–82%)", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = captionStyle.positionYFraction,
                    onValueChange = { v -> onUpdateStyle { it.copy(positionYFraction = v) } },
                    valueRange = 0.12f..0.92f
                )
                Text("Background Opacity: ${(captionStyle.backgroundAlpha * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = captionStyle.backgroundAlpha,
                    onValueChange = { v -> onUpdateStyle { it.copy(backgroundAlpha = v) } },
                    valueRange = 0f..1f
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Subtitle Files (SRT / VTT / TXT)", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SubtitleFormat.entries.forEach { fmt ->
                        OutlinedButton(onClick = { onExportSubtitles(fmt) }) {
                            Icon(Icons.Rounded.Subtitles, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Export ${fmt.ext.uppercase()}")
                        }
                    }
                    OutlinedButton(onClick = onImportSrt) {
                        Text("Import .SRT")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReframeAndCoverTab(
    selectedClip: GeneratedClipEntity?,
    timeline: ClipEditTimeline,
    playheadMs: Long,
    onChangeAspectRatio: (AspectRatioOption) -> Unit,
    onUpdateTimeline: ((ClipEditTimeline) -> ClipEditTimeline) -> Unit,
    onGenerateCover: (Long, String, String, AspectRatioOption, CoverLayoutStyle, String) -> Unit
) {
    val activeAspect = AspectRatioOption.fromId(selectedClip?.aspectRatio ?: "9:16")
    var coverTitle by remember(selectedClip?.id) { mutableStateOf(selectedClip?.title ?: "Viral Highlight") }
    var coverSubtitle by remember { mutableStateOf("CLIPFREE.AI") }
    var coverLayout by remember { mutableStateOf(CoverLayoutStyle.GRADIENT_BOTTOM) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Aspect Ratio & Manual Crop Reframe", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AspectRatioOption.entries.forEach { ratio ->
                        FilterChip(
                            selected = activeAspect == ratio,
                            onClick = { onChangeAspectRatio(ratio) },
                            label = { Text(ratio.label) }
                        )
                    }
                }
                Text("Horizontal Crop Pan: ${String.format(Locale.US, "%.2f", timeline.cropOffsetX)}", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = timeline.cropOffsetX,
                    onValueChange = { v -> onUpdateTimeline { it.copy(cropOffsetX = v) } },
                    valueRange = -0.35f..0.35f
                )
                Text("Zoom Scale: ${String.format(Locale.US, "%.2fx", timeline.zoomScale)}", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = timeline.zoomScale,
                    onValueChange = { v -> onUpdateTimeline { it.copy(zoomScale = v) } },
                    valueRange = 0.8f..1.8f
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Thumbnail & Cover Generator (From Current Frame)", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(
                    value = coverTitle,
                    onValueChange = { coverTitle = it },
                    label = { Text("Cover Headline") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = coverSubtitle,
                    onValueChange = { coverSubtitle = it },
                    label = { Text("Subtitle") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CoverLayoutStyle.entries.forEach { layout ->
                        FilterChip(
                            selected = coverLayout == layout,
                            onClick = { coverLayout = layout },
                            label = { Text(layout.label) }
                        )
                    }
                }
                Button(onClick = {
                    onGenerateCover(playheadMs, coverTitle, coverSubtitle, activeAspect, coverLayout, "#7652E8")
                }) {
                    Icon(Icons.Rounded.Image, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Export Cover Image @ ${TimeUtils.formatDuration(playheadMs)}")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TranscriptAndSearchTab(
    transcript: List<TranscriptSegmentEntity>,
    detectedSilences: List<TimeRangeMs>,
    repeatedTakes: List<RepeatedTakeSuggestionDto>,
    isBusy: Boolean,
    onSeekTo: (Long) -> Unit,
    onToggleSegmentRemoved: (TranscriptSegmentEntity) -> Unit,
    onCreateClipFromSegment: (String, Long, Long) -> Unit,
    onDetectSilences: () -> Unit,
    onApproveSilences: (List<TimeRangeMs>) -> Unit,
    onTranslateTranscript: (String) -> Unit,
    onAnalyzeRepeatedTakes: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedSpeaker by remember { mutableStateOf<String?>(null) }

    val speakers = remember(transcript) {
        transcript.map { it.speakerLabel }.distinct()
    }
    val filtered = remember(transcript, searchQuery, selectedSpeaker) {
        transcript.filter { seg ->
            val spkOk = selectedSpeaker == null || seg.speakerLabel == selectedSpeaker
            val qOk = searchQuery.isBlank() || seg.text.contains(searchQuery, ignoreCase = true)
            spkOk && qOk
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search spoken words or topics...") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        if (speakers.size > 1) {
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = selectedSpeaker == null, onClick = { selectedSpeaker = null }, label = { Text("All Speakers") })
                speakers.forEach { spk ->
                    FilterChip(selected = selectedSpeaker == spk, onClick = { selectedSpeaker = spk }, label = { Text(spk) })
                }
            }
        }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = onDetectSilences, enabled = !isBusy) {
                Icon(Icons.Rounded.GraphicEq, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Detect Silences (Local)")
            }
            OutlinedButton(onClick = onAnalyzeRepeatedTakes, enabled = !isBusy) {
                Text("Detect Repeated Takes")
            }
            OutlinedButton(onClick = { onTranslateTranscript("Spanish") }, enabled = !isBusy) {
                Icon(Icons.Rounded.Translate, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Translate ES")
            }
            OutlinedButton(onClick = { onTranslateTranscript("Hindi") }, enabled = !isBusy) {
                Text("Translate HI")
            }
        }

        if (detectedSilences.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${detectedSilences.size} Pause / Silence Range(s) Found", style = MaterialTheme.typography.titleSmall)
                    detectedSilences.take(5).forEach { r ->
                        Text(
                            "• ${TimeUtils.formatPreciseTimecode(r.startMs)} – ${TimeUtils.formatPreciseTimecode(r.endMs)} (${r.endMs - r.startMs}ms)",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Button(onClick = { onApproveSilences(detectedSilences) }) {
                        Icon(Icons.Rounded.Check, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Approve & Remove Silences in Export")
                    }
                }
            }
        }

        if (repeatedTakes.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Repeated Takes Detected", style = MaterialTheme.typography.titleSmall)
                    repeatedTakes.forEach { take ->
                        Text("• ${take.phraseSummary}: ${take.reason}", style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = {
                            onApproveSilences(listOf(TimeRangeMs(take.redundantStartMs, take.redundantEndMs, "Repeated take")))
                        }) {
                            Text("Cut Redundant Take (${TimeUtils.formatDuration(take.redundantStartMs)})")
                        }
                    }
                }
            }
        }

        if (filtered.isEmpty()) {
            Text(
                text = "No transcript segments yet. Run AI Auto-Create or import an .SRT file in Captions.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Text(
                text = "Text-Based Video Editing: Tap cut icon to remove a spoken section from the real MP4 export.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            filtered.forEach { seg ->
                Surface(
                    onClick = { onSeekTo(seg.startMs) },
                    shape = RoundedCornerShape(12.dp),
                    color = if (seg.isRemoved) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
                    else MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${TimeUtils.formatDuration(seg.startMs)} • ${seg.speakerLabel}${if (seg.isRemoved) " [CUT FROM VIDEO]" else ""}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (seg.isRemoved) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            )
                            Text(seg.text, style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = {
                            onCreateClipFromSegment("Clip: ${seg.text.take(24)}", seg.startMs, seg.endMs + 15_000L)
                        }) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = "Create clip from result")
                        }
                        IconButton(onClick = { onToggleSegmentRemoved(seg) }) {
                            Icon(
                                imageVector = if (seg.isRemoved) Icons.Rounded.Close else Icons.Rounded.ContentCut,
                                contentDescription = if (seg.isRemoved) "Restore segment" else "Cut segment from video",
                                tint = if (seg.isRemoved) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AudioAndBRollTab(
    project: ProjectEntity,
    timeline: ClipEditTimeline,
    chapters: List<VideoChapter>,
    bRollSuggestions: List<BRollSuggestionDto>,
    isBusy: Boolean,
    onUpdateTimeline: ((ClipEditTimeline) -> ClipEditTimeline) -> Unit,
    onPickBgm: () -> Unit,
    onPickBRoll: () -> Unit,
    onRemoveBRoll: (String) -> Unit,
    onAnalyzeBRoll: () -> Unit,
    onJumpToChapter: (VideoChapter) -> Unit,
    onCreateClipFromChapter: (VideoChapter) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Audio Enhancement & Mixing", style = MaterialTheme.typography.titleSmall)
                Text("Source Voice Volume: ${(timeline.audioGain * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = timeline.audioGain,
                    onValueChange = { g -> onUpdateTimeline { it.copy(audioGain = g) } },
                    valueRange = 0f..2.0f
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Voice Enhancement", modifier = Modifier.weight(1f))
                    Switch(checked = timeline.voiceEnhancement, onCheckedChange = { v -> onUpdateTimeline { it.copy(voiceEnhancement = v) } })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Normalize Audio", modifier = Modifier.weight(1f))
                    Switch(checked = timeline.normalizeAudio, onCheckedChange = { v -> onUpdateTimeline { it.copy(normalizeAudio = v) } })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Background Music Ducking", modifier = Modifier.weight(1f))
                    Switch(checked = timeline.bgmDucking, onCheckedChange = { v -> onUpdateTimeline { it.copy(bgmDucking = v) } })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onPickBgm) {
                        Icon(Icons.Rounded.MusicNote, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (timeline.bgmUri == null) "Add User Audio/BGM" else "Replace BGM")
                    }
                    if (timeline.bgmUri != null) {
                        TextButton(onClick = { onUpdateTimeline { it.copy(bgmUri = null, bgmTitle = null) } }) {
                            Text("Remove BGM")
                        }
                    }
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("User B-Roll & AI Cues", style = MaterialTheme.typography.titleSmall)
                    Row {
                        TextButton(onClick = onAnalyzeBRoll, enabled = !isBusy) { Text("AI Cues") }
                        TextButton(onClick = onPickBRoll) { Text("+ Add Media") }
                    }
                }
                timeline.bRollOverlays.forEach { br ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${br.title} (${TimeUtils.formatDuration(br.startMs)}–${TimeUtils.formatDuration(br.endMs)})", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        IconButton(onClick = { onRemoveBRoll(br.id) }) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Remove B-roll")
                        }
                    }
                }
                bRollSuggestions.forEach { cue ->
                    Text(
                        "• ${TimeUtils.formatDuration(cue.startMs)}: ${cue.topic} — ${cue.visualPrompt}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (project.summaryText.isNotBlank() || chapters.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("AI Summary & Chapters (AI-Generated)", style = MaterialTheme.typography.titleSmall)
                    if (project.summaryText.isNotBlank()) {
                        Text(project.summaryText, style = MaterialTheme.typography.bodySmall)
                    }
                    chapters.forEach { ch ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { onJumpToChapter(ch) }, modifier = Modifier.weight(1f)) {
                                Text("${TimeUtils.formatDuration(ch.startMs)} • ${ch.title}")
                            }
                            TextButton(onClick = { onCreateClipFromChapter(ch) }) {
                                Text("Clip")
                            }
                        }
                    }
                }
            }
        }
    }
}
