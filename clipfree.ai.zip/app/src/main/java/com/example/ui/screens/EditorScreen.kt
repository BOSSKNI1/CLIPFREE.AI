package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Queue
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.R
import com.example.core.TimeUtils
import com.example.data.local.BrandKitEntity
import com.example.data.local.CreatorTemplateEntity
import com.example.data.local.ExportStatus
import com.example.data.model.AspectRatioOption
import com.example.data.model.CaptionAnimationStyle
import com.example.data.model.DeviceCapabilities
import com.example.data.model.ExportResolution
import com.example.ui.viewmodel.EditorViewModel
import com.example.video.CheckSeverity
import com.example.video.VideoExportEngine
import kotlinx.coroutines.delay
import java.io.File

private enum class EditorTab(val title: String) {
    CLIPS("Clips"),
    TIMELINE("Timeline"),
    CAPTIONS("Captions"),
    REFRAME("Reframe"),
    TRANSCRIPT("Transcript"),
    AUDIO("Audio & B-Roll")
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EditorScreen(
    projectId: Long,
    initialClipId: Long?,
    brandKits: List<BrandKitEntity>,
    templates: List<CreatorTemplateEntity>,
    deviceCapabilities: DeviceCapabilities,
    defaultResolutionId: String,
    onNavigateBack: () -> Unit,
    onShowMessage: (String) -> Unit,
    editorViewModel: EditorViewModel = viewModel()
) {
    val context = LocalContext.current
    LaunchedEffect(projectId, initialClipId) {
        editorViewModel.loadProject(projectId, initialClipId)
    }

    LaunchedEffect(Unit) {
        editorViewModel.events.collect { msg -> onShowMessage(msg) }
    }

    val project by editorViewModel.project.collectAsStateWithLifecycle()
    val clips by editorViewModel.clips.collectAsStateWithLifecycle()
    val selectedClip by editorViewModel.selectedClip.collectAsStateWithLifecycle()
    val transcript by editorViewModel.transcript.collectAsStateWithLifecycle()
    val timeline by editorViewModel.timeline.collectAsStateWithLifecycle()
    val captionStyle by editorViewModel.captionStyle.collectAsStateWithLifecycle()
    val chapters by editorViewModel.chapters.collectAsStateWithLifecycle()
    val detectedSilences by editorViewModel.detectedSilences.collectAsStateWithLifecycle()
    val hooksResult by editorViewModel.hooksAndMetadata.collectAsStateWithLifecycle()
    val bRollSuggestions by editorViewModel.bRollSuggestions.collectAsStateWithLifecycle()
    val repeatedTakes by editorViewModel.repeatedTakes.collectAsStateWithLifecycle()
    val qualityIssues by editorViewModel.qualityIssues.collectAsStateWithLifecycle()
    val isAiBusy by editorViewModel.isAiBusy.collectAsStateWithLifecycle()
    val canUndo by editorViewModel.canUndo.collectAsStateWithLifecycle()
    val canRedo by editorViewModel.canRedo.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showBatchExportDialog by remember { mutableStateOf(false) }
    var showSafeZones by remember { mutableStateOf(true) }
    var playheadMs by remember { mutableLongStateOf(0L) }
    var isScrubbing by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }
    var didInitialClipSeek by remember(project?.sourceUri, selectedClip?.id) { mutableStateOf(false) }
    var selectedExportRes by remember(defaultResolutionId) {
        mutableStateOf(ExportResolution.fromId(defaultResolutionId))
    }

    val bgmLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            editorViewModel.updateTimeline { it.copy(bgmUri = uri.toString(), bgmTitle = "User Audio") }
        }
    }

    val bRollLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            editorViewModel.addUserBRollOverlay(uri, playheadMs, playheadMs + 3000L)
        }
    }

    val srtImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) editorViewModel.importSrtFile(uri)
    }

    // Real Media3 ExoPlayer instance scoped to this screen
    val exoPlayer = remember(context) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && !didInitialClipSeek) {
                    val target = timeline.trimStartMs.takeIf { it > 0L } ?: selectedClip?.startMs ?: 0L
                    if (target > 0L) {
                        exoPlayer.seekTo(target)
                        playheadMs = target
                    }
                    didInitialClipSeek = true
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    LaunchedEffect(project?.sourceUri) {
        val uriStr = project?.sourceUri ?: return@LaunchedEffect
        runCatching {
            exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(uriStr)))
            exoPlayer.prepare()
        }
    }

    LaunchedEffect(Unit) {
        editorViewModel.seekRequestMs.collect { posMs ->
            exoPlayer.seekTo(posMs)
            playheadMs = posMs
        }
    }

    // Poll playhead position smoothly for timeline scrub & live caption sync
    LaunchedEffect(exoPlayer, timeline.trimStartMs, timeline.trimEndMs) {
        while (true) {
            if (!isScrubbing) {
                val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                playheadMs = pos
                val trimEnd = timeline.trimEndMs
                if (exoPlayer.isPlaying && trimEnd > timeline.trimStartMs && pos >= trimEnd) {
                    exoPlayer.seekTo(timeline.trimStartMs)
                }
            }
            delay(80L)
        }
    }

    val currentProject = project
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = currentProject?.title ?: "Video Studio",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleMedium
                        )
                        selectedClip?.let {
                            Text(
                                text = it.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { editorViewModel.undo() }, enabled = canUndo) {
                        Icon(Icons.AutoMirrored.Rounded.Undo, contentDescription = "Undo")
                    }
                    IconButton(onClick = { editorViewModel.redo() }, enabled = canRedo) {
                        Icon(Icons.AutoMirrored.Rounded.Redo, contentDescription = "Redo")
                    }
                    if (clips.size > 1) {
                        IconButton(onClick = { showBatchExportDialog = true }) {
                            Icon(Icons.Rounded.Queue, contentDescription = "Batch Export")
                        }
                    }
                    Button(
                        onClick = {
                            if (selectedClip != null) {
                                editorViewModel.runQualityCheck(selectedExportRes)
                                showExportDialog = true
                            } else {
                                onShowMessage("Create or select a clip below before exporting.")
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("editor_export_button")
                    ) {
                        Icon(Icons.Rounded.Download, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Export")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (currentProject == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Text("Loading project...")
            }
            return@Scaffold
        }

        val activeAspect = AspectRatioOption.fromId(selectedClip?.aspectRatio ?: currentProject.aspectRatio)
        val previewRatio = (activeAspect.widthRatio.toFloat() / activeAspect.heightRatio.toFloat())
            .coerceIn(0.45f, 1.85f)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Video Preview Stage with Live Aspect Ratio & Animated Caption Overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(265.dp)
                    .background(Color(0xFF0F0D16)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .height(250.dp)
                        .aspectRatio(previewRatio)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                        .then(
                            if (showSafeZones) Modifier.border(
                                1.dp,
                                Color.White.copy(alpha = 0.25f),
                                RoundedCornerShape(12.dp)
                            ) else Modifier
                        )
                ) {
                    AndroidView(
                        factory = { ctx ->
                            (LayoutInflater.from(ctx).inflate(
                                R.layout.editor_player_view,
                                null,
                                false
                            ) as PlayerView).apply {
                                player = exoPlayer
                                useController = false
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                rotationZ = timeline.rotationDegrees.toFloat()
                                scaleX = timeline.zoomScale
                                scaleY = timeline.zoomScale
                                translationX = timeline.cropOffsetX * size.width
                            }
                    )

                    // Live Caption Preview synced to playheadMs
                    if (captionStyle.enabled) {
                        val activeSeg = transcript.firstOrNull {
                            !it.isRemoved && playheadMs in it.startMs..it.endMs
                        }
                        if (activeSeg != null) {
                            val style = CaptionAnimationStyle.fromId(captionStyle.styleId)
                            val previewText = if (style == CaptionAnimationStyle.WORD_BY_WORD) {
                                val words = activeSeg.text.trim().split(Regex("\\s+"))
                                val frac = ((playheadMs - activeSeg.startMs).toFloat() /
                                    (activeSeg.endMs - activeSeg.startMs).coerceAtLeast(1L)).coerceIn(0f, 0.999f)
                                words.getOrElse((frac * words.size).toInt()) { activeSeg.text }
                            } else {
                                activeSeg.text
                            }
                            val bgAlpha = if (style == CaptionAnimationStyle.MINIMAL) 0f else captionStyle.backgroundAlpha
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(
                                        horizontal = 12.dp,
                                        vertical = ((1f - captionStyle.positionYFraction).coerceIn(0.06f, 0.7f) * 180).dp
                                    )
                                    .background(
                                        Color.Black.copy(alpha = bgAlpha),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = previewText,
                                    color = Color.White,
                                    fontSize = (captionStyle.fontSizeSp * 0.62f).sp,
                                    fontWeight = if (style == CaptionAnimationStyle.MINIMAL) FontWeight.Normal else FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    if (timeline.watermarkText.isNotBlank()) {
                        Text(
                            text = timeline.watermarkText,
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                        )
                    }
                }
            }

            // Transport & Scrub Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                }) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play"
                    )
                }
                Text(
                    text = TimeUtils.formatPreciseTimecode(playheadMs),
                    style = MaterialTheme.typography.labelSmall
                )
                Slider(
                    value = playheadMs.toFloat().coerceIn(0f, currentProject.durationMs.toFloat().coerceAtLeast(1000f)),
                    onValueChange = { pos ->
                        isScrubbing = true
                        playheadMs = pos.toLong()
                    },
                    onValueChangeFinished = {
                        exoPlayer.seekTo(playheadMs)
                        isScrubbing = false
                    },
                    valueRange = 0f..currentProject.durationMs.toFloat().coerceAtLeast(1000f),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                )
                Text(
                    text = TimeUtils.formatDuration(currentProject.durationMs),
                    style = MaterialTheme.typography.labelSmall
                )
            }

            // Tool Tabs
            ScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 8.dp) {
                EditorTab.entries.forEachIndexed { idx, tab ->
                    Tab(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        text = { Text(tab.title) }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    when (EditorTab.entries[selectedTab]) {
                        EditorTab.CLIPS -> ClipsEditorTab(
                            project = currentProject,
                            clips = clips,
                            selectedClip = selectedClip,
                            hooksResult = hooksResult,
                            isAiBusy = isAiBusy,
                            onSelectClip = { editorViewModel.selectClip(it) },
                            onCreateDefaultClip = { editorViewModel.createDefault30sClip() },
                            onCreateManualClip = { title, s, e -> editorViewModel.createClipFromRange(title, s, e) },
                            onDeleteClip = { editorViewModel.deleteSelectedClip() },
                            onMergeWithNext = { editorViewModel.mergeWithNextClip() },
                            onGenerateHooks = { editorViewModel.generateHooksAndTitles() },
                            onUpdateClipTitleAndCaption = { title, cap ->
                                editorViewModel.updateClipMetadata(title = title, caption = cap)
                            }
                        )

                        EditorTab.TIMELINE -> TimelineEditorTab(
                            project = currentProject,
                            timeline = timeline,
                            playheadMs = playheadMs,
                            brandKits = brandKits,
                            templates = templates,
                            onUpdateTimeline = { editorViewModel.updateTimeline(it) },
                            onSplitAtPlayhead = { editorViewModel.splitClipAt(playheadMs) },
                            onApplyBrandKit = { editorViewModel.applyBrandKit(it) },
                            onApplyTemplate = { editorViewModel.applyTemplate(it) }
                        )

                        EditorTab.CAPTIONS -> CaptionsEditorTab(
                            captionStyle = captionStyle,
                            onUpdateStyle = { editorViewModel.updateCaptionStyle(it) },
                            onExportSubtitles = { fmt ->
                                editorViewModel.exportSubtitles(fmt) { file ->
                                    val share = VideoExportEngine.createShareFileIntent(context, file, fmt.mimeType)
                                    context.startActivity(Intent.createChooser(share, "Share ${fmt.label}"))
                                }
                            },
                            onImportSrt = { srtImportLauncher.launch(arrayOf("*/*")) }
                        )

                        EditorTab.REFRAME -> ReframeAndCoverTab(
                            selectedClip = selectedClip,
                            timeline = timeline,
                            playheadMs = playheadMs,
                            onChangeAspectRatio = { ratio -> editorViewModel.updateClipMetadata(aspectRatio = ratio) },
                            onUpdateTimeline = { editorViewModel.updateTimeline(it) },
                            onGenerateCover = { ts, t, sub, aspect, layout, color ->
                                editorViewModel.generateAndSaveCover(ts, t, sub, aspect, layout, color) { file ->
                                    val share = VideoExportEngine.createShareFileIntent(context, file, "image/png")
                                    context.startActivity(Intent.createChooser(share, "Share Cover Image"))
                                }
                            }
                        )

                        EditorTab.TRANSCRIPT -> TranscriptAndSearchTab(
                            transcript = transcript,
                            detectedSilences = detectedSilences,
                            repeatedTakes = repeatedTakes,
                            isBusy = isAiBusy,
                            onSeekTo = { editorViewModel.seekTo(it) },
                            onToggleSegmentRemoved = { editorViewModel.toggleTranscriptSegmentRemoved(it) },
                            onCreateClipFromSegment = { title, s, e -> editorViewModel.createClipFromRange(title, s, e) },
                            onDetectSilences = { editorViewModel.runLocalSilenceDetection() },
                            onApproveSilences = { editorViewModel.approveSilenceRemoval(it) },
                            onTranslateTranscript = { editorViewModel.translateTranscript(it) },
                            onAnalyzeRepeatedTakes = { editorViewModel.analyzeBRollAndTakes() }
                        )

                        EditorTab.AUDIO -> AudioAndBRollTab(
                            project = currentProject,
                            timeline = timeline,
                            chapters = chapters,
                            bRollSuggestions = bRollSuggestions,
                            isBusy = isAiBusy,
                            onUpdateTimeline = { editorViewModel.updateTimeline(it) },
                            onPickBgm = { bgmLauncher.launch(arrayOf("audio/*")) },
                            onPickBRoll = { bRollLauncher.launch(arrayOf("video/*", "image/*")) },
                            onRemoveBRoll = { editorViewModel.removeBRollOverlay(it) },
                            onAnalyzeBRoll = { editorViewModel.analyzeBRollAndTakes() },
                            onJumpToChapter = { editorViewModel.seekTo(it.startMs) },
                            onCreateClipFromChapter = { ch ->
                                editorViewModel.createClipFromRange(ch.title, ch.startMs, ch.endMs)
                            }
                        )
                    }
                }
            }
        }
    }

    // Export MP4 + Quality Check Dialog
    if (showExportDialog && currentProject != null) {
        val activeClip = selectedClip
        val clipDur = activeClip?.let {
            (timeline.trimEndMs.takeIf { e -> e > timeline.trimStartMs } ?: it.endMs) -
                timeline.trimStartMs.coerceAtLeast(it.startMs)
        } ?: 15_000L
        val estBytes = VideoExportEngine.estimateFileSizeBytes(clipDur, selectedExportRes)
        val hasBlockingError = qualityIssues.any { it.severity == CheckSeverity.ERROR }

        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("Export MP4 Clip") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Resolution", style = MaterialTheme.typography.titleSmall)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ExportResolution.entries.forEach { res ->
                            val sourceMax = maxOf(currentProject.width, currentProject.height)
                            val supported = res != ExportResolution.RES_4K ||
                                (deviceCapabilities.supports4kEncode && sourceMax >= 2160)
                            FilterChip(
                                selected = selectedExportRes == res,
                                enabled = supported,
                                onClick = {
                                    selectedExportRes = res
                                    editorViewModel.runQualityCheck(res)
                                },
                                label = { Text(if (supported) res.label else "${res.label} (Unsupported)") }
                            )
                        }
                    }

                    Text(
                        text = "Estimated MP4 Size: ~${TimeUtils.formatFileSize(estBytes)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (qualityIssues.isNotEmpty()) {
                        Text("Pre-Export Quality Checks", style = MaterialTheme.typography.titleSmall)
                        qualityIssues.forEach { issue ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (issue.severity == CheckSeverity.ERROR)
                                    MaterialTheme.colorScheme.errorContainer
                                else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Rounded.WarningAmber, null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(issue.title, style = MaterialTheme.typography.labelMedium)
                                    }
                                    Text("${issue.detail} Fix: ${issue.suggestedFix}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }

                    if (activeClip != null) {
                        when (activeClip.exportStatus) {
                            ExportStatus.QUEUED, ExportStatus.EXPORTING -> {
                                Text("Exporting MP4: ${activeClip.exportProgress}%")
                                LinearProgressIndicator(
                                    progress = { (activeClip.exportProgress / 100f).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            ExportStatus.COMPLETED -> {
                                val file = activeClip.exportedFilePath?.let { File(it) }?.takeIf { it.exists() }
                                if (file != null) {
                                    Text(
                                        text = "Export Complete (${TimeUtils.formatFileSize(file.length())}) • Saved to Movies/CLIPFREE.AI",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    OutlinedButton(onClick = {
                                        val share = VideoExportEngine.createShareVideoIntent(
                                            context, file, activeClip.suggestedCaption
                                        )
                                        context.startActivity(Intent.createChooser(share, "Share Short Video"))
                                    }) {
                                        Icon(Icons.Rounded.Share, null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Share to Shorts / Reels / TikTok")
                                    }
                                }
                            }
                            ExportStatus.FAILED -> {
                                Text(
                                    text = activeClip.exportError ?: "Export failed.",
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            else -> Unit
                        }
                    }
                }
            },
            confirmButton = {
                if (activeClip?.exportStatus == ExportStatus.EXPORTING || activeClip?.exportStatus == ExportStatus.QUEUED) {
                    TextButton(onClick = { editorViewModel.cancelExport(activeClip.id) }) {
                        Text("Cancel Export", color = MaterialTheme.colorScheme.error)
                    }
                } else {
                    Button(
                        enabled = !hasBlockingError && activeClip != null,
                        onClick = { editorViewModel.exportSelectedClip(selectedExportRes) }
                    ) { Text("Start MP4 Export") }
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) { Text("Close") }
            }
        )
    }

    if (showBatchExportDialog) {
        var selectedIds by remember(clips) { mutableStateOf(clips.map { it.id }.toSet()) }
        AlertDialog(
            onDismissRequest = { showBatchExportDialog = false },
            title = { Text("Batch Clip Export Queue") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Select clips to export sequentially (${selectedExportRes.label}):", style = MaterialTheme.typography.bodySmall)
                    clips.forEach { clip ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = clip.id in selectedIds,
                                onCheckedChange = { checked ->
                                    selectedIds = if (checked) selectedIds + clip.id else selectedIds - clip.id
                                }
                            )
                            Text(
                                "${clip.title} (${clip.exportStatus})",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = selectedIds.isNotEmpty(),
                    onClick = {
                        editorViewModel.batchExportClips(selectedIds.toList(), selectedExportRes)
                        showBatchExportDialog = false
                    }
                ) { Text("Queue ${selectedIds.size} Clip(s)") }
            },
            dismissButton = {
                TextButton(onClick = { showBatchExportDialog = false }) { Text("Cancel") }
            }
        )
    }
}
