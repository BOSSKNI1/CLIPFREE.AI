package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ClipFreeAppContainer
import com.example.ai.AiResult
import com.example.ai.BRollSuggestionDto
import com.example.ai.MetadataAndHooksResult
import com.example.ai.RepeatedTakeSuggestionDto
import com.example.data.local.BrandKitEntity
import com.example.data.local.CreatorTemplateEntity
import com.example.data.local.GeneratedClipEntity
import com.example.data.local.LibraryAssetEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.TranscriptSegmentEntity
import com.example.data.model.AspectRatioOption
import com.example.data.model.BRollOverlaySpec
import com.example.data.model.CaptionStyleConfig
import com.example.data.model.ClipEditTimeline
import com.example.data.model.ExportResolution
import com.example.data.model.TimeRangeMs
import com.example.data.model.VideoChapter
import com.example.video.CoverGenerator
import com.example.video.CoverLayoutStyle
import com.example.video.ExportQualityChecker
import com.example.video.QualityCheckIssue
import com.example.video.SubtitleExporter
import com.example.video.SubtitleFormat
import com.example.video.VideoInspector
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

data class EditorSnapshot(
    val clip: GeneratedClipEntity,
    val timeline: ClipEditTimeline,
    val captionStyle: CaptionStyleConfig
)

class EditorViewModel(application: Application) : AndroidViewModel(application) {
    private val container = ClipFreeAppContainer.get(application)
    private val repository = container.repository
    private val json = Json { ignoreUnknownKeys = true }

    private val _projectId = MutableStateFlow(-1L)
    private val _selectedClipId = MutableStateFlow<Long?>(null)

    private val _project = MutableStateFlow<ProjectEntity?>(null)
    val project: StateFlow<ProjectEntity?> = _project.asStateFlow()

    private val _clips = MutableStateFlow<List<GeneratedClipEntity>>(emptyList())
    val clips: StateFlow<List<GeneratedClipEntity>> = _clips.asStateFlow()

    private val _transcript = MutableStateFlow<List<TranscriptSegmentEntity>>(emptyList())
    val transcript: StateFlow<List<TranscriptSegmentEntity>> = _transcript.asStateFlow()

    val selectedClip: StateFlow<GeneratedClipEntity?> = combine(_clips, _selectedClipId) { list, id ->
        list.firstOrNull { it.id == id } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _timeline = MutableStateFlow(ClipEditTimeline())
    val timeline: StateFlow<ClipEditTimeline> = _timeline.asStateFlow()

    private val _captionStyle = MutableStateFlow(CaptionStyleConfig())
    val captionStyle: StateFlow<CaptionStyleConfig> = _captionStyle.asStateFlow()

    private val _chapters = MutableStateFlow<List<VideoChapter>>(emptyList())
    val chapters: StateFlow<List<VideoChapter>> = _chapters.asStateFlow()

    private val _detectedSilences = MutableStateFlow<List<TimeRangeMs>>(emptyList())
    val detectedSilences: StateFlow<List<TimeRangeMs>> = _detectedSilences.asStateFlow()

    private val _hooksAndMetadata = MutableStateFlow<MetadataAndHooksResult?>(null)
    val hooksAndMetadata: StateFlow<MetadataAndHooksResult?> = _hooksAndMetadata.asStateFlow()

    private val _bRollSuggestions = MutableStateFlow<List<BRollSuggestionDto>>(emptyList())
    val bRollSuggestions: StateFlow<List<BRollSuggestionDto>> = _bRollSuggestions.asStateFlow()

    private val _repeatedTakes = MutableStateFlow<List<RepeatedTakeSuggestionDto>>(emptyList())
    val repeatedTakes: StateFlow<List<RepeatedTakeSuggestionDto>> = _repeatedTakes.asStateFlow()

    private val _qualityIssues = MutableStateFlow<List<QualityCheckIssue>>(emptyList())
    val qualityIssues: StateFlow<List<QualityCheckIssue>> = _qualityIssues.asStateFlow()

    private val _isAiBusy = MutableStateFlow(false)
    val isAiBusy: StateFlow<Boolean> = _isAiBusy.asStateFlow()

    private val _seekRequestMs = MutableSharedFlow<Long>(extraBufferCapacity = 8)
    val seekRequestMs: SharedFlow<Long> = _seekRequestMs.asSharedFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val events: SharedFlow<String> = _events.asSharedFlow()

    private val undoStack = ArrayDeque<EditorSnapshot>()
    private val redoStack = ArrayDeque<EditorSnapshot>()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    private var syncedClipId: Long? = null
    private var lastUndoTag: String? = null
    private var lastUndoTimeMs: Long = 0L

    fun loadProject(projectId: Long, initialClipId: Long? = null) {
        if (_projectId.value == projectId && initialClipId == null) return
        _projectId.value = projectId
        syncedClipId = null
        if (initialClipId != null) _selectedClipId.value = initialClipId

        viewModelScope.launch {
            repository.observeProject(projectId).collect { proj ->
                _project.value = proj
                if (proj != null) {
                    _chapters.value = runCatching {
                        json.decodeFromString<List<VideoChapter>>(proj.chaptersJson)
                    }.getOrDefault(emptyList())
                }
            }
        }
        viewModelScope.launch {
            repository.observeClipsForProject(projectId).collect { clipList ->
                _clips.value = clipList
                val active = clipList.firstOrNull { it.id == _selectedClipId.value } ?: clipList.firstOrNull()
                if (active == null) {
                    _selectedClipId.value = null
                    syncedClipId = null
                } else if (_selectedClipId.value != active.id) {
                    selectClip(active)
                } else if (syncedClipId != active.id) {
                    syncedClipId = active.id
                    syncTimelineAndStyleFromClip(active)
                }
            }
        }
        viewModelScope.launch {
            repository.observeTranscript(projectId).collect { segs ->
                _transcript.value = segs
            }
        }
    }

    fun selectClip(clip: GeneratedClipEntity) {
        _selectedClipId.value = clip.id
        syncedClipId = clip.id
        undoStack.clear()
        redoStack.clear()
        lastUndoTag = null
        lastUndoTimeMs = 0L
        updateUndoRedoFlags()
        syncTimelineAndStyleFromClip(clip)
        _seekRequestMs.tryEmit(_timeline.value.trimStartMs.takeIf { it > 0L } ?: clip.startMs)
    }

    private fun syncTimelineAndStyleFromClip(clip: GeneratedClipEntity) {
        val tl = runCatching {
            json.decodeFromString<ClipEditTimeline>(clip.editTimelineJson)
        }.getOrDefault(ClipEditTimeline(trimStartMs = clip.startMs, trimEndMs = clip.endMs))
        val fixedTl = if (tl.trimEndMs <= tl.trimStartMs) {
            tl.copy(trimStartMs = clip.startMs, trimEndMs = clip.endMs)
        } else tl
        _timeline.value = fixedTl

        val style = runCatching {
            json.decodeFromString<CaptionStyleConfig>(clip.captionStyleJson)
        }.getOrDefault(CaptionStyleConfig())
        _captionStyle.value = style
    }

    private fun pushUndoSnapshot(editTag: String = "edit") {
        val currentClip = selectedClip.value ?: return
        val now = System.currentTimeMillis()
        if (editTag == lastUndoTag && (now - lastUndoTimeMs) < 1200L) {
            lastUndoTimeMs = now
            return
        }
        lastUndoTag = editTag
        lastUndoTimeMs = now
        undoStack.addLast(EditorSnapshot(currentClip, _timeline.value, _captionStyle.value))
        if (undoStack.size > 30) undoStack.removeFirst()
        redoStack.clear()
        updateUndoRedoFlags()
    }

    private fun updateUndoRedoFlags() {
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        val currentClip = selectedClip.value
        if (currentClip != null) {
            redoStack.addLast(EditorSnapshot(currentClip, _timeline.value, _captionStyle.value))
        }
        lastUndoTag = null
        lastUndoTimeMs = 0L
        updateUndoRedoFlags()
        applySnapshot(prev)
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        val currentClip = selectedClip.value
        if (currentClip != null) {
            undoStack.addLast(EditorSnapshot(currentClip, _timeline.value, _captionStyle.value))
        }
        lastUndoTag = null
        lastUndoTimeMs = 0L
        updateUndoRedoFlags()
        applySnapshot(next)
    }

    private fun applySnapshot(snapshot: EditorSnapshot) {
        _timeline.value = snapshot.timeline
        _captionStyle.value = snapshot.captionStyle
        viewModelScope.launch { repository.saveClipChanges(snapshot.clip) }
    }

    fun updateTimeline(transform: (ClipEditTimeline) -> ClipEditTimeline) {
        val currentClip = selectedClip.value ?: return
        pushUndoSnapshot("timeline")
        val updatedTl = transform(_timeline.value)
        _timeline.value = updatedTl
        val updatedClip = currentClip.copy(
            startMs = updatedTl.trimStartMs.coerceAtLeast(0L),
            endMs = updatedTl.trimEndMs.coerceAtLeast(updatedTl.trimStartMs + 500L),
            editTimelineJson = json.encodeToString(updatedTl)
        )
        viewModelScope.launch { repository.saveClipChanges(updatedClip) }
    }

    fun updateCaptionStyle(transform: (CaptionStyleConfig) -> CaptionStyleConfig) {
        val currentClip = selectedClip.value ?: return
        pushUndoSnapshot("caption_style")
        val updatedStyle = transform(_captionStyle.value)
        _captionStyle.value = updatedStyle
        val updatedClip = currentClip.copy(
            captionStyleJson = json.encodeToString(updatedStyle)
        )
        viewModelScope.launch { repository.saveClipChanges(updatedClip) }
    }

    fun updateClipMetadata(
        title: String? = null,
        caption: String? = null,
        hashtags: List<String>? = null,
        aspectRatio: AspectRatioOption? = null
    ) {
        val currentClip = selectedClip.value ?: return
        pushUndoSnapshot("metadata")
        val updated = currentClip.copy(
            title = title ?: currentClip.title,
            suggestedCaption = caption ?: currentClip.suggestedCaption,
            hashtagsJson = hashtags?.let { json.encodeToString(it) } ?: currentClip.hashtagsJson,
            aspectRatio = aspectRatio?.id ?: currentClip.aspectRatio
        )
        viewModelScope.launch { repository.saveClipChanges(updated) }
    }

    fun splitClipAt(playheadMs: Long) {
        val currentClip = selectedClip.value ?: return
        val tl = _timeline.value
        val start = tl.trimStartMs
        val end = tl.trimEndMs
        if (playheadMs <= start + 1000L || playheadMs >= end - 1000L) {
            _events.tryEmit("Move playhead at least 1s away from start/end to split.")
            return
        }
        viewModelScope.launch {
            val leftTl = tl.copy(trimEndMs = playheadMs)
            _timeline.value = leftTl
            val leftClip = currentClip.copy(
                title = "${currentClip.title} (Part 1)",
                endMs = playheadMs,
                editTimelineJson = json.encodeToString(leftTl)
            )
            repository.saveClipChanges(leftClip)

            val rightTl = tl.copy(trimStartMs = playheadMs, trimEndMs = end)
            val rightClip = currentClip.copy(
                id = 0,
                title = "${currentClip.title} (Part 2)",
                startMs = playheadMs,
                endMs = end,
                exportedFilePath = null,
                exportedUri = null,
                editTimelineJson = json.encodeToString(rightTl)
            )
            repository.saveClipChanges(rightClip)
            _events.tryEmit("Split clip at ${com.example.core.TimeUtils.formatDuration(playheadMs)}.")
        }
    }

    fun mergeWithNextClip() {
        val currentClip = selectedClip.value ?: return
        val ordered = _clips.value.sortedBy { it.startMs }
        val idx = ordered.indexOfFirst { it.id == currentClip.id }
        if (idx == -1 || idx >= ordered.lastIndex) {
            _events.tryEmit("Select a clip that has a following clip to merge.")
            return
        }
        val next = ordered[idx + 1]
        viewModelScope.launch {
            val newStart = minOf(currentClip.startMs, next.startMs)
            val newEnd = maxOf(currentClip.endMs, next.endMs)
            val mergedTl = _timeline.value.copy(trimStartMs = newStart, trimEndMs = newEnd)
            _timeline.value = mergedTl
            val merged = currentClip.copy(
                title = "${currentClip.title} + Merged",
                startMs = newStart,
                endMs = newEnd,
                editTimelineJson = json.encodeToString(mergedTl)
            )
            repository.saveClipChanges(merged)
            repository.deleteClip(next.id)
            _events.tryEmit("Merged clips into single timeline.")
        }
    }

    fun deleteSelectedClip() {
        val currentClip = selectedClip.value ?: return
        viewModelScope.launch {
            repository.deleteClip(currentClip.id)
            _events.tryEmit("Clip deleted.")
        }
    }

    fun createDefault30sClip() {
        val proj = _project.value ?: return
        val endMs = minOf(proj.durationMs, 30_000L).coerceAtLeast(1000L)
        createClipFromRange("${proj.title} — Clip 1", 0L, endMs)
    }

    fun createClipFromRange(title: String, startMs: Long, endMs: Long) {
        val proj = _project.value ?: return
        viewModelScope.launch {
            val aspect = AspectRatioOption.fromId(proj.aspectRatio)
            val res = repository.createManualClip(
                projectId = proj.id,
                title = title,
                startMs = startMs,
                endMs = endMs,
                aspectRatio = aspect,
                captionStyle = _captionStyle.value
            )
            res.onSuccess { created ->
                selectClip(created)
                _events.tryEmit("Created clip \"${created.title}\".")
            }
        }
    }

    /**
     * Text-Based Video Editing: removing a transcript segment excludes its actual
     * timestamps from the exported video via ClipEditTimeline.excludedRanges.
     */
    fun toggleTranscriptSegmentRemoved(segment: TranscriptSegmentEntity) {
        viewModelScope.launch {
            val nowRemoved = !segment.isRemoved
            repository.updateTranscriptSegment(segment.copy(isRemoved = nowRemoved))
            updateTimeline { tl ->
                val updatedExclusions = if (nowRemoved) {
                    (tl.excludedRanges + TimeRangeMs(segment.startMs, segment.endMs, segment.text.take(24)))
                        .distinctBy { it.startMs to it.endMs }
                } else {
                    tl.excludedRanges.filterNot {
                        it.startMs == segment.startMs && it.endMs == segment.endMs
                    }
                }
                tl.copy(excludedRanges = updatedExclusions)
            }
        }
    }

    fun updateTranscriptSegmentSpeakerOrText(
        segment: TranscriptSegmentEntity,
        newSpeaker: String,
        newText: String
    ) {
        viewModelScope.launch {
            repository.updateTranscriptSegment(
                segment.copy(speakerLabel = newSpeaker.ifBlank { "Speaker 1" }, text = newText)
            )
        }
    }

    fun runLocalSilenceDetection() {
        val proj = _project.value ?: return
        viewModelScope.launch {
            _isAiBusy.value = true
            val silences = repository.detectSilenceLocallyForProject(proj.id)
            _detectedSilences.value = silences
            _isAiBusy.value = false
            _events.tryEmit(
                if (silences.isEmpty()) "No long silence gaps (>0.9s) detected."
                else "Detected ${silences.size} silence/pause interval(s) for review."
            )
        }
    }

    fun approveSilenceRemoval(ranges: List<TimeRangeMs>) {
        if (ranges.isEmpty()) return
        updateTimeline { tl ->
            val combined = (tl.excludedRanges + ranges).distinctBy { it.startMs to it.endMs }
            tl.copy(excludedRanges = combined)
        }
        _detectedSilences.value = emptyList()
        _events.tryEmit("Approved ${ranges.size} silence cut(s) on the export timeline.")
    }

    fun generateHooksAndTitles() {
        val proj = _project.value ?: return
        viewModelScope.launch {
            _isAiBusy.value = true
            when (val res = repository.generateHooksAndMetadata(proj.id)) {
                is AiResult.Success -> {
                    _hooksAndMetadata.value = res.data
                    _events.tryEmit("Generated hooks & titles via ${res.providerName}.")
                }
                is AiResult.Failure -> _events.tryEmit(res.message)
            }
            _isAiBusy.value = false
        }
    }

    fun translateTranscript(targetLanguage: String) {
        val proj = _project.value ?: return
        viewModelScope.launch {
            _isAiBusy.value = true
            when (val res = repository.translateProjectTranscript(proj.id, targetLanguage)) {
                is AiResult.Success -> _events.tryEmit("Translated transcript to $targetLanguage.")
                is AiResult.Failure -> _events.tryEmit(res.message)
            }
            _isAiBusy.value = false
        }
    }

    fun analyzeBRollAndTakes() {
        val proj = _project.value ?: return
        viewModelScope.launch {
            _isAiBusy.value = true
            when (val res = repository.analyzeBRollAndRepeatedTakes(proj.id)) {
                is AiResult.Success -> {
                    _bRollSuggestions.value = res.data.bRollSuggestions
                    _repeatedTakes.value = res.data.repeatedTakes
                    _events.tryEmit(
                        "Found ${res.data.bRollSuggestions.size} B-roll cue(s) and ${res.data.repeatedTakes.size} repeated take(s)."
                    )
                }
                is AiResult.Failure -> _events.tryEmit(res.message)
            }
            _isAiBusy.value = false
        }
    }

    fun addUserBRollOverlay(uri: Uri, startMs: Long, endMs: Long) {
        val name = VideoInspector.resolveDisplayName(getApplication(), uri)
        updateTimeline { tl ->
            val item = BRollOverlaySpec(
                id = UUID.randomUUID().toString(),
                mediaUri = uri.toString(),
                title = name,
                startMs = startMs,
                endMs = endMs.coerceAtLeast(startMs + 1000L)
            )
            tl.copy(bRollOverlays = tl.bRollOverlays + item)
        }
        _events.tryEmit("Added user B-roll \"$name\".")
    }

    fun removeBRollOverlay(id: String) {
        updateTimeline { tl -> tl.copy(bRollOverlays = tl.bRollOverlays.filterNot { it.id == id }) }
    }

    fun applyBrandKit(kit: BrandKitEntity) {
        updateCaptionStyle {
            it.copy(
                styleId = kit.captionStyleId,
                fontName = kit.fontName,
                highlightColorHex = kit.primaryColorHex
            )
        }
        updateTimeline {
            it.copy(
                brandKitId = kit.id,
                introText = kit.introText,
                outroText = kit.outroText,
                watermarkText = if (kit.watermarkEnabled) kit.watermarkText else ""
            )
        }
        _events.tryEmit("Applied brand kit \"${kit.name}\".")
    }

    fun applyTemplate(template: CreatorTemplateEntity) {
        val clip = selectedClip.value ?: return
        updateClipMetadata(aspectRatio = AspectRatioOption.fromId(template.aspectRatio))
        updateCaptionStyle {
            it.copy(
                styleId = template.captionStyleId,
                fontName = template.fontName,
                highlightColorHex = template.accentColorHex
            )
        }
        updateTimeline {
            it.copy(
                autoZoomEnabled = template.autoZoomEnabled,
                introText = template.introText,
                outroText = template.outroText
            )
        }
        _events.tryEmit("Applied template \"${template.name}\".")
    }

    fun exportSubtitles(format: SubtitleFormat, onReady: (File) -> Unit) {
        val proj = _project.value ?: return
        val segs = _transcript.value
        if (segs.isEmpty()) {
            _events.tryEmit("No transcript segments to export.")
            return
        }
        viewModelScope.launch {
            val content = when (format) {
                SubtitleFormat.SRT -> SubtitleExporter.buildSrt(segs)
                SubtitleFormat.VTT -> SubtitleExporter.buildVtt(segs)
                SubtitleFormat.TXT -> SubtitleExporter.buildPlainText(segs)
            }
            val file = SubtitleExporter.saveToAppFiles(getApplication(), proj.title, format, content)
            repository.addLibraryAsset(
                LibraryAssetEntity(
                    projectId = proj.id,
                    assetType = "SUBTITLE",
                    title = file.name,
                    filePathOrUri = file.absolutePath,
                    mimeType = format.mimeType,
                    sizeBytes = file.length()
                )
            )
            onReady(file)
        }
    }

    fun importSrtFile(uri: Uri) {
        val proj = _project.value ?: return
        viewModelScope.launch {
            val content = runCatching {
                getApplication<Application>().contentResolver.openInputStream(uri)?.bufferedReader()?.use {
                    it.readText()
                }
            }.getOrNull()
            if (content.isNullOrBlank()) {
                _events.tryEmit("Could not read SRT file.")
                return@launch
            }
            val parsed = SubtitleExporter.parseSrt(content, proj.id)
            if (parsed.isEmpty()) {
                _events.tryEmit("No valid subtitle entries found in SRT.")
            } else {
                repository.importSubtitles(proj.id, parsed)
                _events.tryEmit("Imported ${parsed.size} subtitle lines.")
            }
        }
    }

    fun generateAndSaveCover(
        timestampMs: Long,
        title: String,
        subtitle: String,
        aspectRatio: AspectRatioOption,
        layoutStyle: CoverLayoutStyle,
        accentColorHex: String,
        onSaved: (File) -> Unit
    ) {
        val proj = _project.value ?: return
        viewModelScope.launch {
            val frame = CoverGenerator.extractFrameBitmap(
                getApplication(),
                Uri.parse(proj.sourceUri),
                timestampMs
            )
            if (frame == null) {
                _events.tryEmit("Could not extract frame from source video.")
                return@launch
            }
            val rendered = CoverGenerator.renderCoverBitmap(
                frameBitmap = frame,
                title = title,
                subtitle = subtitle,
                aspectRatio = aspectRatio,
                layoutStyle = layoutStyle,
                accentColorHex = accentColorHex
            )
            frame.recycle()
            val file = CoverGenerator.saveCoverImage(getApplication(), rendered, title)
            rendered.recycle()
            repository.addLibraryAsset(
                LibraryAssetEntity(
                    projectId = proj.id,
                    assetType = "THUMBNAIL",
                    title = file.name,
                    filePathOrUri = file.absolutePath,
                    mimeType = "image/png",
                    sizeBytes = file.length()
                )
            )
            _events.tryEmit("Cover saved to Library.")
            onSaved(file)
        }
    }

    fun runQualityCheck(resolution: ExportResolution) {
        val proj = _project.value ?: return
        val clip = selectedClip.value ?: return
        val caps = VideoInspector.detectDeviceCapabilities(getApplication())
        _qualityIssues.value = ExportQualityChecker.runChecks(
            context = getApplication(),
            project = proj,
            clip = clip,
            timeline = _timeline.value,
            captionStyle = _captionStyle.value,
            resolution = resolution,
            transcript = _transcript.value,
            deviceCaps = caps
        )
    }

    fun exportSelectedClip(resolution: ExportResolution) {
        val clip = selectedClip.value ?: return
        repository.enqueueClipExport(clip.id, resolution, saveToGallery = true)
        _events.tryEmit("Queued MP4 export (${resolution.label}) for \"${clip.title}\".")
    }

    fun batchExportClips(clipIds: List<Long>, resolution: ExportResolution) {
        if (clipIds.isEmpty()) return
        repository.enqueueBatchExport(clipIds, resolution)
        _events.tryEmit("Queued ${clipIds.size} clip(s) for sequential MP4 export.")
    }

    fun cancelExport(clipId: Long) {
        repository.cancelClipExport(clipId)
        _events.tryEmit("Cancelling export...")
    }

    fun seekTo(ms: Long) {
        _seekRequestMs.tryEmit(ms.coerceAtLeast(0L))
    }
}
