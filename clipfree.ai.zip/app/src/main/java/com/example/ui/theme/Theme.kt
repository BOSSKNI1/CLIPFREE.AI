package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

enum class ThemeMode(val label: String) {
    SYSTEM("System Default"),
    LIGHT("Light"),
    DARK("Dark")
}

private val ClipFreeDarkColorScheme = darkColorScheme(
    primary = DarkAccentViolet,
    onPrimary = Color(0xFF120B24),
    primaryContainer = Color(0xFF3E2E7A),
    onPrimaryContainer = DarkSoftLavenderText,
    secondary = DarkSecondaryLavender,
    onSecondary = Color(0xFF1F1638),
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = DarkSoftLavenderText,
    tertiary = Color(0xFF66E3C4),
    onTertiary = Color(0xFF0A2A22),
    background = DarkBackground,
    onBackground = DarkMainText,
    surface = DarkSurface,
    onSurface = DarkMainText,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkSoftLavenderText,
    surfaceContainerLowest = Color(0xFF121018),
    surfaceContainerLow = Color(0xFF1C1926),
    surfaceContainer = DarkSurface,
    surfaceContainerHigh = Color(0xFF2B273B),
    surfaceContainerHighest = Color(0xFF353048),
    outline = DarkOutline,
    outlineVariant = Color(0xFF2E2A40),
    error = Color(0xFFFF6B6B),
    onError = Color(0xFF360808),
    errorContainer = StatusErrorContainerDark,
    onErrorContainer = Color(0xFFFFDADA)
)

private val ClipFreeLightColorScheme = lightColorScheme(
    primary = LightPrimaryViolet,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEDE7FE),
    onPrimaryContainer = Color(0xFF2B1866),
    secondary = LightSecondaryLavender,
    onSecondary = LightMainText,
    secondaryContainer = LightSurfaceVariant,
    onSecondaryContainer = LightMainText,
    tertiary = Color(0xFF0EA5E9),
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = LightMainText,
    surface = LightSurface,
    onSurface = LightMainText,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightMutedText,
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF4F1FA),
    surfaceContainer = LightSurface,
    surfaceContainerHigh = Color(0xFFEBE6F7),
    surfaceContainerHighest = Color(0xFFE2DBF4),
    outline = LightOutline,
    outlineVariant = Color(0xFFE9E4F5),
    error = StatusError,
    onError = Color.White,
    errorContainer = StatusErrorContainerLight,
    onErrorContainer = Color(0xFF7F1D1D)
)

val ClipFreeShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun ClipFreeTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> ClipFreeDarkColorScheme
        else -> ClipFreeLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = ClipFreeShapes,
        content = content
    )
}
