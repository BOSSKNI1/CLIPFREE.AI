package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Tokens
val LightBackground = Color(0xFFF8F7FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEFEBF9)
val LightPrimaryViolet = Color(0xFF7652E8)
val LightSecondaryLavender = Color(0xFFB9A6F6)
val LightMainText = Color(0xFF242136)
val LightMutedText = Color(0xFF5E5A75)
val LightOutline = Color(0xFFDCD6EE)

// Dark Theme Tokens
val DarkBackground = Color(0xFF17151F)
val DarkSurface = Color(0xFF242132)
val DarkSurfaceVariant = Color(0xFF2F2B42)
val DarkAccentViolet = Color(0xFF9878FF)
val DarkSecondaryLavender = Color(0xFFB9A6F6)
val DarkMainText = Color(0xFFFFFFFF)
val DarkSoftLavenderText = Color(0xFFD8D0FA)
val DarkMutedText = Color(0xFFA49BC7)
val DarkOutline = Color(0xFF3A3552)

// Semantic Status Tokens
val StatusSuccess = Color(0xFF16A34A)
val StatusSuccessContainerLight = Color(0xFFDCFCE7)
val StatusSuccessContainerDark = Color(0xFF133A24)
val StatusWarning = Color(0xFFD97706)
val StatusWarningContainerLight = Color(0xFFFEF3C7)
val StatusWarningContainerDark = Color(0xFF422C0E)
val StatusError = Color(0xFFDC2626)
val StatusErrorContainerLight = Color(0xFFFEE2E2)
val StatusErrorContainerDark = Color(0xFF47181A)
val StatusInfo = Color(0xFF2563EB)
