package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.TimeUtils
import com.example.data.local.BrandKitEntity
import com.example.data.local.CreatorTemplateEntity
import com.example.data.local.GeneratedClipEntity
import com.example.data.local.LibraryAssetEntity
import com.example.data.local.ProjectEntity
import com.example.ui.components.VideoThumbnailImage
import com.example.ui.components.ViralityScoreBadge
import com.example.video.VideoExportEngine
import java.io.File

private enum class LibraryFilter(val label: String) {
    ALL("All"),
    CLIPS("Generated Clips"),
    EXPORTS("Exported Videos"),
    PROJECTS("Original Projects"),
    SUBTITLES("Subtitles"),
    THUMBNAILS("Thumbnails"),
    TEMPLATES("Templates"),
    BRAND_KITS("Brand Kits")
}

@Composable
fun LibraryScreen(
    clips: List<GeneratedClipEntity>,
    projects: List<ProjectEntity>,
    assets: List<LibraryAssetEntity>,
    brandKits: List<BrandKitEntity>,
    templates: List<CreatorTemplateEntity>,
    onOpenClipEditor: (Long, Long) -> Unit,
    onDeleteClip: (Long) -> Unit,
    onDeleteAsset: (LibraryAssetEntity) -> Unit,
    onSaveBrandKit: (BrandKitEntity) -> Unit,
    onDeleteBrandKit: (Long) -> Unit,
    onSaveTemplate: (CreatorTemplateEntity) -> Unit,
    onDeleteTemplate: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var filter by remember { mutableStateOf(LibraryFilter.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    var showBrandKitDialog by remember { mutableStateOf(false) }
    var showTemplateDialog by remember { mutableStateOf(false) }
    var confirmDeleteClip by remember { mutableStateOf<GeneratedClipEntity?>(null) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Creator Library", style = MaterialTheme.typography.headlineMedium)
            }

            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search clips, exports, subtitles, templates...") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LibraryFilter.entries.forEach { tab ->
                        FilterChip(
                            selected = filter == tab,
                            onClick = { filter = tab },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }

            if (filter == LibraryFilter.ALL || filter == LibraryFilter.CLIPS || filter == LibraryFilter.EXPORTS) {
                val filteredClips = clips.filter { clip ->
                    val matchesQuery = searchQuery.isBlank() || clip.title.contains(searchQuery, ignoreCase = true)
                    val matchesTab = when (filter) {
                        LibraryFilter.EXPORTS -> !clip.exportedFilePath.isNullOrBlank() && File(clip.exportedFilePath).exists()
                        else -> true
                    }
                    matchesQuery && matchesTab
                }
                if (filteredClips.isNotEmpty()) {
                    item {
                        Text(
                            text = if (filter == LibraryFilter.EXPORTS) "Exported MP4 Videos" else "Clips & Exports",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    items(filteredClips, key = { "clip_${it.id}" }) { clip ->
                        val exportedFile = clip.exportedFilePath?.let { File(it) }?.takeIf { it.exists() }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                VideoThumbnailImage(
                                    thumbnailPath = clip.previewThumbnailPath,
                                    contentDescription = clip.title,
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = clip.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = buildString {
                                            append(TimeUtils.formatDuration(clip.endMs - clip.startMs))
                                            append(" • ${clip.aspectRatio}")
                                            if (exportedFile != null) {
                                                append(" • MP4 (${TimeUtils.formatFileSize(exportedFile.length())})")
                                            }
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    ViralityScoreBadge(clip.viralityScore, clip.isAiGenerated)
                                }
                                IconButton(onClick = { onOpenClipEditor(clip.projectId, clip.id) }) {
                                    Icon(Icons.Rounded.Edit, contentDescription = "Edit clip")
                                }
                                if (exportedFile != null) {
                                    IconButton(
                                        onClick = {
                                            val shareIntent = VideoExportEngine.createShareVideoIntent(
                                                context, exportedFile, clip.suggestedCaption
                                            )
                                            context.startActivity(Intent.createChooser(shareIntent, "Share MP4"))
                                        }
                                    ) {
                                        Icon(Icons.Rounded.Share, contentDescription = "Share exported MP4")
                                    }
                                }
                                IconButton(onClick = { confirmDeleteClip = clip }) {
                                    Icon(
                                        Icons.Rounded.DeleteOutline,
                                        contentDescription = "Delete clip",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (filter == LibraryFilter.ALL || filter == LibraryFilter.SUBTITLES || filter == LibraryFilter.THUMBNAILS) {
                val filteredAssets = assets.filter { asset ->
                    val typeOk = when (filter) {
                        LibraryFilter.SUBTITLES -> asset.assetType == "SUBTITLE"
                        LibraryFilter.THUMBNAILS -> asset.assetType == "THUMBNAIL"
                        else -> asset.assetType == "SUBTITLE" || asset.assetType == "THUMBNAIL" || asset.assetType == "BROLL"
                    }
                    typeOk && (searchQuery.isBlank() || asset.title.contains(searchQuery, ignoreCase = true))
                }
                if (filteredAssets.isNotEmpty()) {
                    item { Text("Subtitles, Thumbnails & Assets", style = MaterialTheme.typography.titleMedium) }
                    items(filteredAssets, key = { "asset_${it.id}" }) { asset ->
                        val file = File(asset.filePathOrUri)
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.Subtitles, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(asset.title, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        text = "${asset.assetType} • ${TimeUtils.formatFileSize(asset.sizeBytes)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (file.exists()) {
                                    IconButton(
                                        onClick = {
                                            val share = VideoExportEngine.createShareFileIntent(context, file, asset.mimeType)
                                            context.startActivity(Intent.createChooser(share, "Share ${asset.title}"))
                                        }
                                    ) {
                                        Icon(Icons.Rounded.Share, contentDescription = "Share file")
                                    }
                                }
                                IconButton(onClick = { onDeleteAsset(asset) }) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete asset")
                                }
                            }
                        }
                    }
                }
            }

            if (filter == LibraryFilter.ALL || filter == LibraryFilter.PROJECTS) {
                val filteredProj = projects.filter {
                    searchQuery.isBlank() || it.title.contains(searchQuery, ignoreCase = true)
                }
                if (filteredProj.isNotEmpty() && filter == LibraryFilter.PROJECTS) {
                    item { Text("Original Projects", style = MaterialTheme.typography.titleMedium) }
                    items(filteredProj, key = { "proj_${it.id}" }) { proj ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                VideoThumbnailImage(proj.thumbnailPath, proj.title, Modifier.size(56.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(proj.title, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "${TimeUtils.formatDuration(proj.durationMs)} • ${proj.width}×${proj.height}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (filter == LibraryFilter.ALL || filter == LibraryFilter.BRAND_KITS) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Brand Kits", style = MaterialTheme.typography.titleMedium)
                        TextButton(onClick = { showBrandKitDialog = true }) {
                            Icon(Icons.Rounded.Add, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("New Preset")
                        }
                    }
                }
                items(brandKits, key = { "kit_${it.id}" }) { kit ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Palette, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(kit.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = "${kit.fontName} • ${kit.captionStyleId} • CTA: ${kit.ctaText}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (!kit.isDefault) {
                                IconButton(onClick = { onDeleteBrandKit(kit.id) }) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete brand kit")
                                }
                            }
                        }
                    }
                }
            }

            if (filter == LibraryFilter.ALL || filter == LibraryFilter.TEMPLATES) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Creator Templates", style = MaterialTheme.typography.titleMedium)
                        TextButton(onClick = { showTemplateDialog = true }) {
                            Icon(Icons.Rounded.Add, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Save Template")
                        }
                    }
                }
                items(templates, key = { "tpl_${it.id}" }) { tpl ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Style, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(tpl.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = "${tpl.category} • ${tpl.aspectRatio} • ${tpl.captionStyleId}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (!tpl.isBuiltIn) {
                                IconButton(onClick = { onDeleteTemplate(tpl.id) }) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete template")
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Text(
                                        "Built-in",
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showBrandKitDialog) {
        var name by remember { mutableStateOf("") }
        var primaryHex by remember { mutableStateOf("#7652E8") }
        var outroText by remember { mutableStateOf("Follow for more!") }
        var watermarkText by remember { mutableStateOf("@creator") }
        var watermarkOn by remember { mutableStateOf(true) }
        AlertDialog(
            onDismissRequest = { showBrandKitDialog = false },
            title = { Text("New Brand Kit") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Preset Name") })
                    OutlinedTextField(value = primaryHex, onValueChange = { primaryHex = it }, label = { Text("Brand Color Hex") })
                    OutlinedTextField(value = outroText, onValueChange = { outroText = it }, label = { Text("Outro / CTA Text") })
                    OutlinedTextField(value = watermarkText, onValueChange = { watermarkText = it }, label = { Text("Watermark") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Enable Watermark", modifier = Modifier.weight(1f))
                        Switch(checked = watermarkOn, onCheckedChange = { watermarkOn = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            onSaveBrandKit(
                                BrandKitEntity(
                                    name = name.trim(),
                                    primaryColorHex = primaryHex,
                                    outroText = outroText,
                                    watermarkEnabled = watermarkOn,
                                    watermarkText = watermarkText
                                )
                            )
                            showBrandKitDialog = false
                        }
                    }
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showBrandKitDialog = false }) { Text("Cancel") } }
        )
    }

    if (showTemplateDialog) {
        var name by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("Custom") }
        var aspect by remember { mutableStateOf("9:16") }
        AlertDialog(
            onDismissRequest = { showTemplateDialog = false },
            title = { Text("Save Creator Template") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Template Name") })
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") })
                    OutlinedTextField(value = aspect, onValueChange = { aspect = it }, label = { Text("Aspect Ratio (9:16, 16:9, 1:1, 4:5)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            onSaveTemplate(
                                CreatorTemplateEntity(
                                    name = name.trim(),
                                    category = category.ifBlank { "Custom" },
                                    captionStyleId = "bold_creator",
                                    fontName = "Space Grotesk",
                                    primaryColorHex = "#7652E8",
                                    accentColorHex = "#9878FF",
                                    aspectRatio = aspect
                                )
                            )
                            showTemplateDialog = false
                        }
                    }
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showTemplateDialog = false }) { Text("Cancel") } }
        )
    }

    confirmDeleteClip?.let { target ->
        AlertDialog(
            onDismissRequest = { confirmDeleteClip = null },
            title = { Text("Delete Clip?") },
            text = { Text("Delete \"${target.title}\"? Your original source video remains untouched.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteClip(target.id)
                        confirmDeleteClip = null
                    }
                ) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDeleteClip = null }) { Text("Cancel") } }
        )
    }
}
