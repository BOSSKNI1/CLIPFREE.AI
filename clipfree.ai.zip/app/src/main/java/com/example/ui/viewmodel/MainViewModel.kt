package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiOverallHealth
import com.example.ai.FailoverSnapshot
import com.example.ai.ProviderStatus
import com.example.ai.ProviderType
import com.example.core.AppPreferences
import com.example.core.QuotaMode
import com.example.core.TimeUtils
import com.example.data.ClipFreeRepository
import com.example.data.cloud.CloudSyncRepository
import com.example.data.cloud.CloudSyncStatus
import com.example.data.cloud.CloudUserProfile
import com.example.data.local.AiProviderConfigEntity
import com.example.data.local.BrandKitEntity
import com.example.data.local.CreatorTemplateEntity
import com.example.data.local.GeneratedClipEntity
import com.example.data.local.LibraryAssetEntity
import com.example.data.local.ProjectEntity
import com.example.data.model.DeviceCapabilities
import com.example.ui.theme.ThemeMode
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface ProfileUiState<out T> {
    data object Loading : ProfileUiState<Nothing>
    data class Success<T>(val data: T) : ProfileUiState<T>
    data class Error(val message: String) : ProfileUiState<Nothing>
}

class MainViewModel(
    val repository: ClipFreeRepository,
    private val cloudSync: CloudSyncRepository,
    private val currentUserId: String,
    private val currentUser: FirebaseUser?,
    private val capabilitiesProvider: () -> DeviceCapabilities
) : ViewModel() {

    val preferences: StateFlow<AppPreferences> = repository.preferences.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppPreferences())

    val projects: StateFlow<List<ProjectEntity>> = repository.projectsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allClips: StateFlow<List<GeneratedClipEntity>> = repository.allClipsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val brandKits: StateFlow<List<BrandKitEntity>> = repository.brandKitsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val templates: StateFlow<List<CreatorTemplateEntity>> = repository.templatesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val providers: StateFlow<List<AiProviderConfigEntity>> = repository.providersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val libraryAssets: StateFlow<List<LibraryAssetEntity>> = repository.libraryAssetsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val failoverSnapshot: StateFlow<FailoverSnapshot> = repository.aiOrchestrator.snapshot

    val cloudSyncStatus: StateFlow<CloudSyncStatus> = cloudSync.syncStatus

    // Two-tier Flow unwrapping: snapshots() wraps FirebaseFirestoreException in CancellationException on error
    val userProfileState: StateFlow<ProfileUiState<CloudUserProfile?>> =
        cloudSync.observeUserProfile(currentUserId)
            .map<CloudUserProfile?, ProfileUiState<CloudUserProfile?>> { ProfileUiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing user profile", rootError)
                emit(ProfileUiState.Error(rootError.message ?: "Failed to load cloud profile"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = ProfileUiState.Loading
            )

    private val _toastMessages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val toastMessages: SharedFlow<String> = _toastMessages.asSharedFlow()

    private val _deviceCapabilities = MutableStateFlow(capabilitiesProvider())
    val deviceCapabilities: StateFlow<DeviceCapabilities> = _deviceCapabilities.asStateFlow()

    private val _storageUsage = MutableStateFlow(0L to 0L)
    val storageUsage: StateFlow<Pair<Long, Long>> = _storageUsage.asStateFlow()

    private val _testingProviderId = MutableStateFlow<String?>(null)
    val testingProviderId: StateFlow<String?> = _testingProviderId.asStateFlow()

    private var activeSyncJob: Job? = null

    init {
        viewModelScope.launch {
            repository.initializeDefaults()
            refreshStorageStats()
            if (currentUser != null && currentUser.uid == currentUserId && currentUserId.isNotBlank()) {
                cloudSync.handleAccountSessionReady(currentUser)
            }
        }
        viewModelScope.launch {
            repository.aiOrchestrator.notifications.collect { msg ->
                _toastMessages.tryEmit(msg)
            }
        }
    }

    fun syncNow() {
        if (activeSyncJob?.isActive == true) return
        activeSyncJob = viewModelScope.launch {
            val res = cloudSync.syncNow()
            res.fold(
                onSuccess = { summary ->
                    _toastMessages.tryEmit(
                        "Cloud backup synced: ${summary.projectsSynced} projects, ${summary.clipsSynced} clips."
                    )
                },
                onFailure = { err ->
                    _toastMessages.tryEmit(err.localizedMessage ?: "Cloud sync failed.")
                }
            )
        }
    }

    fun prepareSignOut() {
        activeSyncJob?.cancel()
        activeSyncJob = null
        cloudSync.resetStatusOnSignOut()
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { repository.preferences.setThemeMode(mode) }
    }

    fun setDynamicColor(enabled: Boolean) {
        viewModelScope.launch { repository.preferences.setDynamicColor(enabled) }
    }

    fun setPreferredLanguage(lang: String) {
        viewModelScope.launch {
            repository.preferences.setPreferredLanguage(lang)
            pushCurrentPreferencesToCloud()
        }
    }

    fun setDefaultResolution(res: String) {
        viewModelScope.launch {
            repository.preferences.setDefaultResolution(res)
            pushCurrentPreferencesToCloud()
        }
    }

    fun setDefaultAspectRatio(aspect: String) {
        viewModelScope.launch {
            repository.preferences.setDefaultAspectRatio(aspect)
            pushCurrentPreferencesToCloud()
        }
    }

    fun setQuotaMode(mode: QuotaMode) {
        viewModelScope.launch {
            repository.preferences.setQuotaMode(mode)
            if (mode == QuotaMode.RETRY_AI) {
                repository.aiOrchestrator.clearCooldowns()
                _toastMessages.tryEmit("Retry AI Mode active. Ready to resume AI analysis.")
            }
            repository.aiOrchestrator.refreshSnapshot()
        }
    }

    fun setAiUploadConsent(granted: Boolean) {
        viewModelScope.launch { repository.preferences.setAiUploadConsent(granted) }
    }

    fun setAutosaveEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setAutosaveEnabled(enabled)
            pushCurrentPreferencesToCloud()
        }
    }

    private suspend fun pushCurrentPreferencesToCloud() {
        val latest = repository.preferences.preferencesFlow.first()
        cloudSync.syncPreferencesToCloud(latest)
    }

    fun refreshStorageStats() {
        viewModelScope.launch {
            _storageUsage.value = repository.calculateStorageUsageBytes()
            _deviceCapabilities.value = capabilitiesProvider()
        }
    }

    fun clearCache() {
        viewModelScope.launch {
            val freed = repository.clearTemporaryCache()
            refreshStorageStats()
            _toastMessages.tryEmit("Cleared ${TimeUtils.formatFileSize(freed)} of temporary cache.")
        }
    }

    fun addOrUpdateAiProvider(
        existingId: String?,
        type: ProviderType,
        displayName: String,
        modelName: String,
        endpointUrl: String,
        priority: Int,
        rawApiKey: String?
    ) {
        viewModelScope.launch {
            val id = existingId ?: "custom_${UUID.randomUUID().toString().take(8)}"
            val existing = existingId?.let { targetId -> providers.value.firstOrNull { it.id == targetId } }
            val hasValidKey = type == ProviderType.FIREBASE_AI_LOGIC ||
                !rawApiKey.isNullOrBlank() ||
                repository.vault.hasApiKey(id)
            val entity = AiProviderConfigEntity(
                id = id,
                providerType = type.id,
                displayName = displayName.ifBlank { type.label },
                modelName = modelName.ifBlank { type.defaultModel },
                endpointUrl = endpointUrl.ifBlank { type.defaultEndpoint },
                priority = existing?.priority ?: priority,
                isEnabled = true,
                isActive = existing?.isActive ?: providers.value.none { it.isActive },
                status = if (hasValidKey) ProviderStatus.AVAILABLE else ProviderStatus.UNCONFIGURED,
                lastError = null
            )
            val autoSelected = repository.addOrUpdateProvider(entity, rawApiKey)
            val msg = if (autoSelected) {
                "Saved & selected ${entity.displayName} as active AI API to continue."
            } else {
                "Saved provider ${entity.displayName} as backup AI API."
            }
            _toastMessages.tryEmit(msg)
        }
    }

    fun testProviderConnection(provider: AiProviderConfigEntity) {
        viewModelScope.launch {
            _testingProviderId.value = provider.id
            val result = repository.aiOrchestrator.testProvider(provider)
            _testingProviderId.value = null
            _toastMessages.tryEmit("${provider.displayName}: ${result.message}")
        }
    }

    fun selectActiveProvider(providerId: String) {
        viewModelScope.launch {
            repository.setActiveProvider(providerId)
            _toastMessages.tryEmit("Active AI provider updated.")
        }
    }

    fun toggleProviderEnabled(provider: AiProviderConfigEntity, enabled: Boolean) {
        viewModelScope.launch {
            val promoted = repository.addOrUpdateProvider(provider.copy(isEnabled = enabled), null)
            if (promoted) {
                _toastMessages.tryEmit("Enabled & selected ${provider.displayName} to continue.")
            }
        }
    }

    fun updateProviderPriority(provider: AiProviderConfigEntity, delta: Int) {
        viewModelScope.launch {
            val newPriority = (provider.priority + delta).coerceAtLeast(0)
            repository.addOrUpdateProvider(provider.copy(priority = newPriority), null)
        }
    }

    fun deleteProvider(id: String) {
        viewModelScope.launch {
            repository.deleteProvider(id)
            _toastMessages.tryEmit("Provider connection removed.")
        }
    }

    fun clearAllStoredKeys() {
        viewModelScope.launch {
            repository.vault.clearAllKeys()
            providers.value.filter { it.id != "builtin_firebase_ai" }.forEach {
                repository.addOrUpdateProvider(it.copy(status = ProviderStatus.UNCONFIGURED), null)
            }
            _toastMessages.tryEmit("All stored third-party API keys cleared.")
        }
    }

    fun saveBrandKit(kit: BrandKitEntity) {
        viewModelScope.launch {
            repository.saveBrandKit(kit)
            _toastMessages.tryEmit("Brand kit \"${kit.name}\" saved.")
        }
    }

    fun deleteBrandKit(id: Long) {
        viewModelScope.launch {
            repository.deleteBrandKit(id)
            _toastMessages.tryEmit("Brand kit deleted.")
        }
    }

    fun saveCustomTemplate(template: CreatorTemplateEntity) {
        viewModelScope.launch {
            repository.saveCustomTemplate(template)
            _toastMessages.tryEmit("Template \"${template.name}\" saved.")
        }
    }

    fun deleteCustomTemplate(id: Long) {
        viewModelScope.launch {
            repository.deleteCustomTemplate(id)
        }
    }

    fun deleteLibraryAsset(asset: LibraryAssetEntity) {
        viewModelScope.launch {
            repository.deleteLibraryAsset(asset.id)
            _toastMessages.tryEmit("Removed ${asset.title} from library.")
        }
    }

    fun deleteClip(clipId: Long) {
        viewModelScope.launch {
            repository.deleteClip(clipId)
            _toastMessages.tryEmit("Clip deleted.")
        }
    }

    fun getMaskedKey(providerId: String): String = repository.vault.getMaskedKeyLabel(providerId)

    fun isAiQuotaExhaustedBannerVisible(): Boolean {
        val health = failoverSnapshot.value.health
        return health == AiOverallHealth.QUOTA_EXHAUSTED
    }

    private companion object {
        const val TAG = "MainViewModel"
    }
}
