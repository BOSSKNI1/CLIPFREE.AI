package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AutoCreateStep
import com.example.data.ClipFreeRepository
import com.example.data.local.ProjectEntity
import com.example.data.model.AspectRatioOption
import com.example.data.model.CaptionStyleConfig
import com.example.data.model.DurationPreset
import com.example.data.model.SocialPlatform
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface AutoCreateUiState {
    data object Idle : AutoCreateUiState
    data class Importing(val message: String = "Inspecting video stream...") : AutoCreateUiState
    data class ReadyToGenerate(val project: ProjectEntity) : AutoCreateUiState
    data class Processing(
        val project: ProjectEntity,
        val step: AutoCreateStep
    ) : AutoCreateUiState
    data class Completed(
        val projectId: Long,
        val clipCount: Int
    ) : AutoCreateUiState
    data class Error(
        val project: ProjectEntity?,
        val message: String,
        val canRetryAi: Boolean = true
    ) : AutoCreateUiState
}

class CreateAndProjectsViewModel(
    private val repository: ClipFreeRepository
) : ViewModel() {

    private val _autoCreateState = MutableStateFlow<AutoCreateUiState>(AutoCreateUiState.Idle)
    val autoCreateState: StateFlow<AutoCreateUiState> = _autoCreateState.asStateFlow()

    private var activeJob: Job? = null

    fun importVideoUri(
        uri: Uri,
        aspectRatio: AspectRatioOption = AspectRatioOption.RATIO_9_16,
        platform: SocialPlatform = SocialPlatform.YOUTUBE_SHORTS,
        durationPreset: DurationPreset = DurationPreset.MEDIUM_30_45,
        captionStyleId: String = "bold_creator"
    ) {
        viewModelScope.launch {
            _autoCreateState.value = AutoCreateUiState.Importing()
            val result = repository.importVideo(uri, aspectRatio, platform, durationPreset, captionStyleId)
            result.fold(
                onSuccess = { project ->
                    _autoCreateState.value = AutoCreateUiState.ReadyToGenerate(project)
                },
                onFailure = { err ->
                    _autoCreateState.value = AutoCreateUiState.Error(
                        project = null,
                        message = err.localizedMessage ?: "Unsupported or unreadable video file.",
                        canRetryAi = false
                    )
                }
            )
        }
    }

    fun selectExistingProjectForCreate(project: ProjectEntity) {
        _autoCreateState.value = AutoCreateUiState.ReadyToGenerate(project)
    }

    fun startAutoCreate(
        project: ProjectEntity,
        minSeconds: Int,
        maxSeconds: Int,
        aspectRatio: AspectRatioOption,
        platform: SocialPlatform,
        captionStyle: CaptionStyleConfig,
        preferredLanguage: String
    ) {
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            _autoCreateState.value = AutoCreateUiState.Processing(project, AutoCreateStep.EXTRACTING_MEDIA)
            try {
                val res = repository.runAutoCreateAnalysis(
                    projectId = project.id,
                    minSeconds = minSeconds,
                    maxSeconds = maxSeconds,
                    aspectRatio = aspectRatio,
                    platform = platform,
                    captionStyle = captionStyle,
                    preferredLanguage = preferredLanguage,
                    onStep = { step ->
                        _autoCreateState.value = AutoCreateUiState.Processing(project, step)
                    }
                )
                res.fold(
                    onSuccess = { clips ->
                        _autoCreateState.value = AutoCreateUiState.Completed(project.id, clips.size)
                    },
                    onFailure = { err ->
                        _autoCreateState.value = AutoCreateUiState.Error(
                            project = project,
                            message = err.localizedMessage ?: "AI analysis failed.",
                            canRetryAi = true
                        )
                    }
                )
            } catch (e: CancellationException) {
                _autoCreateState.value = AutoCreateUiState.ReadyToGenerate(project)
                throw e
            }
        }
    }

    fun cancelProcessing(project: ProjectEntity) {
        activeJob?.cancel()
        activeJob = null
        _autoCreateState.value = AutoCreateUiState.ReadyToGenerate(project)
    }

    fun createManualLocalClipAndOpen(
        project: ProjectEntity,
        aspectRatio: AspectRatioOption,
        captionStyle: CaptionStyleConfig,
        onCreated: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val endMs = minOf(project.durationMs, 30_000L).coerceAtLeast(1000L)
            val res = repository.createManualClip(
                projectId = project.id,
                title = "${project.title} — Clip 1",
                startMs = 0L,
                endMs = endMs,
                aspectRatio = aspectRatio,
                captionStyle = captionStyle
            )
            res.onSuccess {
                _autoCreateState.value = AutoCreateUiState.Idle
                onCreated(project.id)
            }
        }
    }

    fun resetCreateFlow() {
        activeJob?.cancel()
        _autoCreateState.value = AutoCreateUiState.Idle
    }

    fun renameProject(project: ProjectEntity, newTitle: String) {
        viewModelScope.launch { repository.renameProject(project, newTitle) }
    }

    fun duplicateProject(project: ProjectEntity) {
        viewModelScope.launch { repository.duplicateProject(project) }
    }

    fun deleteProject(projectId: Long) {
        viewModelScope.launch { repository.deleteProject(projectId) }
    }

    fun relinkSource(projectId: Long, newUri: Uri) {
        viewModelScope.launch { repository.relinkProjectSource(projectId, newUri) }
    }
}
