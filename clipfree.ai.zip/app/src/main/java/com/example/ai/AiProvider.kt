package com.example.ai

import com.example.data.local.AiProviderConfigEntity
import com.example.data.local.TranscriptSegmentEntity

interface AiProvider {
    val config: AiProviderConfigEntity

    suspend fun validateConnection(): ProviderValidationResult

    suspend fun analyzeVideoForHighlights(
        request: HighlightAnalysisRequest
    ): AiResult<VideoAnalysisResult>

    suspend fun generateHooksAndMetadata(
        transcriptText: String,
        videoTitle: String
    ): AiResult<MetadataAndHooksResult>

    suspend fun translateTranscript(
        segments: List<TranscriptSegmentEntity>,
        targetLanguage: String
    ): AiResult<List<TranslatedSegmentDto>>

    suspend fun suggestBRollAndTakes(
        segments: List<TranscriptSegmentEntity>
    ): AiResult<CreatorInsightsResult>
}
