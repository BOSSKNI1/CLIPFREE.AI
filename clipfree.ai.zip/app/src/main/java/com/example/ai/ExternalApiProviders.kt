package com.example.ai

import android.graphics.Bitmap
import android.util.Base64
import com.example.core.SecureVault
import com.example.data.local.AiProviderConfigEntity
import com.example.data.local.TranscriptSegmentEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

private val sharedHttpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(40, TimeUnit.SECONDS)
        .build()
}

/**
 * Supports user-configured Gemini Developer API connections with encrypted key storage.
 */
class GeminiRestAiProvider(
    override val config: AiProviderConfigEntity,
    private val vault: SecureVault
) : AiProvider {

    override suspend fun validateConnection(): ProviderValidationResult = withContext(Dispatchers.IO) {
        val apiKey = vault.getApiKey(config.id)
        if (apiKey.isNullOrBlank()) {
            return@withContext ProviderValidationResult(
                false, ProviderStatus.UNCONFIGURED, "No API key configured for ${config.displayName}."
            )
        }
        val baseUrl = config.endpointUrl.ifBlank { ProviderType.GEMINI_REST.defaultEndpoint }.trimEnd('/')
        val url = "$baseUrl/models/${config.modelName}"
        val req = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .get()
            .build()
        try {
            sharedHttpClient.newCall(req).execute().use { resp ->
                val remaining = resp.header("x-ratelimit-remaining-requests")
                val reset = resp.header("retry-after") ?: resp.header("x-ratelimit-reset-requests")
                val bodyLower = resp.body?.string().orEmpty().lowercase()
                when (resp.code) {
                    in 200..299 -> ProviderValidationResult(
                        true, ProviderStatus.AVAILABLE, "Verified (${config.modelName})", remaining, reset
                    )
                    402, 429 -> ProviderValidationResult(
                        false, ProviderStatus.QUOTA_EXHAUSTED, "API points or quota exhausted (HTTP ${resp.code}).", remaining, reset
                    )
                    401, 403 -> {
                        if (isQuotaOrCreditMessage(bodyLower)) {
                            ProviderValidationResult(
                                false, ProviderStatus.QUOTA_EXHAUSTED, "API credits or quota exhausted (HTTP ${resp.code}).", remaining, reset
                            )
                        } else {
                            ProviderValidationResult(
                                false, ProviderStatus.UNAUTHORIZED, "Invalid or unauthorized API key (HTTP ${resp.code})."
                            )
                        }
                    }
                    else -> {
                        if (isQuotaOrCreditMessage(bodyLower)) {
                            ProviderValidationResult(
                                false, ProviderStatus.QUOTA_EXHAUSTED, "API points or quota exhausted (HTTP ${resp.code}).", remaining, reset
                            )
                        } else {
                            ProviderValidationResult(
                                false, ProviderStatus.LIMITED, "Provider returned HTTP ${resp.code}."
                            )
                        }
                    }
                }
            }
        } catch (e: IOException) {
            ProviderValidationResult(false, ProviderStatus.OFFLINE, "Network unreachable: ${e.localizedMessage}")
        }
    }

    override suspend fun analyzeVideoForHighlights(
        request: HighlightAnalysisRequest
    ): AiResult<VideoAnalysisResult> {
        val parts = JSONArray().apply {
            put(
                JSONObject().put(
                    "text",
                    """
                    Return strictly valid JSON with keys: "summary", "chapters" ([{title,startMs,endMs,summary}]),
                    "transcript" ([{startMs,endMs,text,speakerLabel,language,isFillerOrSilence,isRepeatedTake}]),
                    and "clips" ([{title,startMs,endMs,description,openingHook,reasonForSelection,viralityScore,scoreExplanation,suggestedCaption,hashtags,language,speakerLabel}]).
                    Actual duration: ${request.videoDurationMs}ms. Target clip length: ${request.targetMinSeconds}-${request.targetMaxSeconds}s for ${request.targetPlatformLabel} (${request.aspectRatioLabel}). Language: ${request.preferredLanguage}.
                    Do NOT invent timestamps beyond ${request.videoDurationMs}ms.
                    """.trimIndent()
                )
            )
            if (request.audioBytes != null && request.audioBytes.isNotEmpty()) {
                put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject()
                            .put("mime_type", request.audioMimeType)
                            .put("data", Base64.encodeToString(request.audioBytes, Base64.NO_WRAP))
                    )
                )
            }
            request.keyframes.take(6).forEach { (timeMs, bitmap) ->
                put(JSONObject().put("text", "Frame at ${timeMs}ms"))
                put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject()
                            .put("mime_type", "image/jpeg")
                            .put("data", bitmap.toBase64Jpeg())
                    )
                )
            }
        }

        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put(
                "generationConfig",
                JSONObject().put("responseMimeType", "application/json")
            )

        return executeGeminiRest(body).fold(
            onSuccess = { text, rem, reset ->
                val parsed = FirebaseAiLogicProvider.parseAnalysisJson(text, request.videoDurationMs)
                AiResult.Success(parsed, config.id, config.displayName, rem, reset)
            },
            onFailure = { it }
        )
    }

    override suspend fun generateHooksAndMetadata(
        transcriptText: String,
        videoTitle: String
    ): AiResult<MetadataAndHooksResult> {
        val prompt = """
            Return JSON with keys: titles (string[]), captions (string[]), hashtags (string[]), shortSummary (string), hooks ([{category,hookText}]).
            Base all hooks strictly on this real video title "$videoTitle" and transcript:
            ${transcriptText.take(6000)}
        """.trimIndent()
        return executeTextJsonPrompt(prompt) { text, rem, reset ->
            AiResult.Success(FirebaseAiLogicProvider.parseHooksJson(text), config.id, config.displayName, rem, reset)
        }
    }

    override suspend fun translateTranscript(
        segments: List<TranscriptSegmentEntity>,
        targetLanguage: String
    ): AiResult<List<TranslatedSegmentDto>> {
        val formatted = segments.take(80).joinToString("\n") { "${it.startMs}-${it.endMs}: ${it.text}" }
        val prompt = """
            Return JSON {"segments":[{"startMs":0,"endMs":1000,"translatedText":"..."}]} translating to $targetLanguage:
            $formatted
        """.trimIndent()
        return executeTextJsonPrompt(prompt) { text, rem, reset ->
            val arr = JSONObject(text).optJSONArray("segments") ?: JSONArray()
            val list = (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                TranslatedSegmentDto(o.optLong("startMs"), o.optLong("endMs"), o.optString("translatedText"))
            }
            AiResult.Success(list, config.id, config.displayName, rem, reset)
        }
    }

    override suspend fun suggestBRollAndTakes(
        segments: List<TranscriptSegmentEntity>
    ): AiResult<CreatorInsightsResult> {
        val formatted = segments.take(80).joinToString("\n") { "[${it.startMs}-${it.endMs}] ${it.text}" }
        val prompt = """
            Return JSON with "bRollSuggestions" ([{startMs,endMs,topic,visualPrompt,reason}]) and "repeatedTakes" ([{phraseSummary,keptStartMs,keptEndMs,redundantStartMs,redundantEndMs,reason}]) from:
            $formatted
        """.trimIndent()
        return executeTextJsonPrompt(prompt) { text, rem, reset ->
            AiResult.Success(FirebaseAiLogicProvider.parseInsightsJson(text), config.id, config.displayName, rem, reset)
        }
    }

    private suspend fun <T> executeTextJsonPrompt(
        prompt: String,
        mapper: (String, String?, String?) -> AiResult<T>
    ): AiResult<T> {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        return executeGeminiRest(body).fold(
            onSuccess = { text, rem, reset ->
                runCatching { mapper(text, rem, reset) }.getOrElse {
                    AiResult.Failure(AiFailureReason.INVALID_RESPONSE, "Failed to parse JSON: ${it.localizedMessage}")
                }
            },
            onFailure = { it }
        )
    }

    private suspend fun executeGeminiRest(body: JSONObject): RestCallOutcome = withContext(Dispatchers.IO) {
        val apiKey = vault.getApiKey(config.id)
            ?: return@withContext RestCallOutcome.Err(
                AiResult.Failure(AiFailureReason.UNAUTHORIZED, "API key is missing.")
            )
        val baseUrl = config.endpointUrl.ifBlank { ProviderType.GEMINI_REST.defaultEndpoint }.trimEnd('/')
        val url = "$baseUrl/models/${config.modelName}:generateContent"
        val req = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        try {
            sharedHttpClient.newCall(req).execute().use { resp ->
                val rem = resp.header("x-ratelimit-remaining-requests")
                val reset = resp.header("retry-after") ?: resp.header("x-ratelimit-reset-requests")
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext RestCallOutcome.Err(classifyHttpFailure(resp.code, raw, rem, reset))
                }
                val text = JSONObject(raw)
                    .optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")
                    .orEmpty()
                if (text.isBlank()) {
                    RestCallOutcome.Err(AiResult.Failure(AiFailureReason.INVALID_RESPONSE, "Empty AI response."))
                } else {
                    RestCallOutcome.Ok(text, rem, reset)
                }
            }
        } catch (e: IOException) {
            RestCallOutcome.Err(AiResult.Failure(AiFailureReason.NETWORK_UNAVAILABLE, e.localizedMessage ?: "Network error"))
        } catch (e: Exception) {
            RestCallOutcome.Err(AiResult.Failure(AiFailureReason.PROVIDER_ERROR, e.localizedMessage ?: "Provider error"))
        }
    }
}

/**
 * Supports OpenAI, Groq, OpenRouter, or any custom OpenAI-compatible Chat Completions endpoint.
 */
class OpenAiCompatibleAiProvider(
    override val config: AiProviderConfigEntity,
    private val vault: SecureVault
) : AiProvider {

    override suspend fun validateConnection(): ProviderValidationResult = withContext(Dispatchers.IO) {
        val apiKey = vault.getApiKey(config.id)
        if (apiKey.isNullOrBlank()) {
            return@withContext ProviderValidationResult(
                false, ProviderStatus.UNCONFIGURED, "No API key configured for ${config.displayName}."
            )
        }
        val baseUrl = config.endpointUrl.trim().trimEnd('/')
        if (baseUrl.isBlank()) {
            return@withContext ProviderValidationResult(
                false, ProviderStatus.UNCONFIGURED, "Endpoint URL is blank."
            )
        }
        val req = Request.Builder()
            .url("$baseUrl/models")
            .addHeader("Authorization", "Bearer $apiKey")
            .get()
            .build()
        try {
            sharedHttpClient.newCall(req).execute().use { resp ->
                val rem = resp.header("x-ratelimit-remaining-requests")
                val reset = resp.header("x-ratelimit-reset-requests") ?: resp.header("retry-after")
                val bodyLower = resp.body?.string().orEmpty().lowercase()
                when (resp.code) {
                    in 200..299 -> ProviderValidationResult(
                        true, ProviderStatus.AVAILABLE, "Connected (${config.modelName})", rem, reset
                    )
                    402, 429 -> ProviderValidationResult(
                        false, ProviderStatus.QUOTA_EXHAUSTED, "API points or quota exhausted (HTTP ${resp.code}).", rem, reset
                    )
                    401, 403 -> {
                        if (isQuotaOrCreditMessage(bodyLower)) {
                            ProviderValidationResult(
                                false, ProviderStatus.QUOTA_EXHAUSTED, "API credits or quota exhausted (HTTP ${resp.code}).", rem, reset
                            )
                        } else {
                            ProviderValidationResult(
                                false, ProviderStatus.UNAUTHORIZED, "Unauthorized API key (HTTP ${resp.code})."
                            )
                        }
                    }
                    else -> {
                        if (isQuotaOrCreditMessage(bodyLower)) {
                            ProviderValidationResult(
                                false, ProviderStatus.QUOTA_EXHAUSTED, "API points or quota exhausted (HTTP ${resp.code}).", rem, reset
                            )
                        } else {
                            ProviderValidationResult(
                                false, ProviderStatus.LIMITED, "Returned HTTP ${resp.code}."
                            )
                        }
                    }
                }
            }
        } catch (e: IOException) {
            ProviderValidationResult(false, ProviderStatus.OFFLINE, "Connection failed: ${e.localizedMessage}")
        }
    }

    override suspend fun analyzeVideoForHighlights(
        request: HighlightAnalysisRequest
    ): AiResult<VideoAnalysisResult> {
        val contentArr = JSONArray().apply {
            put(
                JSONObject().put("type", "text").put(
                    "text",
                    """
                    Analyze these timestamped keyframes from video "${request.videoTitle}" (duration ${request.videoDurationMs}ms).
                    Return strict JSON with keys: summary, chapters ([{title,startMs,endMs,summary}]),
                    transcript ([{startMs,endMs,text,speakerLabel,language,isFillerOrSilence,isRepeatedTake}]),
                    clips ([{title,startMs,endMs,description,openingHook,reasonForSelection,viralityScore,scoreExplanation,suggestedCaption,hashtags,language,speakerLabel}]).
                    Target clip duration: ${request.targetMinSeconds}-${request.targetMaxSeconds}s for ${request.targetPlatformLabel} (${request.aspectRatioLabel}). Language: ${request.preferredLanguage}.
                    Only output timestamps inside 0..${request.videoDurationMs}ms.
                    """.trimIndent()
                )
            )
            request.keyframes.take(5).forEach { (timeMs, bitmap) ->
                put(JSONObject().put("type", "text").put("text", "Keyframe ${timeMs}ms"))
                put(
                    JSONObject()
                        .put("type", "image_url")
                        .put(
                            "image_url",
                            JSONObject().put("url", "data:image/jpeg;base64,${bitmap.toBase64Jpeg()}")
                        )
                )
            }
        }
        return executeChatCompletion(contentArr).fold(
            onSuccess = { text, rem, reset ->
                runCatching {
                    AiResult.Success(
                        FirebaseAiLogicProvider.parseAnalysisJson(text, request.videoDurationMs),
                        config.id,
                        config.displayName,
                        rem,
                        reset
                    )
                }.getOrElse {
                    AiResult.Failure(AiFailureReason.INVALID_RESPONSE, "Invalid JSON from ${config.displayName}")
                }
            },
            onFailure = { it }
        )
    }

    override suspend fun generateHooksAndMetadata(
        transcriptText: String,
        videoTitle: String
    ): AiResult<MetadataAndHooksResult> {
        val prompt = """
            Return JSON with keys: titles (string[]), captions (string[]), hashtags (string[]), shortSummary (string), hooks ([{category,hookText}]).
            Title: $videoTitle
            Transcript: ${transcriptText.take(6000)}
        """.trimIndent()
        return executeSimplePrompt(prompt) { text, rem, reset ->
            AiResult.Success(FirebaseAiLogicProvider.parseHooksJson(text), config.id, config.displayName, rem, reset)
        }
    }

    override suspend fun translateTranscript(
        segments: List<TranscriptSegmentEntity>,
        targetLanguage: String
    ): AiResult<List<TranslatedSegmentDto>> {
        val formatted = segments.take(80).joinToString("\n") { "${it.startMs}-${it.endMs}: ${it.text}" }
        val prompt = """
            Return JSON {"segments":[{"startMs":0,"endMs":1000,"translatedText":"..."}]} translating to $targetLanguage:
            $formatted
        """.trimIndent()
        return executeSimplePrompt(prompt) { text, rem, reset ->
            val arr = JSONObject(text).optJSONArray("segments") ?: JSONArray()
            val list = (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                TranslatedSegmentDto(o.optLong("startMs"), o.optLong("endMs"), o.optString("translatedText"))
            }
            AiResult.Success(list, config.id, config.displayName, rem, reset)
        }
    }

    override suspend fun suggestBRollAndTakes(
        segments: List<TranscriptSegmentEntity>
    ): AiResult<CreatorInsightsResult> {
        val formatted = segments.take(80).joinToString("\n") { "[${it.startMs}-${it.endMs}] ${it.text}" }
        val prompt = """
            Return JSON with "bRollSuggestions" ([{startMs,endMs,topic,visualPrompt,reason}]) and "repeatedTakes" ([{phraseSummary,keptStartMs,keptEndMs,redundantStartMs,redundantEndMs,reason}]) from:
            $formatted
        """.trimIndent()
        return executeSimplePrompt(prompt) { text, rem, reset ->
            AiResult.Success(FirebaseAiLogicProvider.parseInsightsJson(text), config.id, config.displayName, rem, reset)
        }
    }

    private suspend fun <T> executeSimplePrompt(
        prompt: String,
        mapper: (String, String?, String?) -> AiResult<T>
    ): AiResult<T> {
        return executeChatCompletion(prompt).fold(
            onSuccess = { text, rem, reset ->
                runCatching { mapper(text, rem, reset) }.getOrElse {
                    AiResult.Failure(AiFailureReason.INVALID_RESPONSE, "Failed to parse JSON: ${it.localizedMessage}")
                }
            },
            onFailure = { it }
        )
    }

    private suspend fun executeChatCompletion(userContent: Any): RestCallOutcome = withContext(Dispatchers.IO) {
        val apiKey = vault.getApiKey(config.id)
            ?: return@withContext RestCallOutcome.Err(
                AiResult.Failure(AiFailureReason.UNAUTHORIZED, "API key is missing.")
            )
        val baseUrl = config.endpointUrl.trim().trimEnd('/')
        val body = JSONObject()
            .put("model", config.modelName)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put(
                "messages",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("content", userContent)
                )
            )

        val req = Request.Builder()
            .url("$baseUrl/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        try {
            sharedHttpClient.newCall(req).execute().use { resp ->
                val rem = resp.header("x-ratelimit-remaining-requests")
                val reset = resp.header("x-ratelimit-reset-requests") ?: resp.header("retry-after")
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext RestCallOutcome.Err(classifyHttpFailure(resp.code, raw, rem, reset))
                }
                val text = JSONObject(raw)
                    .optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content")
                    .orEmpty()
                if (text.isBlank()) {
                    RestCallOutcome.Err(AiResult.Failure(AiFailureReason.INVALID_RESPONSE, "Empty AI response."))
                } else {
                    RestCallOutcome.Ok(text, rem, reset)
                }
            }
        } catch (e: IOException) {
            RestCallOutcome.Err(AiResult.Failure(AiFailureReason.NETWORK_UNAVAILABLE, e.localizedMessage ?: "Network error"))
        } catch (e: Exception) {
            RestCallOutcome.Err(AiResult.Failure(AiFailureReason.PROVIDER_ERROR, e.localizedMessage ?: "Provider error"))
        }
    }
}

private sealed class RestCallOutcome {
    data class Ok(val text: String, val remaining: String?, val reset: String?) : RestCallOutcome()
    data class Err(val failure: AiResult.Failure) : RestCallOutcome()

    inline fun <R> fold(
        onSuccess: (String, String?, String?) -> R,
        onFailure: (AiResult.Failure) -> R
    ): R = when (this) {
        is Ok -> onSuccess(text, remaining, reset)
        is Err -> onFailure(failure)
    }
}

private fun isQuotaOrCreditMessage(lowerBody: String): Boolean {
    return lowerBody.contains("resource_exhausted") ||
        lowerBody.contains("quota") ||
        lowerBody.contains("insufficient_quota") ||
        lowerBody.contains("insufficient credits") ||
        lowerBody.contains("insufficient_balance") ||
        lowerBody.contains("credit balance") ||
        lowerBody.contains("out of credits") ||
        lowerBody.contains("payment required") ||
        lowerBody.contains("exceeded") ||
        lowerBody.contains("rate_limit") ||
        lowerBody.contains("rate limit") ||
        lowerBody.contains("billing") ||
        lowerBody.contains("limit reached")
}

private fun classifyHttpFailure(
    code: Int,
    rawBody: String,
    remaining: String?,
    reset: String?
): AiResult.Failure {
    val lower = rawBody.lowercase()
    return when {
        code == 402 || code == 429 || isQuotaOrCreditMessage(lower) ->
            AiResult.Failure(
                AiFailureReason.QUOTA_EXHAUSTED,
                "API points or quota exhausted (HTTP $code).",
                code, remaining, reset
            )
        code == 401 || code == 403 ->
            AiResult.Failure(AiFailureReason.UNAUTHORIZED, "Authentication failed (HTTP $code).", code, remaining, reset)
        code in 500..599 ->
            AiResult.Failure(AiFailureReason.PROVIDER_ERROR, "Provider service error (HTTP $code).", code, remaining, reset)
        else ->
            AiResult.Failure(AiFailureReason.PROVIDER_ERROR, "HTTP $code error.", code, remaining, reset)
    }
}

private fun Bitmap.toBase64Jpeg(): String {
    val out = ByteArrayOutputStream()
    compress(Bitmap.CompressFormat.JPEG, 75, out)
    return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
}
