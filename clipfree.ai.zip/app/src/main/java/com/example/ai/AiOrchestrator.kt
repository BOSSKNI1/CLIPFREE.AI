package com.example.ai

import com.example.core.PreferencesManager
import com.example.core.QuotaMode
import com.example.core.SecureVault
import com.example.data.local.AiProviderConfigEntity
import com.example.data.local.AiProviderDao
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import java.util.concurrent.ConcurrentHashMap

data class FailoverSnapshot(
    val activeProviderName: String = "Firebase AI Logic",
    val activeModelName: String = "gemini-3.8-flash",
    val health: AiOverallHealth = AiOverallHealth.AI_AVAILABLE,
    val lastSwitchingEvent: String? = null,
    val localFallbackActive: Boolean = false
)

class AiOrchestrator(
    private val providerDao: AiProviderDao,
    private val vault: SecureVault,
    private val preferencesManager: PreferencesManager,
    private val customProviderFactory: ((AiProviderConfigEntity) -> AiProvider)? = null
) {
    private val _notifications = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val notifications: SharedFlow<String> = _notifications.asSharedFlow()

    private val _snapshot = MutableStateFlow(FailoverSnapshot())
    val snapshot: StateFlow<FailoverSnapshot> = _snapshot.asStateFlow()

    // Prevents rapid ping-ponging between recently exhausted/failing providers
    private val cooldownUntilMs = ConcurrentHashMap<String, Long>()

    suspend fun ensureDefaultProvidersSeeded() {
        val existing = providerDao.getProviders()
        if (existing.isEmpty()) {
            providerDao.upsertAll(
                listOf(
                    AiProviderConfigEntity(
                        id = "builtin_firebase_ai",
                        providerType = ProviderType.FIREBASE_AI_LOGIC.id,
                        displayName = "Firebase AI Logic (Built-in)",
                        modelName = "gemini-3.8-flash",
                        endpointUrl = ProviderType.FIREBASE_AI_LOGIC.defaultEndpoint,
                        priority = 0,
                        isEnabled = true,
                        isActive = true,
                        status = ProviderStatus.AVAILABLE
                    )
                )
            )
        }
        refreshSnapshot()
    }

    suspend fun refreshSnapshot() {
        val prefs = preferencesManager.preferencesFlow.first()
        val providers = providerDao.getProviders()
        val configuredEnabled = providers.filter { it.isEnabled && isProviderConfigured(it) }
        val active = configuredEnabled.firstOrNull { it.isActive }
            ?: providers.firstOrNull { it.isActive }
            ?: configuredEnabled.firstOrNull()
            ?: providers.firstOrNull()
        val anyAvailable = configuredEnabled.any { it.status == ProviderStatus.AVAILABLE }
        val allExhausted = configuredEnabled.isNotEmpty() && configuredEnabled.all {
            it.status == ProviderStatus.QUOTA_EXHAUSTED ||
                it.status == ProviderStatus.LIMITED ||
                it.status == ProviderStatus.UNAUTHORIZED
        }

        val health = when {
            prefs.quotaMode == QuotaMode.LOCAL_MODE -> AiOverallHealth.OFFLINE_MODE
            anyAvailable -> AiOverallHealth.AI_AVAILABLE
            allExhausted || configuredEnabled.isEmpty() -> AiOverallHealth.QUOTA_EXHAUSTED
            else -> AiOverallHealth.TEMPORARILY_LIMITED
        }
        _snapshot.value = _snapshot.value.copy(
            activeProviderName = active?.displayName ?: "Local Mode",
            activeModelName = active?.modelName ?: "Offline Engine",
            health = health,
            localFallbackActive = prefs.quotaMode == QuotaMode.LOCAL_MODE || !anyAvailable
        )
    }

    suspend fun <T> executeWithFailover(
        block: suspend (AiProvider) -> AiResult<T>
    ): AiResult<T> {
        ensureDefaultProvidersSeeded()
        val prefs = preferencesManager.preferencesFlow.first()
        if (prefs.quotaMode == QuotaMode.LOCAL_MODE) {
            return AiResult.Failure(
                AiFailureReason.QUOTA_EXHAUSTED,
                "Local Mode is active. AI requests are paused; local editing and export remain available."
            )
        }

        _snapshot.value = _snapshot.value.copy(health = AiOverallHealth.PROCESSING)

        val allProviders = providerDao.getProviders()
            .filter { it.isEnabled && isProviderConfigured(it) }
            .sortedWith(
                compareByDescending<AiProviderConfigEntity> { it.isActive }
                    .thenBy { it.priority }
                    .thenBy { it.id }
            )

        if (allProviders.isEmpty()) {
            val notice = "No configured AI API is available. Add an API key in Profile or use Local Mode."
            activateLocalFallback(notice)
            return AiResult.Failure(AiFailureReason.QUOTA_EXHAUSTED, notice)
        }

        val initialActive = allProviders.firstOrNull { it.isActive }
        val now = System.currentTimeMillis()
        val nonCooling = allProviders.filter { (cooldownUntilMs[it.id] ?: 0L) <= now }
        // Try non-cooling providers first; if all are cooling (e.g. user clicked Retry), try all by priority
        val candidates = if (nonCooling.isNotEmpty()) {
            nonCooling
        } else {
            allProviders.sortedWith(compareBy<AiProviderConfigEntity> { it.priority }.thenBy { it.id })
        }

        var lastFailure: AiResult.Failure? = null
        var previousFailedName: String? = initialActive?.takeIf { it.id != candidates.first().id }?.displayName

        for ((index, config) in candidates.withIndex()) {
            val switchedFromInitial = initialActive != null && config.id != initialActive.id
            val isSwitching = index > 0 || switchedFromInitial

            if (isSwitching) {
                val switchTime = System.currentTimeMillis()
                // Exclusively set the newly selected provider as active in Room
                providerDao.setActiveProvider(config.id)
                providerDao.upsert(
                    config.copy(
                        isActive = true,
                        lastSwitchedAt = switchTime
                    )
                )
                val fromLabel = previousFailedName ?: initialActive?.displayName ?: "previous API"
                val switchNotice = "Switching from $fromLabel to ${config.displayName} to continue..."
                _notifications.tryEmit(switchNotice)
                _snapshot.value = _snapshot.value.copy(
                    activeProviderName = config.displayName,
                    activeModelName = config.modelName,
                    health = AiOverallHealth.PROCESSING,
                    lastSwitchingEvent = "Switched to ${config.displayName}"
                )
            }

            val provider = buildProvider(config)
            when (val result = block(provider)) {
                is AiResult.Success -> {
                    cooldownUntilMs.remove(config.id)
                    val successTime = System.currentTimeMillis()
                    providerDao.setActiveProvider(config.id)
                    providerDao.upsert(
                        config.copy(
                            isActive = true,
                            status = ProviderStatus.AVAILABLE,
                            lastError = null,
                            lastSwitchedAt = if (isSwitching) successTime else config.lastSwitchedAt,
                            requestsUsedSession = config.requestsUsedSession + 1,
                            rateLimitRemaining = result.rateLimitRemaining ?: config.rateLimitRemaining,
                            rateLimitReset = result.rateLimitReset ?: config.rateLimitReset
                        )
                    )
                    val switchEvent = if (isSwitching) {
                        val fromLabel = previousFailedName ?: "previous API"
                        val resumedMsg = "API points/limit reached on $fromLabel. Selected ${config.displayName} and continued."
                        _notifications.tryEmit(resumedMsg)
                        "Switched from $fromLabel to ${config.displayName}"
                    } else {
                        _snapshot.value.lastSwitchingEvent
                    }
                    _snapshot.value = _snapshot.value.copy(
                        activeProviderName = config.displayName,
                        activeModelName = config.modelName,
                        health = AiOverallHealth.AI_AVAILABLE,
                        lastSwitchingEvent = switchEvent,
                        localFallbackActive = false
                    )
                    return result
                }

                is AiResult.Failure -> {
                    lastFailure = result
                    val newStatus = when (result.reason) {
                        AiFailureReason.QUOTA_EXHAUSTED -> ProviderStatus.QUOTA_EXHAUSTED
                        AiFailureReason.RATE_LIMITED, AiFailureReason.TIMEOUT, AiFailureReason.PROVIDER_ERROR ->
                            ProviderStatus.LIMITED
                        AiFailureReason.UNAUTHORIZED -> ProviderStatus.UNAUTHORIZED
                        AiFailureReason.NETWORK_UNAVAILABLE -> ProviderStatus.OFFLINE
                        AiFailureReason.INVALID_RESPONSE -> ProviderStatus.LIMITED
                    }
                    val latest = providerDao.getProvider(config.id) ?: config
                    providerDao.upsert(
                        latest.copy(
                            status = newStatus,
                            lastError = result.message,
                            rateLimitRemaining = result.rateLimitRemaining ?: latest.rateLimitRemaining,
                            rateLimitReset = result.rateLimitReset ?: latest.rateLimitReset
                        )
                    )
                    if (result.reason == AiFailureReason.NETWORK_UNAVAILABLE) {
                        activateLocalFallback("Network offline. Local editing and MP4 export remain available.", offline = true)
                        return result
                    }
                    cooldownUntilMs[config.id] = System.currentTimeMillis() + COOLDOWN_MS
                    previousFailedName = config.displayName
                    if (index < candidates.lastIndex) {
                        val nextCandidate = candidates[index + 1]
                        _notifications.tryEmit(
                            "${config.displayName} reached its API limit. Selecting ${nextCandidate.displayName} to continue..."
                        )
                    }
                }
            }
        }

        val exhaustedNotice = if (allProviders.size <= 1) {
            "${allProviders.first().displayName} ran out of API points/quota and no backup API is configured. Add another API in Profile to auto-continue."
        } else {
            "All ${allProviders.size} configured AI APIs are out of points or unavailable. Add a new API in Profile or use Local Mode."
        }
        activateLocalFallback(exhaustedNotice)
        return lastFailure ?: AiResult.Failure(AiFailureReason.QUOTA_EXHAUSTED, exhaustedNotice)
    }

    suspend fun onProviderSavedOrEnabled(config: AiProviderConfigEntity): Boolean {
        cooldownUntilMs.remove(config.id)
        if (!config.isEnabled || !isProviderConfigured(config) || config.status != ProviderStatus.AVAILABLE) {
            refreshSnapshot()
            return false
        }
        val providers = providerDao.getProviders()
        val currentActive = providers.firstOrNull { it.isActive }
        val shouldPromote = currentActive == null ||
            !currentActive.isEnabled ||
            !isProviderConfigured(currentActive) ||
            currentActive.status != ProviderStatus.AVAILABLE

        if (shouldPromote) {
            val now = System.currentTimeMillis()
            providerDao.setActiveProvider(config.id)
            providerDao.upsert(
                config.copy(
                    isActive = true,
                    lastSwitchedAt = now,
                    lastError = null
                )
            )
            val fromPart = currentActive?.takeIf { it.id != config.id }?.let { "from ${it.displayName} " } ?: ""
            _snapshot.value = _snapshot.value.copy(
                lastSwitchingEvent = "Selected ${config.displayName} ${fromPart}(ready to continue)"
            )
            refreshSnapshot()
            return true
        }
        refreshSnapshot()
        return false
    }

    suspend fun ensureActiveProviderValidAfterRemovalOrDisable() {
        val providers = providerDao.getProviders()
        val currentActive = providers.firstOrNull { it.isActive }
        if (currentActive != null && currentActive.isEnabled && isProviderConfigured(currentActive)) {
            refreshSnapshot()
            return
        }
        val replacement = providers
            .filter { it.isEnabled && isProviderConfigured(it) }
            .sortedWith(
                compareByDescending<AiProviderConfigEntity> { it.status == ProviderStatus.AVAILABLE }
                    .thenBy { it.priority }
                    .thenBy { it.id }
            )
            .firstOrNull()
        if (replacement != null) {
            providerDao.setActiveProvider(replacement.id)
            _snapshot.value = _snapshot.value.copy(
                lastSwitchingEvent = "Selected ${replacement.displayName}"
            )
        }
        refreshSnapshot()
    }

    suspend fun testProvider(config: AiProviderConfigEntity): ProviderValidationResult {
        val provider = buildProvider(config)
        val result = provider.validateConnection()
        if (result.isValid) cooldownUntilMs.remove(config.id)
        providerDao.upsert(
            config.copy(
                status = result.status,
                lastTestedAt = System.currentTimeMillis(),
                lastError = if (result.isValid) null else result.message,
                rateLimitRemaining = result.rateLimitRemaining ?: config.rateLimitRemaining,
                rateLimitReset = result.rateLimitReset ?: config.rateLimitReset
            )
        )
        if (result.isValid) {
            onProviderSavedOrEnabled(config.copy(status = result.status))
        } else {
            refreshSnapshot()
        }
        return result
    }

    fun clearCooldowns() {
        cooldownUntilMs.clear()
    }

    fun clearCooldown(providerId: String) {
        cooldownUntilMs.remove(providerId)
    }

    private fun activateLocalFallback(notice: String, offline: Boolean = false) {
        _notifications.tryEmit(notice)
        _snapshot.value = _snapshot.value.copy(
            health = if (offline) AiOverallHealth.OFFLINE_MODE else AiOverallHealth.QUOTA_EXHAUSTED,
            localFallbackActive = true,
            lastSwitchingEvent = notice
        )
    }

    fun isProviderConfigured(config: AiProviderConfigEntity): Boolean {
        return when (config.providerType) {
            ProviderType.FIREBASE_AI_LOGIC.id -> true
            else -> vault.hasApiKey(config.id)
        }
    }

    private fun buildProvider(config: AiProviderConfigEntity): AiProvider {
        customProviderFactory?.let { return it(config) }
        return when (config.providerType) {
            ProviderType.FIREBASE_AI_LOGIC.id -> FirebaseAiLogicProvider(config)
            ProviderType.GEMINI_REST.id -> GeminiRestAiProvider(config, vault)
            else -> OpenAiCompatibleAiProvider(config, vault)
        }
    }

    companion object {
        private const val COOLDOWN_MS = 90_000L
    }
}
