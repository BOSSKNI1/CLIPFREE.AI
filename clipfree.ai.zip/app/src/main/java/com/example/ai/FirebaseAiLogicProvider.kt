package com.example.ai

import android.util.Log
import com.example.data.local.AiProviderConfigEntity
import com.example.data.local.TranscriptSegmentEntity
import com.example.data.model.VideoChapter
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

private const val TAG = "FirebaseAiLogicProvider"

class FirebaseAiLogicProvider(
    override val config: AiProviderConfigEntity
) : AiProvider {

    private val modelName: String
        get() = config.modelName.ifBlank { "gemini-3.8-flash" }

    private val analysisModel by lazy {
        Firebase.ai.generativeModel(
            modelName = modelName,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = videoAnalysisSchema
            }
        )
    }

    private val hooksModel by lazy {
        Firebase.ai.generativeModel(
            modelName = modelName,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = hooksMetadataSchema
            }
        )
    }

    private val translationModel by lazy {
        Firebase.ai.generativeModel(
            modelName = modelName,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = translationSchema
            }
        )
    }

    private val insightsModel by lazy {
        Firebase.ai.generativeModel(
            modelName = modelName,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = creatorInsightsSchema
            }
        )
    }

    private val validationModel by lazy {
        Firebase.ai.generativeModel(modelName = "gemini-3.5-flash-lite")
    }

    override suspend fun validateConnection(): ProviderValidationResult {
        return try {
            val response = withTimeout(25_000L) {
                validationModel.generateContent("Reply with OK")
            }
            if (!response.text.isNullOrBlank()) {
                ProviderValidationResult(true, ProviderStatus.AVAILABLE, "Firebase AI Logic connected ($modelName).")
            } else {
                ProviderValidationResult(false, ProviderStatus.LIMITED, "Empty validation response from Firebase AI.")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val failure = classifyException(e)
            val status = when (failure.reason) {
                AiFailureReason.QUOTA_EXHAUSTED -> ProviderStatus.QUOTA_EXHAUSTED
                AiFailureReason.RATE_LIMITED -> ProviderStatus.LIMITED
                AiFailureReason.UNAUTHORIZED -> ProviderStatus.UNAUTHORIZED
                AiFailureReason.NETWORK_UNAVAILABLE -> ProviderStatus.OFFLINE
                else -> ProviderStatus.LIMITED
            }
            ProviderValidationResult(false, status, failure.message)
        }
    }

    override suspend fun analyzeVideoForHighlights(
        request: HighlightAnalysisRequest
    ): AiResult<VideoAnalysisResult> {
        return try {
            val promptText = buildAnalysisPrompt(request)
            val response = withTimeout(90_000L) {
                analysisModel.generateContent(
                    content {
                        text(promptText)
                        if (request.audioBytes != null && request.audioBytes.isNotEmpty()) {
                            inlineData(request.audioBytes, request.audioMimeType)
                        }
                        request.keyframes.take(6).forEach { (timeMs, bitmap) ->
                            text("Keyframe at ${timeMs}ms:")
                            image(bitmap)
                        }
                    }
                )
            }
            val jsonText = response.text
                ?: return AiResult.Failure(AiFailureReason.INVALID_RESPONSE, "Model returned an empty response.")
            val parsed = parseAnalysisJson(jsonText, request.videoDurationMs)
            AiResult.Success(parsed, config.id, config.displayName)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "analyzeVideoForHighlights failed", e)
            classifyException(e)
        }
    }

    override suspend fun generateHooksAndMetadata(
        transcriptText: String,
        videoTitle: String
    ): AiResult<MetadataAndHooksResult> {
        return try {
            val prompt = """
                Based strictly on this real video transcript and title, generate viral metadata and opening hooks.
                Do not invent facts or claims not grounded in the transcript.
                Title: $videoTitle
                Transcript:
                ${transcriptText.take(6000)}
            """.trimIndent()
            val response = withTimeout(45_000L) { hooksModel.generateContent(prompt) }
            val jsonText = response.text
                ?: return AiResult.Failure(AiFailureReason.INVALID_RESPONSE, "Empty hook generation output.")
            AiResult.Success(parseHooksJson(jsonText), config.id, config.displayName)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "generateHooksAndMetadata failed", e)
            classifyException(e)
        }
    }

    override suspend fun translateTranscript(
        segments: List<TranscriptSegmentEntity>,
        targetLanguage: String
    ): AiResult<List<TranslatedSegmentDto>> {
        return try {
            val formatted = segments.take(80).joinToString("\n") {
                "${it.startMs}-${it.endMs}: ${it.text}"
            }
            val prompt = """
                Translate each transcript segment naturally into $targetLanguage while preserving exact startMs and endMs timestamps.
                Segments:
                $formatted
            """.trimIndent()
            val response = withTimeout(50_000L) { translationModel.generateContent(prompt) }
            val jsonText = response.text
                ?: return AiResult.Failure(AiFailureReason.INVALID_RESPONSE, "Empty translation response.")
            val obj = JSONObject(jsonText)
            val arr = obj.optJSONArray("segments") ?: JSONArray()
            val translated = (0 until arr.length()).mapNotNull { i ->
                val item = arr.optJSONObject(i) ?: return@mapNotNull null
                TranslatedSegmentDto(
                    startMs = item.optLong("startMs"),
                    endMs = item.optLong("endMs"),
                    translatedText = item.optString("translatedText")
                )
            }
            AiResult.Success(translated, config.id, config.displayName)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "translateTranscript failed", e)
            classifyException(e)
        }
    }

    override suspend fun suggestBRollAndTakes(
        segments: List<TranscriptSegmentEntity>
    ): AiResult<CreatorInsightsResult> {
        return try {
            val formatted = segments.take(80).joinToString("\n") {
                "[${it.startMs}-${it.endMs}] ${it.speakerLabel}: ${it.text}"
            }
            val prompt = """
                Analyze this video transcript with timestamps:
                1. Suggest up to 5 B-roll moments (startMs, endMs, topic, visualPrompt, reason) where user-uploaded supporting footage would enhance storytelling.
                2. Detect any repeated takes or duplicate recording attempts (phraseSummary, keptStartMs, keptEndMs, redundantStartMs, redundantEndMs, reason). Only report genuine repetitions found in the transcript.
                Transcript:
                $formatted
            """.trimIndent()
            val response = withTimeout(45_000L) { insightsModel.generateContent(prompt) }
            val jsonText = response.text
                ?: return AiResult.Failure(AiFailureReason.INVALID_RESPONSE, "Empty creator insights response.")
            AiResult.Success(parseInsightsJson(jsonText), config.id, config.displayName)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "suggestBRollAndTakes failed", e)
            classifyException(e)
        }
    }

    private fun buildAnalysisPrompt(request: HighlightAnalysisRequest): String {
        return """
            You are CLIPFREE.AI's video intelligence analyzer.
            Analyze the attached real audio track (if present) and timestamped keyframes from "${request.videoTitle}".
            Actual video duration: ${request.videoDurationMs} ms.
            Target clip duration range: ${request.targetMinSeconds} to ${request.targetMaxSeconds} seconds.
            Target platform: ${request.targetPlatformLabel} (${request.aspectRatioLabel}).
            Preferred output language: ${request.preferredLanguage}.

            CRITICAL RULES:
            - Do NOT invent speech, quotes, or timestamps outside 0..${request.videoDurationMs} ms.
            - Every startMs and endMs MUST strictly fall inside 0..${request.videoDurationMs} with endMs > startMs.
            - Transcribe real spoken segments with accurate timestamps, speaker labels (e.g., Speaker 1, Speaker 2; never real-world names), and flag filler words/long pauses (isFillerOrSilence) or repeated takes (isRepeatedTake).
            - Identify 2 to 6 strongest short-form candidate clips (strong hooks, conversations, educational explanations, emotional moments, Q&A, quotes, storytelling, conclusions).
            - Assign a realistic viralityScore (0-100) with a clear scoreExplanation (never promise guaranteed views).
            - Generate logical video chapters and an AI-generated summary.
        """.trimIndent()
    }

    private fun classifyException(e: Exception): AiResult.Failure {
        if (e is TimeoutCancellationException) {
            return AiResult.Failure(
                AiFailureReason.TIMEOUT,
                "AI request timed out. Retrying or switching provider..."
            )
        }
        val fullMsg = generateSequence<Throwable>(e) { it.cause }
            .mapNotNull { it.localizedMessage ?: it.message }
            .distinct()
            .joinToString(" | ")
        val lower = fullMsg.lowercase()
        return when {
            lower.contains("429") ||
                lower.contains("402") ||
                lower.contains("resource_exhausted") ||
                lower.contains("quota") ||
                lower.contains("insufficient") ||
                lower.contains("credit") ||
                lower.contains("limit exceeded") ||
                lower.contains("billing") ->
                AiResult.Failure(AiFailureReason.QUOTA_EXHAUSTED, "API points/quota exhausted: $fullMsg", 429)
            lower.contains("rate") ->
                AiResult.Failure(AiFailureReason.RATE_LIMITED, "Rate limited: $fullMsg", 429)
            lower.contains("403") || lower.contains("401") || lower.contains("app check") || lower.contains("unauthenticated") ->
                AiResult.Failure(AiFailureReason.UNAUTHORIZED, "Authorization / App Check failed: $fullMsg", 403)
            lower.contains("unable to resolve host") || lower.contains("network") || lower.contains("failed to connect") ->
                AiResult.Failure(AiFailureReason.NETWORK_UNAVAILABLE, "No network connection available.")
            else ->
                AiResult.Failure(AiFailureReason.PROVIDER_ERROR, fullMsg.ifBlank { "Firebase AI request failed." })
        }
    }

    companion object {
        private val videoAnalysisSchema = Schema.obj(
            properties = mapOf(
                "summary" to Schema.string(description = "Concise AI summary of the video"),
                "chapters" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "title" to Schema.string(),
                            "startMs" to Schema.integer(),
                            "endMs" to Schema.integer(),
                            "summary" to Schema.string()
                        ),
                        optionalProperties = listOf("summary")
                    )
                ),
                "transcript" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "startMs" to Schema.integer(),
                            "endMs" to Schema.integer(),
                            "text" to Schema.string(),
                            "speakerLabel" to Schema.string(),
                            "language" to Schema.string(),
                            "isFillerOrSilence" to Schema.boolean(),
                            "isRepeatedTake" to Schema.boolean()
                        ),
                        optionalProperties = listOf(
                            "speakerLabel",
                            "language",
                            "isFillerOrSilence",
                            "isRepeatedTake"
                        )
                    )
                ),
                "clips" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "title" to Schema.string(),
                            "startMs" to Schema.integer(),
                            "endMs" to Schema.integer(),
                            "description" to Schema.string(),
                            "openingHook" to Schema.string(),
                            "reasonForSelection" to Schema.string(),
                            "viralityScore" to Schema.integer(),
                            "scoreExplanation" to Schema.string(),
                            "suggestedCaption" to Schema.string(),
                            "hashtags" to Schema.array(items = Schema.string()),
                            "language" to Schema.string(),
                            "speakerLabel" to Schema.string()
                        ),
                        optionalProperties = listOf(
                            "description",
                            "openingHook",
                            "reasonForSelection",
                            "suggestedCaption",
                            "hashtags",
                            "language",
                            "speakerLabel"
                        )
                    )
                )
            ),
            optionalProperties = listOf("summary", "chapters")
        )

        private val hooksMetadataSchema = Schema.obj(
            properties = mapOf(
                "titles" to Schema.array(items = Schema.string()),
                "captions" to Schema.array(items = Schema.string()),
                "hashtags" to Schema.array(items = Schema.string()),
                "shortSummary" to Schema.string(),
                "hooks" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "category" to Schema.string(),
                            "hookText" to Schema.string()
                        )
                    )
                )
            ),
            optionalProperties = listOf("shortSummary", "hashtags")
        )

        private val translationSchema = Schema.obj(
            properties = mapOf(
                "segments" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "startMs" to Schema.integer(),
                            "endMs" to Schema.integer(),
                            "translatedText" to Schema.string()
                        )
                    )
                )
            )
        )

        private val creatorInsightsSchema = Schema.obj(
            properties = mapOf(
                "bRollSuggestions" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "startMs" to Schema.integer(),
                            "endMs" to Schema.integer(),
                            "topic" to Schema.string(),
                            "visualPrompt" to Schema.string(),
                            "reason" to Schema.string()
                        ),
                        optionalProperties = listOf("visualPrompt", "reason")
                    )
                ),
                "repeatedTakes" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "phraseSummary" to Schema.string(),
                            "keptStartMs" to Schema.integer(),
                            "keptEndMs" to Schema.integer(),
                            "redundantStartMs" to Schema.integer(),
                            "redundantEndMs" to Schema.integer(),
                            "reason" to Schema.string()
                        ),
                        optionalProperties = listOf("reason")
                    )
                )
            ),
            optionalProperties = listOf("bRollSuggestions", "repeatedTakes")
        )

        fun parseAnalysisJson(jsonString: String, maxDurationMs: Long): VideoAnalysisResult {
            val cleaned = jsonString.trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()
            val root = JSONObject(cleaned)
            val summary = root.optString("summary", "")

            val chaptersArr = root.optJSONArray("chapters") ?: JSONArray()
            val chapters = (0 until chaptersArr.length()).mapNotNull { i ->
                val c = chaptersArr.optJSONObject(i) ?: return@mapNotNull null
                val start = c.optLong("startMs").coerceIn(0L, maxDurationMs)
                val end = c.optLong("endMs").coerceIn(start + 500L, maxDurationMs)
                if (end <= start) return@mapNotNull null
                VideoChapter(
                    title = c.optString("title", "Chapter ${i + 1}"),
                    startMs = start,
                    endMs = end,
                    summary = c.optString("summary", "")
                )
            }

            val transArr = root.optJSONArray("transcript") ?: JSONArray()
            val transcript = (0 until transArr.length()).mapNotNull { i ->
                val t = transArr.optJSONObject(i) ?: return@mapNotNull null
                val start = t.optLong("startMs").coerceIn(0L, maxDurationMs)
                val end = t.optLong("endMs").coerceIn(start + 200L, maxDurationMs)
                val text = t.optString("text", "").trim()
                if (text.isBlank() || end <= start) return@mapNotNull null
                DetectedTranscriptSegmentDto(
                    startMs = start,
                    endMs = end,
                    text = text,
                    speakerLabel = t.optString("speakerLabel", "Speaker 1"),
                    language = t.optString("language", "English"),
                    isFillerOrSilence = t.optBoolean("isFillerOrSilence", false),
                    isRepeatedTake = t.optBoolean("isRepeatedTake", false)
                )
            }

            val clipsArr = root.optJSONArray("clips") ?: JSONArray()
            val clips = (0 until clipsArr.length()).mapNotNull { i ->
                val cl = clipsArr.optJSONObject(i) ?: return@mapNotNull null
                val start = cl.optLong("startMs").coerceIn(0L, (maxDurationMs - 1000L).coerceAtLeast(0L))
                val end = cl.optLong("endMs").coerceIn(start + 1000L, maxDurationMs)
                if (end <= start) return@mapNotNull null
                val tagsArr = cl.optJSONArray("hashtags") ?: JSONArray()
                val hashtags = (0 until tagsArr.length()).mapNotNull { j ->
                    tagsArr.optString(j).takeIf { it.isNotBlank() }
                }
                DetectedClipDto(
                    title = cl.optString("title", "Highlight Clip ${i + 1}"),
                    startMs = start,
                    endMs = end,
                    description = cl.optString("description", ""),
                    openingHook = cl.optString("openingHook", ""),
                    reasonForSelection = cl.optString("reasonForSelection", ""),
                    viralityScore = cl.optInt("viralityScore", 70).coerceIn(0, 100),
                    scoreExplanation = cl.optString("scoreExplanation", ""),
                    suggestedCaption = cl.optString("suggestedCaption", ""),
                    hashtags = hashtags,
                    language = cl.optString("language", "English"),
                    speakerLabel = cl.optString("speakerLabel", "Speaker 1")
                )
            }.sortedByDescending { it.viralityScore }

            return VideoAnalysisResult(
                summary = summary,
                chapters = chapters,
                transcript = transcript,
                clips = clips
            )
        }

        fun parseHooksJson(jsonString: String): MetadataAndHooksResult {
            val cleaned = jsonString.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val root = JSONObject(cleaned)
            val titles = root.optJSONArray("titles").toStringList()
            val captions = root.optJSONArray("captions").toStringList()
            val hashtags = root.optJSONArray("hashtags").toStringList()
            val summary = root.optString("shortSummary", "")
            val hooksArr = root.optJSONArray("hooks") ?: JSONArray()
            val hooks = (0 until hooksArr.length()).mapNotNull { i ->
                val h = hooksArr.optJSONObject(i) ?: return@mapNotNull null
                HookOptionDto(
                    category = h.optString("category", "Curiosity"),
                    hookText = h.optString("hookText", "")
                ).takeIf { it.hookText.isNotBlank() }
            }
            return MetadataAndHooksResult(titles, captions, hashtags, hooks, summary)
        }

        fun parseInsightsJson(jsonString: String): CreatorInsightsResult {
            val cleaned = jsonString.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val root = JSONObject(cleaned)
            val bRollArr = root.optJSONArray("bRollSuggestions") ?: JSONArray()
            val bRolls = (0 until bRollArr.length()).mapNotNull { i ->
                val b = bRollArr.optJSONObject(i) ?: return@mapNotNull null
                BRollSuggestionDto(
                    startMs = b.optLong("startMs"),
                    endMs = b.optLong("endMs"),
                    topic = b.optString("topic"),
                    visualPrompt = b.optString("visualPrompt"),
                    reason = b.optString("reason")
                )
            }
            val takesArr = root.optJSONArray("repeatedTakes") ?: JSONArray()
            val takes = (0 until takesArr.length()).mapNotNull { i ->
                val t = takesArr.optJSONObject(i) ?: return@mapNotNull null
                RepeatedTakeSuggestionDto(
                    phraseSummary = t.optString("phraseSummary"),
                    keptStartMs = t.optLong("keptStartMs"),
                    keptEndMs = t.optLong("keptEndMs"),
                    redundantStartMs = t.optLong("redundantStartMs"),
                    redundantEndMs = t.optLong("redundantEndMs"),
                    reason = t.optString("reason")
                )
            }
            return CreatorInsightsResult(bRolls, takes)
        }

        private fun JSONArray?.toStringList(): List<String> {
            if (this == null) return emptyList()
            return (0 until length()).mapNotNull { optString(it).takeIf { s -> s.isNotBlank() } }
        }
    }
}
