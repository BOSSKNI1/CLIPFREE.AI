package com.example.ai

import android.graphics.Bitmap
import com.example.data.model.VideoChapter
import kotlinx.serialization.Serializable

enum class ProviderType(val id: String, val label: String, val defaultEndpoint: String, val defaultModel: String) {
    FIREBASE_AI_LOGIC("FIREBASE_AI_LOGIC", "Firebase AI Logic (Gemini)", "firebase://ai-logic", "gemini-3.8-flash"),
    GEMINI_REST("GEMINI_REST", "Gemini API (User Key)", "https://generativelanguage.googleapis.com/v1beta", "gemini-3.8-flash"),
    OPENAI_COMPATIBLE("OPENAI_COMPATIBLE", "OpenAI Compatible", "https://api.openai.com/v1", "gpt-4o-mini"),
    GROQ("GROQ", "Groq Cloud", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
    OPENROUTER("OPENROUTER", "OpenRouter", "https://openrouter.ai/api/v1", "google/gemini-2.0-flash-001"),
    CUSTOM_HTTP("CUSTOM_HTTP", "Custom AI Endpoint", "", "")
}

object ProviderStatus {
    const val AVAILABLE = "AVAILABLE"
    const val LIMITED = "LIMITED"
    const val QUOTA_EXHAUSTED = "QUOTA_EXHAUSTED"
    const val UNAUTHORIZED = "UNAUTHORIZED"
    const val OFFLINE = "OFFLINE"
    const val UNCONFIGURED = "UNCONFIGURED"
}

enum class AiOverallHealth(val label: String) {
    AI_AVAILABLE("AI Available"),
    TEMPORARILY_LIMITED("Temporarily Limited"),
    QUOTA_EXHAUSTED("Quota Exhausted"),
    OFFLINE_MODE("Offline Mode"),
    PROCESSING("Processing"),
    READY_TO_RETRY("Ready to Retry")
}

enum class AiFailureReason {
    QUOTA_EXHAUSTED,
    RATE_LIMITED,
    UNAUTHORIZED,
    TIMEOUT,
    NETWORK_UNAVAILABLE,
    PROVIDER_ERROR,
    INVALID_RESPONSE
}

sealed class AiResult<out T> {
    data class Success<T>(
        val data: T,
        val providerId: String,
        val providerName: String,
        val rateLimitRemaining: String? = null,
        val rateLimitReset: String? = null
    ) : AiResult<T>()

    data class Failure(
        val reason: AiFailureReason,
        val message: String,
        val httpCode: Int? = null,
        val rateLimitRemaining: String? = null,
        val rateLimitReset: String? = null
    ) : AiResult<Nothing>()
}

data class ProviderValidationResult(
    val isValid: Boolean,
    val status: String,
    val message: String,
    val rateLimitRemaining: String? = null,
    val rateLimitReset: String? = null
)

data class HighlightAnalysisRequest(
    val videoTitle: String,
    val videoDurationMs: Long,
    val targetMinSeconds: Int,
    val targetMaxSeconds: Int,
    val targetPlatformLabel: String,
    val aspectRatioLabel: String,
    val preferredLanguage: String,
    val audioBytes: ByteArray?,
    val audioMimeType: String = "audio/mp4",
    val keyframes: List<Pair<Long, Bitmap>>
)

@Serializable
data class DetectedTranscriptSegmentDto(
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val speakerLabel: String = "Speaker 1",
    val language: String = "English",
    val isFillerOrSilence: Boolean = false,
    val isRepeatedTake: Boolean = false
)

@Serializable
data class DetectedClipDto(
    val title: String,
    val startMs: Long,
    val endMs: Long,
    val description: String,
    val openingHook: String,
    val reasonForSelection: String,
    val viralityScore: Int,
    val scoreExplanation: String,
    val suggestedCaption: String,
    val hashtags: List<String> = emptyList(),
    val language: String = "English",
    val speakerLabel: String = "Speaker 1"
)

@Serializable
data class VideoAnalysisResult(
    val summary: String,
    val chapters: List<VideoChapter> = emptyList(),
    val transcript: List<DetectedTranscriptSegmentDto> = emptyList(),
    val clips: List<DetectedClipDto> = emptyList()
)

@Serializable
data class HookOptionDto(
    val category: String, // Curiosity, Question, Strong Statement, Educational, Storytelling
    val hookText: String
)

@Serializable
data class MetadataAndHooksResult(
    val titles: List<String> = emptyList(),
    val captions: List<String> = emptyList(),
    val hashtags: List<String> = emptyList(),
    val hooks: List<HookOptionDto> = emptyList(),
    val shortSummary: String = ""
)

@Serializable
data class TranslatedSegmentDto(
    val startMs: Long,
    val endMs: Long,
    val translatedText: String
)

@Serializable
data class BRollSuggestionDto(
    val startMs: Long,
    val endMs: Long,
    val topic: String,
    val visualPrompt: String,
    val reason: String
)

@Serializable
data class RepeatedTakeSuggestionDto(
    val phraseSummary: String,
    val keptStartMs: Long,
    val keptEndMs: Long,
    val redundantStartMs: Long,
    val redundantEndMs: Long,
    val reason: String
)

@Serializable
data class CreatorInsightsResult(
    val bRollSuggestions: List<BRollSuggestionDto> = emptyList(),
    val repeatedTakes: List<RepeatedTakeSuggestionDto> = emptyList()
)
