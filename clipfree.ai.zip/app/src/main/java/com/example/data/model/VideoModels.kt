package com.example.data.model

import kotlinx.serialization.Serializable

enum class AspectRatioOption(
    val id: String,
    val label: String,
    val widthRatio: Int,
    val heightRatio: Int,
    val targetWidth1080: Int,
    val targetHeight1080: Int
) {
    RATIO_9_16("9:16", "9:16 Vertical", 9, 16, 1080, 1920),
    RATIO_16_9("16:9", "16:9 Landscape", 16, 9, 1920, 1080),
    RATIO_1_1("1:1", "1:1 Square", 1, 1, 1080, 1080),
    RATIO_4_5("4:5", "4:5 Portrait", 4, 5, 1080, 1350);

    companion object {
        fun fromId(id: String): AspectRatioOption =
            entries.firstOrNull { it.id == id } ?: RATIO_9_16
    }
}

enum class SocialPlatform(
    val id: String,
    val label: String,
    val recommendedAspect: AspectRatioOption,
    val maxDurationSec: Int
) {
    YOUTUBE_SHORTS("youtube_shorts", "YouTube Shorts", AspectRatioOption.RATIO_9_16, 60),
    INSTAGRAM_REELS("instagram_reels", "Instagram Reels", AspectRatioOption.RATIO_9_16, 90),
    TIKTOK("tiktok", "TikTok", AspectRatioOption.RATIO_9_16, 60),
    FACEBOOK_REELS("facebook_reels", "Facebook Reels", AspectRatioOption.RATIO_9_16, 90),
    CUSTOM("custom", "Custom Format", AspectRatioOption.RATIO_9_16, 180)
}

enum class DurationPreset(
    val id: String,
    val label: String,
    val minSeconds: Int,
    val maxSeconds: Int
) {
    SHORT_15_30("15-30s", "15–30 sec", 15, 30),
    MEDIUM_30_45("30-45s", "30–45 sec", 30, 45),
    LONG_45_60("45-60s", "45–60 sec", 45, 60),
    EXTENDED_60_90("60-90s", "60–90 sec", 60, 90),
    CUSTOM("custom", "Custom", 10, 120);

    companion object {
        fun fromId(id: String): DurationPreset =
            entries.firstOrNull { it.id == id } ?: MEDIUM_30_45
    }
}

enum class CaptionAnimationStyle(val id: String, val label: String) {
    WORD_BY_WORD("word_by_word", "Word-by-Word Pop"),
    KARAOKE("karaoke", "Karaoke Highlight"),
    BOLD_CREATOR("bold_creator", "Bold Creator"),
    MINIMAL("minimal", "Minimal Clean"),
    HIGHLIGHTED_KEYWORDS("keywords", "Keyword Accent"),
    SPEAKER_COLORED("speaker_colored", "Speaker Colors");

    companion object {
        fun fromId(id: String): CaptionAnimationStyle =
            entries.firstOrNull { it.id == id } ?: BOLD_CREATOR
    }
}

@Serializable
data class CaptionStyleConfig(
    val styleId: String = CaptionAnimationStyle.BOLD_CREATOR.id,
    val fontName: String = "Space Grotesk",
    val fontSizeSp: Float = 22f,
    val textColorHex: String = "#FFFFFF",
    val highlightColorHex: String = "#9878FF",
    val backgroundColorHex: String = "#17151F",
    val backgroundAlpha: Float = 0.68f,
    val positionYFraction: Float = 0.78f,
    val lineSpacingMultiplier: Float = 1.2f,
    val enabled: Boolean = true,
    val speakerColors: Map<String, String> = mapOf(
        "Speaker 1" to "#9878FF",
        "Speaker 2" to "#38BDF8",
        "Speaker 3" to "#34D399"
    )
)

@Serializable
data class TimeRangeMs(
    val startMs: Long,
    val endMs: Long,
    val label: String = ""
)

@Serializable
data class BRollOverlaySpec(
    val id: String,
    val mediaUri: String,
    val title: String,
    val startMs: Long,
    val endMs: Long,
    val cropMode: String = "Center Crop",
    val opacity: Float = 1.0f
)

@Serializable
data class ClipEditTimeline(
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 0L,
    val excludedRanges: List<TimeRangeMs> = emptyList(),
    val splitPointsMs: List<Long> = emptyList(),
    val cropOffsetX: Float = 0f,
    val cropOffsetY: Float = 0f,
    val zoomScale: Float = 1.0f,
    val autoZoomEnabled: Boolean = false,
    val autoZoomIntensity: Float = 0.12f,
    val rotationDegrees: Int = 0,
    val audioGain: Float = 1.0f,
    val voiceEnhancement: Boolean = false,
    val noiseReduction: Boolean = false,
    val normalizeAudio: Boolean = false,
    val bgmUri: String? = null,
    val bgmTitle: String? = null,
    val bgmVolume: Float = 0.25f,
    val bgmFadeInMs: Long = 800L,
    val bgmFadeOutMs: Long = 1000L,
    val bgmDucking: Boolean = true,
    val bRollOverlays: List<BRollOverlaySpec> = emptyList(),
    val introText: String = "",
    val introDurationMs: Long = 0L,
    val outroText: String = "",
    val outroDurationMs: Long = 0L,
    val transitionType: String = "Crossfade",
    val brandKitId: Long? = null,
    val textOverlay: String = "",
    val watermarkText: String = ""
)

@Serializable
data class TranscriptWord(
    val word: String,
    val startMs: Long,
    val endMs: Long,
    val isFiller: Boolean = false
)

@Serializable
data class VideoChapter(
    val title: String,
    val startMs: Long,
    val endMs: Long,
    val summary: String = ""
)

enum class ExportResolution(val id: String, val label: String, val shortSidePx: Int) {
    RES_720P("720p", "720p HD", 720),
    RES_1080P("1080p", "1080p Full HD", 1080),
    RES_4K("4K", "4K Ultra HD", 2160);

    companion object {
        fun fromId(id: String): ExportResolution =
            entries.firstOrNull { it.id == id } ?: RES_1080P
    }
}

data class DeviceCapabilities(
    val supports4kEncode: Boolean,
    val supportsHevc: Boolean,
    val maxSupportedWidth: Int,
    val maxSupportedHeight: Int,
    val availableStorageBytes: Long
)
