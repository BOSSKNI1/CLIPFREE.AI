package com.example.data.cloud

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.R
import com.example.core.AppPreferences
import com.example.core.PreferencesManager
import com.example.data.local.BrandKitEntity
import com.example.data.local.ClipFreeDatabase
import com.example.data.local.CreatorTemplateEntity
import com.example.data.local.ExportStatus
import com.example.data.local.GeneratedClipEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.ProjectStatus
import com.example.data.model.CaptionStyleConfig
import com.example.data.model.ClipEditTimeline
import com.example.data.model.VideoChapter
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

sealed interface CloudSyncStatus {
    data object Idle : CloudSyncStatus
    data object Syncing : CloudSyncStatus
    data class Synced(
        val syncedAtMs: Long,
        val projectsCount: Int,
        val clipsCount: Int
    ) : CloudSyncStatus
    data class Error(val message: String) : CloudSyncStatus
}

data class CloudSyncSummary(
    val projectsSynced: Int,
    val clipsSynced: Int,
    val brandKitsSynced: Int,
    val templatesSynced: Int
)

class CloudSyncRepository(
    private val db: FirebaseFirestore,
    context: Context,
    private val localDb: ClipFreeDatabase,
    private val preferences: PreferencesManager,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(
        context: Context,
        localDb: ClipFreeDatabase,
        preferences: PreferencesManager
    ) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        context = context.applicationContext,
        localDb = localDb,
        preferences = preferences
    )

    private val appContext = context.applicationContext
    private val json = Json { ignoreUnknownKeys = true }
    private val syncMutex = Mutex()
    private val accountPrefs: SharedPreferences =
        appContext.getSharedPreferences("clipfree_cloud_account_state", Context.MODE_PRIVATE)

    private val _syncStatus = MutableStateFlow<CloudSyncStatus>(CloudSyncStatus.Idle)
    val syncStatus: StateFlow<CloudSyncStatus> = _syncStatus.asStateFlow()

    private fun requireUserId(): String {
        val uid = auth.currentUser?.uid
        if (uid.isNullOrBlank()) {
            throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
        }
        return uid
    }

    private fun idMapPrefs(uid: String): SharedPreferences =
        appContext.getSharedPreferences("clipfree_cloud_map_$uid", Context.MODE_PRIVATE)

    fun observeUserProfile(userId: String): Flow<CloudUserProfile?> = flow {
        val currentUid = auth.currentUser?.uid
        if (currentUid.isNullOrBlank() || currentUid != userId) {
            emit(null)
            return@flow
        }
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObject(
                        CloudUserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    suspend fun handleAccountSessionReady(user: FirebaseUser): Result<CloudSyncSummary> = syncMutex.withLock {
        val uid = user.uid
        if (uid.isBlank()) {
            return@withLock Result.failure(IllegalStateException("Authenticated user UID is blank."))
        }
        val previousUid = accountPrefs.getString(KEY_LAST_SIGNED_IN_UID, null)
        if (previousUid != null && previousUid != uid) {
            // Isolate local user metadata when switching Google accounts on the same device
            withContext(Dispatchers.IO) {
                localDb.projectDao().deleteAllProjects()
                localDb.brandKitDao().deleteAllBrandKits()
                localDb.templateDao().deleteAllCustomTemplates()
                localDb.libraryAssetDao().clearAll()
            }
        }
        accountPrefs.edit().putString(KEY_LAST_SIGNED_IN_UID, uid).apply()

        val profileRes = ensureUserProfileInternal(user)
        if (profileRes.isFailure) {
            return@withLock Result.failure(
                profileRes.exceptionOrNull() ?: IllegalStateException("Failed to sync user profile")
            )
        }
        return@withLock syncNowInternal(uid)
    }

    suspend fun syncNow(): Result<CloudSyncSummary> = syncMutex.withLock {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return@withLock Result.failure(e)
        }
        return@withLock syncNowInternal(uid)
    }

    suspend fun syncPreferencesToCloud(prefs: AppPreferences): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val docRef = db.collection("users").document(uid)
        return try {
            val snapshot = docRef.get().await()
            if (snapshot.exists()) {
                docRef.update(
                    mapOf(
                        "preferredLanguage" to prefs.preferredLanguage.ifBlank { "English" }.take(40),
                        "defaultResolution" to prefs.defaultResolution.ifBlank { "1080p" }.take(20),
                        "defaultAspectRatio" to prefs.defaultAspectRatio.ifBlank { "9:16" }.take(20),
                        "autosaveEnabled" to prefs.autosaveEnabled,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun pushProjectAndClips(projectId: Long): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val project = localDb.projectDao().getProjectById(projectId) ?: return Result.success(Unit)
        val clips = localDb.clipDao().getClipsForProject(projectId)
        val mapPrefs = idMapPrefs(uid)

        val cloudProjectId = getOrAssignCloudId(mapPrefs, "proj_${project.id}")
        val projRef = db.collection("users").document(uid)
            .collection("projects").document(cloudProjectId)

        return try {
            check(auth.currentUser?.uid == uid) { "Signed-in user changed; aborting push." }
            val cloudModel = project.toCloudProject(uid, cloudProjectId)
            val existingProj = projRef.get().await()
            if (existingProj.exists()) {
                projRef.update(cloudModel.toUpdateMap()).await()
            } else {
                projRef.set(cloudModel.toCreateMap(uid)).await()
            }

            clips.forEach { clip ->
                val cloudClipId = getOrAssignCloudId(mapPrefs, "clip_${clip.id}")
                val clipRef = projRef.collection("clips").document(cloudClipId)
                val cloudClip = clip.toCloudClip(uid, cloudProjectId, cloudClipId)
                val existingClip = clipRef.get().await()
                if (existingClip.exists()) {
                    clipRef.update(cloudClip.toUpdateMap()).await()
                } else {
                    clipRef.set(cloudClip.toCreateMap(uid, cloudProjectId)).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, projRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteCloudProject(localProjectId: Long): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val mapPrefs = idMapPrefs(uid)
        val cloudProjectId = mapPrefs.getString("proj_$localProjectId", null) ?: return Result.success(Unit)
        val projRef = db.collection("users").document(uid).collection("projects").document(cloudProjectId)
        return try {
            val clipSnaps = projRef.collection("clips").get().await()
            clipSnaps.documents.forEach { doc ->
                doc.reference.delete().await()
            }
            projRef.delete().await()
            mapPrefs.edit()
                .remove("proj_$localProjectId")
                .remove("rev_proj_$cloudProjectId")
                .apply()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, projRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteCloudClip(localProjectId: Long, localClipId: Long): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val mapPrefs = idMapPrefs(uid)
        val cloudProjectId = mapPrefs.getString("proj_$localProjectId", null) ?: return Result.success(Unit)
        val cloudClipId = mapPrefs.getString("clip_$localClipId", null) ?: return Result.success(Unit)
        val clipRef = db.collection("users").document(uid)
            .collection("projects").document(cloudProjectId)
            .collection("clips").document(cloudClipId)
        return try {
            clipRef.delete().await()
            mapPrefs.edit()
                .remove("clip_$localClipId")
                .remove("rev_clip_$cloudClipId")
                .apply()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, clipRef.path)
            Result.failure(e)
        }
    }

    suspend fun pushBrandKit(kit: BrandKitEntity): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        if (kit.id <= 0L) return Result.success(Unit)
        val mapPrefs = idMapPrefs(uid)
        val cloudKitId = getOrAssignCloudId(mapPrefs, "kit_${kit.id}")
        val docRef = db.collection("users").document(uid).collection("brandKits").document(cloudKitId)
        return try {
            val cloudKit = kit.toCloudBrandKit(uid, cloudKitId)
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(cloudKit.toUpdateMap()).await()
            } else {
                docRef.set(cloudKit.toCreateMap(uid)).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteCloudBrandKit(localKitId: Long): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val mapPrefs = idMapPrefs(uid)
        val cloudKitId = mapPrefs.getString("kit_$localKitId", null) ?: return Result.success(Unit)
        val docRef = db.collection("users").document(uid).collection("brandKits").document(cloudKitId)
        return try {
            docRef.delete().await()
            mapPrefs.edit()
                .remove("kit_$localKitId")
                .remove("rev_kit_$cloudKitId")
                .apply()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun pushCustomTemplate(template: CreatorTemplateEntity): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        if (template.isBuiltIn || template.id <= 0L) return Result.success(Unit)
        val mapPrefs = idMapPrefs(uid)
        val cloudTplId = getOrAssignCloudId(mapPrefs, "tpl_${template.id}")
        val docRef = db.collection("users").document(uid).collection("templates").document(cloudTplId)
        return try {
            val cloudTpl = template.toCloudTemplate(uid, cloudTplId)
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(cloudTpl.toUpdateMap()).await()
            } else {
                docRef.set(cloudTpl.toCreateMap(uid)).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteCloudTemplate(localTemplateId: Long): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val mapPrefs = idMapPrefs(uid)
        val cloudTplId = mapPrefs.getString("tpl_$localTemplateId", null) ?: return Result.success(Unit)
        val docRef = db.collection("users").document(uid).collection("templates").document(cloudTplId)
        return try {
            docRef.delete().await()
            mapPrefs.edit()
                .remove("tpl_$localTemplateId")
                .remove("rev_tpl_$cloudTplId")
                .apply()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    fun resetStatusOnSignOut() {
        _syncStatus.value = CloudSyncStatus.Idle
    }

    private suspend fun ensureUserProfileInternal(user: FirebaseUser): Result<Unit> {
        val uid = user.uid
        val docRef = db.collection("users").document(uid)
        return try {
            val prefs = preferences.preferencesFlow.first()
            val displayName = (user.displayName?.takeIf { it.isNotBlank() }
                ?: user.email?.substringBefore('@')
                ?: "Creator").take(120)
            val email = user.email?.takeIf { it.isNotBlank() }?.take(254)
            val photoUrl = user.photoUrl?.toString()?.takeIf { it.isNotBlank() }?.take(1000)

            val snap = docRef.get().await()
            if (snap.exists()) {
                val updates = mapOf(
                    "displayName" to displayName,
                    "email" to email,
                    "photoUrl" to photoUrl,
                    "updatedAt" to FieldValue.serverTimestamp()
                ).withoutNulls()
                docRef.update(updates).await()
            } else {
                val createPayload = mapOf(
                    "uid" to uid,
                    "displayName" to displayName,
                    "email" to email,
                    "photoUrl" to photoUrl,
                    "preferredLanguage" to prefs.preferredLanguage.ifBlank { "English" }.take(40),
                    "defaultResolution" to prefs.defaultResolution.ifBlank { "1080p" }.take(20),
                    "defaultAspectRatio" to prefs.defaultAspectRatio.ifBlank { "9:16" }.take(20),
                    "autosaveEnabled" to prefs.autosaveEnabled,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).withoutNulls()
                docRef.set(createPayload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    private suspend fun syncNowInternal(uid: String): Result<CloudSyncSummary> {
        _syncStatus.value = CloudSyncStatus.Syncing
        val userDoc = db.collection("users").document(uid)
        return try {
            check(auth.currentUser?.uid == uid) { "User session changed during sync." }
            val mapPrefs = idMapPrefs(uid)

            // 1. Pull cloud projects & clips first, merging newer cloud entries into Room
            val cloudProjSnaps = userDoc.collection("projects").get().await()
            val cloudProjects = cloudProjSnaps.toObjects(
                CloudProject::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            val localProjectsById = localDb.projectDao().getAllProjects().associateBy { it.id }.toMutableMap()

            for (cp in cloudProjects) {
                val mappedLocalId = mapPrefs.getLong("rev_proj_${cp.id}", -1L)
                val existingLocal = if (mappedLocalId > 0L) localProjectsById[mappedLocalId] else null
                val targetLocalId: Long
                if (existingLocal == null) {
                    val inserted = ProjectEntity(
                        title = cp.title.ifBlank { "Synced Project" },
                        sourceUri = "",
                        sourceDisplayName = cp.sourceDisplayName,
                        durationMs = cp.durationMs,
                        width = cp.width,
                        height = cp.height,
                        rotationDegrees = cp.rotationDegrees,
                        hasAudio = cp.hasAudio,
                        fileSizeBytes = cp.fileSizeBytes,
                        aspectRatio = cp.aspectRatio,
                        targetPlatform = cp.targetPlatform,
                        durationPreset = cp.durationPreset,
                        captionStyleId = cp.captionStyleId,
                        status = if (cp.status in ALLOWED_STATUSES) cp.status else ProjectStatus.IMPORTED,
                        summaryText = cp.summaryText,
                        chaptersJson = encodeChaptersJson(cp.chapters),
                        sourceMissing = true,
                        activeProviderUsed = cp.activeProviderUsed,
                        createdAt = cp.clientCreatedAtMs.takeIf { it > 0L } ?: System.currentTimeMillis(),
                        updatedAt = cp.clientUpdatedAtMs.takeIf { it > 0L } ?: System.currentTimeMillis()
                    )
                    targetLocalId = localDb.projectDao().insertProject(inserted)
                    mapPrefs.edit()
                        .putString("proj_$targetLocalId", cp.id)
                        .putLong("rev_proj_${cp.id}", targetLocalId)
                        .apply()
                    localProjectsById[targetLocalId] = inserted.copy(id = targetLocalId)
                } else {
                    targetLocalId = existingLocal.id
                    if (cp.clientUpdatedAtMs > existingLocal.updatedAt) {
                        val updated = existingLocal.copy(
                            title = cp.title.ifBlank { existingLocal.title },
                            aspectRatio = cp.aspectRatio,
                            targetPlatform = cp.targetPlatform,
                            durationPreset = cp.durationPreset,
                            captionStyleId = cp.captionStyleId,
                            status = if (cp.status in ALLOWED_STATUSES) cp.status else existingLocal.status,
                            summaryText = cp.summaryText.ifBlank { existingLocal.summaryText },
                            chaptersJson = if (cp.chapters.isNotEmpty()) encodeChaptersJson(cp.chapters) else existingLocal.chaptersJson,
                            updatedAt = cp.clientUpdatedAtMs
                        )
                        localDb.projectDao().updateProject(updated)
                        localProjectsById[targetLocalId] = updated
                    }
                }

                // Pull clips for this project
                val cloudClipSnaps = userDoc.collection("projects").document(cp.id)
                    .collection("clips").get().await()
                val cloudClips = cloudClipSnaps.toObjects(
                    CloudClip::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                val existingLocalClips = localDb.clipDao().getClipsForProject(targetLocalId).associateBy { it.id }
                for (cc in cloudClips) {
                    val mappedClipId = mapPrefs.getLong("rev_clip_${cc.id}", -1L)
                    val localClip = if (mappedClipId > 0L) existingLocalClips[mappedClipId] else null
                    if (localClip == null) {
                        val styleJson = json.encodeToString(CaptionStyleConfig(styleId = cc.captionStyleId))
                        val timelineJson = json.encodeToString(
                            ClipEditTimeline(trimStartMs = cc.trimStartMs, trimEndMs = cc.trimEndMs)
                        )
                        val newClip = GeneratedClipEntity(
                            projectId = targetLocalId,
                            title = cc.title,
                            startMs = cc.startMs,
                            endMs = cc.endMs,
                            viralityScore = cc.viralityScore,
                            scoreExplanation = cc.scoreExplanation,
                            openingHook = cc.openingHook,
                            reasonForSelection = cc.reasonForSelection,
                            description = cc.description,
                            suggestedCaption = cc.suggestedCaption,
                            hashtagsJson = json.encodeToString(cc.hashtags),
                            language = cc.language,
                            speakerLabel = cc.speakerLabel,
                            aspectRatio = cc.aspectRatio,
                            captionStyleJson = styleJson,
                            editTimelineJson = timelineJson,
                            exportStatus = ExportStatus.DRAFT,
                            isAiGenerated = cc.aiGenerated,
                            createdAt = cc.clientCreatedAtMs.takeIf { it > 0L } ?: System.currentTimeMillis(),
                            updatedAt = cc.clientUpdatedAtMs.takeIf { it > 0L } ?: System.currentTimeMillis()
                        )
                        val insertedClipId = localDb.clipDao().insertClip(newClip)
                        mapPrefs.edit()
                            .putString("clip_$insertedClipId", cc.id)
                            .putLong("rev_clip_${cc.id}", insertedClipId)
                            .apply()
                    } else if (cc.clientUpdatedAtMs > localClip.updatedAt) {
                        val timeline = runCatching {
                            json.decodeFromString<ClipEditTimeline>(localClip.editTimelineJson)
                        }.getOrDefault(ClipEditTimeline()).copy(
                            trimStartMs = cc.trimStartMs,
                            trimEndMs = cc.trimEndMs
                        )
                        localDb.clipDao().updateClip(
                            localClip.copy(
                                title = cc.title,
                                aspectRatio = cc.aspectRatio,
                                suggestedCaption = cc.suggestedCaption,
                                hashtagsJson = json.encodeToString(cc.hashtags),
                                editTimelineJson = json.encodeToString(timeline),
                                updatedAt = cc.clientUpdatedAtMs
                            )
                        )
                    }
                }
            }

            // 2. Push local projects & clips to cloud
            val localProjects = localDb.projectDao().getAllProjects()
            var totalClipsSynced = 0
            val cloudProjIdsSet = cloudProjects.map { it.id }.toSet()

            for (proj in localProjects) {
                val cloudProjId = getOrAssignCloudId(mapPrefs, "proj_${proj.id}", "rev_proj", proj.id)
                val projRef = userDoc.collection("projects").document(cloudProjId)
                val cloudModel = proj.toCloudProject(uid, cloudProjId)
                if (cloudProjId in cloudProjIdsSet) {
                    val cloudUpdatedMs = cloudProjects.firstOrNull { it.id == cloudProjId }?.clientUpdatedAtMs ?: 0L
                    if (proj.updatedAt >= cloudUpdatedMs) {
                        projRef.update(cloudModel.toUpdateMap()).await()
                    }
                } else {
                    projRef.set(cloudModel.toCreateMap(uid)).await()
                }

                val localClips = localDb.clipDao().getClipsForProject(proj.id)
                val existingCloudClips = projRef.collection("clips").get().await().documents.map { it.id }.toSet()
                for (clip in localClips) {
                    val cloudClipId = getOrAssignCloudId(mapPrefs, "clip_${clip.id}", "rev_clip", clip.id)
                    val clipRef = projRef.collection("clips").document(cloudClipId)
                    val cloudClip = clip.toCloudClip(uid, cloudProjId, cloudClipId)
                    if (cloudClipId in existingCloudClips) {
                        clipRef.update(cloudClip.toUpdateMap()).await()
                    } else {
                        clipRef.set(cloudClip.toCreateMap(uid, cloudProjId)).await()
                    }
                    totalClipsSynced++
                }
            }

            // 3. Sync brand kits
            val cloudKits = userDoc.collection("brandKits").get().await()
                .toObjects(CloudBrandKit::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            val existingLocalKits = localDb.brandKitDao().getAllBrandKits().associateBy { it.id }
            for (ck in cloudKits) {
                val mappedId = mapPrefs.getLong("rev_kit_${ck.id}", -1L)
                if (mappedId <= 0L || mappedId !in existingLocalKits) {
                    val newId = localDb.brandKitDao().insert(
                        BrandKitEntity(
                            name = ck.name,
                            primaryColorHex = ck.primaryColorHex,
                            secondaryColorHex = ck.secondaryColorHex,
                            fontName = ck.fontName,
                            captionStyleId = ck.captionStyleId,
                            introText = ck.introText,
                            outroText = ck.outroText,
                            ctaText = ck.ctaText,
                            watermarkEnabled = ck.watermarkEnabled,
                            watermarkText = ck.watermarkText,
                            isDefault = ck.defaultKit,
                            createdAt = ck.clientCreatedAtMs.takeIf { it > 0L } ?: System.currentTimeMillis()
                        )
                    )
                    mapPrefs.edit()
                        .putString("kit_$newId", ck.id)
                        .putLong("rev_kit_${ck.id}", newId)
                        .apply()
                }
            }
            val localKits = localDb.brandKitDao().getAllBrandKits()
            val cloudKitIds = cloudKits.map { it.id }.toSet()
            for (kit in localKits) {
                val cloudKitId = getOrAssignCloudId(mapPrefs, "kit_${kit.id}", "rev_kit", kit.id)
                val kitRef = userDoc.collection("brandKits").document(cloudKitId)
                val cloudKit = kit.toCloudBrandKit(uid, cloudKitId)
                if (cloudKitId in cloudKitIds) {
                    kitRef.update(cloudKit.toUpdateMap()).await()
                } else {
                    kitRef.set(cloudKit.toCreateMap(uid)).await()
                }
            }

            // 4. Sync custom templates (built-in templates are seeded locally)
            val cloudTemplates = userDoc.collection("templates").get().await()
                .toObjects(CloudTemplate::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            val existingLocalTpls = localDb.templateDao().getAllTemplates().associateBy { it.id }
            for (ct in cloudTemplates) {
                val mappedId = mapPrefs.getLong("rev_tpl_${ct.id}", -1L)
                if (mappedId <= 0L || mappedId !in existingLocalTpls) {
                    val newId = localDb.templateDao().insert(
                        CreatorTemplateEntity(
                            name = ct.name,
                            category = ct.category,
                            captionStyleId = ct.captionStyleId,
                            fontName = ct.fontName,
                            primaryColorHex = ct.primaryColorHex,
                            accentColorHex = ct.accentColorHex,
                            aspectRatio = ct.aspectRatio,
                            autoZoomEnabled = ct.autoZoomEnabled,
                            introText = ct.introText,
                            outroText = ct.outroText,
                            isBuiltIn = false
                        )
                    )
                    mapPrefs.edit()
                        .putString("tpl_$newId", ct.id)
                        .putLong("rev_tpl_${ct.id}", newId)
                        .apply()
                }
            }
            val customTemplates = localDb.templateDao().getAllTemplates().filter { !it.isBuiltIn }
            val cloudTplIds = cloudTemplates.map { it.id }.toSet()
            for (tpl in customTemplates) {
                val cloudTplId = getOrAssignCloudId(mapPrefs, "tpl_${tpl.id}", "rev_tpl", tpl.id)
                val tplRef = userDoc.collection("templates").document(cloudTplId)
                val cloudTpl = tpl.toCloudTemplate(uid, cloudTplId)
                if (cloudTplId in cloudTplIds) {
                    tplRef.update(cloudTpl.toUpdateMap()).await()
                } else {
                    tplRef.set(cloudTpl.toCreateMap(uid)).await()
                }
            }

            val summary = CloudSyncSummary(
                projectsSynced = localProjects.size,
                clipsSynced = totalClipsSynced,
                brandKitsSynced = localKits.size,
                templatesSynced = customTemplates.size
            )
            _syncStatus.value = CloudSyncStatus.Synced(
                syncedAtMs = System.currentTimeMillis(),
                projectsCount = summary.projectsSynced,
                clipsCount = summary.clipsSynced
            )
            Result.success(summary)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Cloud sync failed", e)
            handleFirestoreError(e, OperationType.WRITE, userDoc.path)
            _syncStatus.value = CloudSyncStatus.Error(
                e.localizedMessage ?: "Cloud backup sync failed"
            )
            Result.failure(e)
        }
    }

    private fun getOrAssignCloudId(
        prefs: SharedPreferences,
        key: String,
        reversePrefix: String? = null,
        localId: Long = -1L
    ): String {
        val existing = prefs.getString(key, null)
        if (!existing.isNullOrBlank()) return existing
        val generated = UUID.randomUUID().toString()
        prefs.edit().apply {
            putString(key, generated)
            if (reversePrefix != null && localId > 0L) {
                putLong("${reversePrefix}_$generated", localId)
            }
        }.apply()
        return generated
    }

    private fun ProjectEntity.toCloudProject(uid: String, cloudId: String): CloudProject {
        val chaptersList = runCatching {
            json.decodeFromString<List<VideoChapter>>(chaptersJson)
                .map { "${it.title}: ${it.summary}".trim(':', ' ').take(300) }
                .filter { it.isNotBlank() }
        }.getOrDefault(emptyList())
        return CloudProject(
            id = cloudId,
            userId = uid,
            localProjectId = id,
            title = title,
            sourceDisplayName = sourceDisplayName,
            durationMs = durationMs,
            width = width,
            height = height,
            rotationDegrees = rotationDegrees,
            hasAudio = hasAudio,
            fileSizeBytes = fileSizeBytes,
            aspectRatio = aspectRatio,
            targetPlatform = targetPlatform,
            durationPreset = durationPreset,
            captionStyleId = captionStyleId,
            status = status,
            summaryText = summaryText,
            chapters = chaptersList,
            activeProviderUsed = activeProviderUsed,
            clientCreatedAtMs = createdAt,
            clientUpdatedAtMs = updatedAt
        )
    }

    private fun GeneratedClipEntity.toCloudClip(
        uid: String,
        cloudProjectId: String,
        cloudClipId: String
    ): CloudClip {
        val styleConfig = runCatching {
            json.decodeFromString<CaptionStyleConfig>(captionStyleJson)
        }.getOrDefault(CaptionStyleConfig())
        val timeline = runCatching {
            json.decodeFromString<ClipEditTimeline>(editTimelineJson)
        }.getOrDefault(ClipEditTimeline(trimStartMs = startMs, trimEndMs = endMs))
        val tags = runCatching {
            json.decodeFromString<List<String>>(hashtagsJson)
        }.getOrDefault(emptyList())

        return CloudClip(
            id = cloudClipId,
            userId = uid,
            projectId = cloudProjectId,
            title = title,
            startMs = startMs,
            endMs = endMs,
            viralityScore = viralityScore,
            scoreExplanation = scoreExplanation,
            openingHook = openingHook,
            reasonForSelection = reasonForSelection,
            description = description,
            suggestedCaption = suggestedCaption,
            hashtags = tags,
            language = language,
            speakerLabel = speakerLabel,
            aspectRatio = aspectRatio,
            captionStyleId = styleConfig.styleId,
            trimStartMs = timeline.trimStartMs,
            trimEndMs = timeline.trimEndMs,
            aiGenerated = isAiGenerated,
            exportStatus = exportStatus,
            clientCreatedAtMs = createdAt,
            clientUpdatedAtMs = updatedAt
        )
    }

    private fun BrandKitEntity.toCloudBrandKit(uid: String, cloudKitId: String) = CloudBrandKit(
        id = cloudKitId,
        userId = uid,
        name = name,
        primaryColorHex = primaryColorHex,
        secondaryColorHex = secondaryColorHex,
        fontName = fontName,
        captionStyleId = captionStyleId,
        introText = introText,
        outroText = outroText,
        ctaText = ctaText,
        watermarkEnabled = watermarkEnabled,
        watermarkText = watermarkText,
        defaultKit = isDefault,
        clientCreatedAtMs = createdAt
    )

    private fun CreatorTemplateEntity.toCloudTemplate(uid: String, cloudTplId: String) = CloudTemplate(
        id = cloudTplId,
        userId = uid,
        name = name,
        category = category,
        captionStyleId = captionStyleId,
        fontName = fontName,
        primaryColorHex = primaryColorHex,
        accentColorHex = accentColorHex,
        aspectRatio = aspectRatio,
        autoZoomEnabled = autoZoomEnabled,
        introText = introText,
        outroText = outroText
    )

    private fun encodeChaptersJson(chapters: List<String>): String {
        if (chapters.isEmpty()) return "[]"
        val objs = chapters.mapIndexed { idx, line ->
            val parts = line.split(":", limit = 2)
            VideoChapter(
                title = parts.firstOrNull()?.trim().orEmpty().ifBlank { "Chapter ${idx + 1}" },
                startMs = idx * 1000L,
                endMs = (idx + 1) * 1000L,
                summary = parts.getOrNull(1)?.trim().orEmpty()
            )
        }
        return json.encodeToString(objs)
    }

    companion object {
        private const val TAG = "CloudSyncRepo"
        private const val KEY_LAST_SIGNED_IN_UID = "last_signed_in_uid"
        private val ALLOWED_STATUSES = setOf(
            ProjectStatus.IMPORTED,
            ProjectStatus.ANALYZING,
            ProjectStatus.READY,
            ProjectStatus.LOCAL_ONLY,
            ProjectStatus.ERROR
        )
    }
}
