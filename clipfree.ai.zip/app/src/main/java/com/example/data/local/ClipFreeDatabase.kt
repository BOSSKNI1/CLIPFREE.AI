package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProjectEntity::class,
        TranscriptSegmentEntity::class,
        GeneratedClipEntity::class,
        BrandKitEntity::class,
        CreatorTemplateEntity::class,
        AiProviderConfigEntity::class,
        LibraryAssetEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ClipFreeDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun transcriptDao(): TranscriptDao
    abstract fun clipDao(): ClipDao
    abstract fun brandKitDao(): BrandKitDao
    abstract fun templateDao(): CreatorTemplateDao
    abstract fun aiProviderDao(): AiProviderDao
    abstract fun libraryAssetDao(): LibraryAssetDao

    companion object {
        @Volatile
        private var INSTANCE: ClipFreeDatabase? = null

        fun getInstance(context: Context): ClipFreeDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ClipFreeDatabase::class.java,
                    "clipfree_ai.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
