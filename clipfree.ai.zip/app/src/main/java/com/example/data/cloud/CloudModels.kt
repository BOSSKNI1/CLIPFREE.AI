package com.example.data.cloud

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class CloudUserProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val displayName: String = "",
    val email: String? = null,
    val photoUrl: String? = null,
    val preferredLanguage: String = "English",
    val defaultResolution: String = "1080p",
    val defaultAspectRatio: String = "9:16",
    val autosaveEnabled: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudProject(
    @DocumentId val id: String = "",
    val userId: String = "",
    val localProjectId: Long = 0L,
    val title: String = "",
    val sourceDisplayName: String = "",
    val durationMs: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val rotationDegrees: Int = 0,
    val hasAudio: Boolean = true,
    val fileSizeBytes: Long = 0L,
    val aspectRatio: String = "9:16",
    val targetPlatform: String = "youtube_shorts",
    val durationPreset: String = "30-45s",
    val captionStyleId: String = "bold_creator",
    val status: String = "IMPORTED",
    val summaryText: String = "",
    val chapters: List<String> = emptyList(),
    val activeProviderUsed: String? = null,
    val clientCreatedAtMs: Long = 0L,
    val clientUpdatedAtMs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudClip(
    @DocumentId val id: String = "",
    val userId: String = "",
    val projectId: String = "",
    val title: String = "",
    val startMs: Long = 0L,
    val endMs: Long = 0L,
    val viralityScore: Int = 0,
    val scoreExplanation: String = "",
    val openingHook: String = "",
    val reasonForSelection: String = "",
    val description: String = "",
    val suggestedCaption: String = "",
    val hashtags: List<String> = emptyList(),
    val language: String = "English",
    val speakerLabel: String = "Speaker 1",
    val aspectRatio: String = "9:16",
    val captionStyleId: String = "bold_creator",
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 0L,
    val aiGenerated: Boolean = true,
    val exportStatus: String = "DRAFT",
    val clientCreatedAtMs: Long = 0L,
    val clientUpdatedAtMs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudBrandKit(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val primaryColorHex: String = "#7652E8",
    val secondaryColorHex: String = "#B9A6F6",
    val fontName: String = "Space Grotesk",
    val captionStyleId: String = "bold_creator",
    val introText: String = "",
    val outroText: String = "Follow for more!",
    val ctaText: String = "Subscribe & Share",
    val watermarkEnabled: Boolean = false,
    val watermarkText: String = "@creator",
    val defaultKit: Boolean = false,
    val clientCreatedAtMs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudTemplate(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val category: String = "Custom",
    val captionStyleId: String = "bold_creator",
    val fontName: String = "Space Grotesk",
    val primaryColorHex: String = "#7652E8",
    val accentColorHex: String = "#9878FF",
    val aspectRatio: String = "9:16",
    val autoZoomEnabled: Boolean = false,
    val introText: String = "",
    val outroText: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Suppress("UNCHECKED_CAST")
internal fun Map<String, Any?>.withoutNulls(): Map<String, Any> =
    filterValues { it != null } as Map<String, Any>

internal fun CloudProject.toCreateMap(uid: String): Map<String, Any> = mapOf<String, Any?>(
    "userId" to uid,
    "localProjectId" to localProjectId.coerceAtLeast(0L),
    "title" to title.ifBlank { "Untitled Project" }.take(160),
    "sourceDisplayName" to sourceDisplayName.ifBlank { "video.mp4" }.take(255),
    "durationMs" to durationMs.coerceAtLeast(0L),
    "width" to width.coerceAtLeast(0),
    "height" to height.coerceAtLeast(0),
    "rotationDegrees" to rotationDegrees.coerceIn(0, 360),
    "hasAudio" to hasAudio,
    "fileSizeBytes" to fileSizeBytes.coerceAtLeast(0L),
    "aspectRatio" to aspectRatio.ifBlank { "9:16" }.take(20),
    "targetPlatform" to targetPlatform.ifBlank { "youtube_shorts" }.take(40),
    "durationPreset" to durationPreset.ifBlank { "30-45s" }.take(40),
    "captionStyleId" to captionStyleId.ifBlank { "bold_creator" }.take(64),
    "status" to (status.takeIf { it in ALLOWED_PROJECT_STATUSES } ?: "IMPORTED"),
    "summaryText" to summaryText.take(4000),
    "chapters" to chapters.take(50).map { it.take(300) },
    "activeProviderUsed" to activeProviderUsed?.take(120),
    "clientCreatedAtMs" to clientCreatedAtMs.coerceAtLeast(0L),
    "clientUpdatedAtMs" to clientUpdatedAtMs.coerceAtLeast(0L),
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).withoutNulls()

internal fun CloudProject.toUpdateMap(): Map<String, Any> = mapOf<String, Any?>(
    "localProjectId" to localProjectId.coerceAtLeast(0L),
    "title" to title.ifBlank { "Untitled Project" }.take(160),
    "sourceDisplayName" to sourceDisplayName.ifBlank { "video.mp4" }.take(255),
    "durationMs" to durationMs.coerceAtLeast(0L),
    "width" to width.coerceAtLeast(0),
    "height" to height.coerceAtLeast(0),
    "rotationDegrees" to rotationDegrees.coerceIn(0, 360),
    "hasAudio" to hasAudio,
    "fileSizeBytes" to fileSizeBytes.coerceAtLeast(0L),
    "aspectRatio" to aspectRatio.ifBlank { "9:16" }.take(20),
    "targetPlatform" to targetPlatform.ifBlank { "youtube_shorts" }.take(40),
    "durationPreset" to durationPreset.ifBlank { "30-45s" }.take(40),
    "captionStyleId" to captionStyleId.ifBlank { "bold_creator" }.take(64),
    "status" to (status.takeIf { it in ALLOWED_PROJECT_STATUSES } ?: "IMPORTED"),
    "summaryText" to summaryText.take(4000),
    "chapters" to chapters.take(50).map { it.take(300) },
    "activeProviderUsed" to activeProviderUsed?.take(120),
    "clientUpdatedAtMs" to clientUpdatedAtMs.coerceAtLeast(0L),
    "updatedAt" to FieldValue.serverTimestamp()
).withoutNulls()

internal fun CloudClip.toCreateMap(uid: String, cloudProjectId: String): Map<String, Any> = mapOf<String, Any?>(
    "userId" to uid,
    "projectId" to cloudProjectId,
    "title" to title.ifBlank { "Clip" }.take(160),
    "startMs" to startMs.coerceAtLeast(0L),
    "endMs" to endMs.coerceAtLeast(0L),
    "viralityScore" to viralityScore.coerceIn(0, 100),
    "scoreExplanation" to scoreExplanation.take(1500),
    "openingHook" to openingHook.take(500),
    "reasonForSelection" to reasonForSelection.take(1000),
    "description" to description.take(2000),
    "suggestedCaption" to suggestedCaption.take(1500),
    "hashtags" to hashtags.take(20).map { it.take(64) },
    "language" to language.ifBlank { "English" }.take(40),
    "speakerLabel" to speakerLabel.ifBlank { "Speaker 1" }.take(80),
    "aspectRatio" to aspectRatio.ifBlank { "9:16" }.take(20),
    "captionStyleId" to captionStyleId.ifBlank { "bold_creator" }.take(64),
    "trimStartMs" to trimStartMs.coerceAtLeast(0L),
    "trimEndMs" to trimEndMs.coerceAtLeast(0L),
    "aiGenerated" to aiGenerated,
    "exportStatus" to (exportStatus.takeIf { it in ALLOWED_EXPORT_STATUSES } ?: "DRAFT"),
    "clientCreatedAtMs" to clientCreatedAtMs.coerceAtLeast(0L),
    "clientUpdatedAtMs" to clientUpdatedAtMs.coerceAtLeast(0L),
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).withoutNulls()

internal fun CloudClip.toUpdateMap(): Map<String, Any> = mapOf<String, Any?>(
    "title" to title.ifBlank { "Clip" }.take(160),
    "startMs" to startMs.coerceAtLeast(0L),
    "endMs" to endMs.coerceAtLeast(0L),
    "viralityScore" to viralityScore.coerceIn(0, 100),
    "scoreExplanation" to scoreExplanation.take(1500),
    "openingHook" to openingHook.take(500),
    "reasonForSelection" to reasonForSelection.take(1000),
    "description" to description.take(2000),
    "suggestedCaption" to suggestedCaption.take(1500),
    "hashtags" to hashtags.take(20).map { it.take(64) },
    "language" to language.ifBlank { "English" }.take(40),
    "speakerLabel" to speakerLabel.ifBlank { "Speaker 1" }.take(80),
    "aspectRatio" to aspectRatio.ifBlank { "9:16" }.take(20),
    "captionStyleId" to captionStyleId.ifBlank { "bold_creator" }.take(64),
    "trimStartMs" to trimStartMs.coerceAtLeast(0L),
    "trimEndMs" to trimEndMs.coerceAtLeast(0L),
    "aiGenerated" to aiGenerated,
    "exportStatus" to (exportStatus.takeIf { it in ALLOWED_EXPORT_STATUSES } ?: "DRAFT"),
    "clientUpdatedAtMs" to clientUpdatedAtMs.coerceAtLeast(0L),
    "updatedAt" to FieldValue.serverTimestamp()
).withoutNulls()

internal fun CloudBrandKit.toCreateMap(uid: String): Map<String, Any> = mapOf(
    "userId" to uid,
    "name" to name.ifBlank { "Brand Kit" }.take(100),
    "primaryColorHex" to primaryColorHex.ifBlank { "#7652E8" }.take(16),
    "secondaryColorHex" to secondaryColorHex.ifBlank { "#B9A6F6" }.take(16),
    "fontName" to fontName.ifBlank { "Space Grotesk" }.take(80),
    "captionStyleId" to captionStyleId.ifBlank { "bold_creator" }.take(64),
    "introText" to introText.take(200),
    "outroText" to outroText.take(200),
    "ctaText" to ctaText.take(200),
    "watermarkEnabled" to watermarkEnabled,
    "watermarkText" to watermarkText.take(100),
    "defaultKit" to defaultKit,
    "clientCreatedAtMs" to clientCreatedAtMs.coerceAtLeast(0L),
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).withoutNulls()

internal fun CloudBrandKit.toUpdateMap(): Map<String, Any> = mapOf(
    "name" to name.ifBlank { "Brand Kit" }.take(100),
    "primaryColorHex" to primaryColorHex.ifBlank { "#7652E8" }.take(16),
    "secondaryColorHex" to secondaryColorHex.ifBlank { "#B9A6F6" }.take(16),
    "fontName" to fontName.ifBlank { "Space Grotesk" }.take(80),
    "captionStyleId" to captionStyleId.ifBlank { "bold_creator" }.take(64),
    "introText" to introText.take(200),
    "outroText" to outroText.take(200),
    "ctaText" to ctaText.take(200),
    "watermarkEnabled" to watermarkEnabled,
    "watermarkText" to watermarkText.take(100),
    "defaultKit" to defaultKit,
    "updatedAt" to FieldValue.serverTimestamp()
).withoutNulls()

internal fun CloudTemplate.toCreateMap(uid: String): Map<String, Any> = mapOf(
    "userId" to uid,
    "name" to name.ifBlank { "Custom Template" }.take(100),
    "category" to category.ifBlank { "Custom" }.take(60),
    "captionStyleId" to captionStyleId.ifBlank { "bold_creator" }.take(64),
    "fontName" to fontName.ifBlank { "Space Grotesk" }.take(80),
    "primaryColorHex" to primaryColorHex.ifBlank { "#7652E8" }.take(16),
    "accentColorHex" to accentColorHex.ifBlank { "#9878FF" }.take(16),
    "aspectRatio" to aspectRatio.ifBlank { "9:16" }.take(20),
    "autoZoomEnabled" to autoZoomEnabled,
    "introText" to introText.take(200),
    "outroText" to outroText.take(200),
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).withoutNulls()

internal fun CloudTemplate.toUpdateMap(): Map<String, Any> = mapOf(
    "name" to name.ifBlank { "Custom Template" }.take(100),
    "category" to category.ifBlank { "Custom" }.take(60),
    "captionStyleId" to captionStyleId.ifBlank { "bold_creator" }.take(64),
    "fontName" to fontName.ifBlank { "Space Grotesk" }.take(80),
    "primaryColorHex" to primaryColorHex.ifBlank { "#7652E8" }.take(16),
    "accentColorHex" to accentColorHex.ifBlank { "#9878FF" }.take(16),
    "aspectRatio" to aspectRatio.ifBlank { "9:16" }.take(20),
    "autoZoomEnabled" to autoZoomEnabled,
    "introText" to introText.take(200),
    "outroText" to outroText.take(200),
    "updatedAt" to FieldValue.serverTimestamp()
).withoutNulls()

private val ALLOWED_PROJECT_STATUSES = setOf("IMPORTED", "ANALYZING", "READY", "LOCAL_ONLY", "ERROR")
private val ALLOWED_EXPORT_STATUSES = setOf("DRAFT", "QUEUED", "EXPORTING", "COMPLETED", "FAILED", "CANCELLED")
