package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

object ProjectStatus {
    const val IMPORTED = "IMPORTED"
    const val ANALYZING = "ANALYZING"
    const val READY = "READY"
    const val LOCAL_ONLY = "LOCAL_ONLY"
    const val ERROR = "ERROR"
}

object ExportStatus {
    const val DRAFT = "DRAFT"
    const val QUEUED = "QUEUED"
    const val EXPORTING = "EXPORTING"
    const val COMPLETED = "COMPLETED"
    const val FAILED = "FAILED"
    const val CANCELLED = "CANCELLED"
}

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val sourceUri: String,
    val sourceDisplayName: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val rotationDegrees: Int = 0,
    val hasAudio: Boolean = true,
    val fileSizeBytes: Long = 0L,
    val thumbnailPath: String? = null,
    val aspectRatio: String = "9:16",
    val targetPlatform: String = "youtube_shorts",
    val durationPreset: String = "30-45s",
    val captionStyleId: String = "bold_creator",
    val status: String = ProjectStatus.IMPORTED,
    val summaryText: String = "",
    val chaptersJson: String = "[]",
    val lastError: String? = null,
    val sourceMissing: Boolean = false,
    val activeProviderUsed: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "transcript_segments",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class TranscriptSegmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val speakerLabel: String = "Speaker 1",
    val language: String = "English",
    val isFillerOrSilence: Boolean = false,
    val isRepeatedTake: Boolean = false,
    val isRemoved: Boolean = false,
    val wordsJson: String = "[]"
)

@Entity(
    tableName = "generated_clips",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class GeneratedClipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val title: String,
    val startMs: Long,
    val endMs: Long,
    val viralityScore: Int,
    val scoreExplanation: String,
    val openingHook: String,
    val reasonForSelection: String,
    val description: String,
    val suggestedCaption: String,
    val hashtagsJson: String = "[]",
    val language: String = "English",
    val speakerLabel: String = "Speaker 1",
    val aspectRatio: String = "9:16",
    val captionStyleJson: String = "{}",
    val editTimelineJson: String = "{}",
    val previewThumbnailPath: String? = null,
    val exportedFilePath: String? = null,
    val exportedUri: String? = null,
    val exportStatus: String = ExportStatus.DRAFT,
    val exportProgress: Int = 0,
    val exportError: String? = null,
    val isAiGenerated: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "brand_kits")
data class BrandKitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val primaryColorHex: String = "#7652E8",
    val secondaryColorHex: String = "#B9A6F6",
    val fontName: String = "Space Grotesk",
    val captionStyleId: String = "bold_creator",
    val logoUri: String? = null,
    val introText: String = "",
    val outroText: String = "Follow for more!",
    val ctaText: String = "Subscribe & Share",
    val watermarkEnabled: Boolean = false,
    val watermarkText: String = "@creator",
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "creator_templates")
data class CreatorTemplateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val captionStyleId: String,
    val fontName: String,
    val primaryColorHex: String,
    val accentColorHex: String,
    val aspectRatio: String = "9:16",
    val autoZoomEnabled: Boolean = false,
    val introText: String = "",
    val outroText: String = "",
    val isBuiltIn: Boolean = false
)

@Entity(tableName = "ai_provider_configs")
data class AiProviderConfigEntity(
    @PrimaryKey val id: String,
    val providerType: String, // FIREBASE_AI_LOGIC, GEMINI_REST, OPENAI_COMPATIBLE, GROQ, OPENROUTER, CUSTOM_HTTP
    val displayName: String,
    val modelName: String,
    val endpointUrl: String = "",
    val priority: Int = 0,
    val isEnabled: Boolean = true,
    val isActive: Boolean = false,
    val status: String = "AVAILABLE", // AVAILABLE, LIMITED, QUOTA_EXHAUSTED, UNAUTHORIZED, OFFLINE, UNCONFIGURED
    val lastError: String? = null,
    val lastTestedAt: Long? = null,
    val lastSwitchedAt: Long? = null,
    val requestsUsedSession: Int = 0,
    val rateLimitRemaining: String? = null,
    val rateLimitReset: String? = null
)

@Entity(tableName = "library_assets")
data class LibraryAssetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long? = null,
    val assetType: String, // CLIP, EXPORTED_VIDEO, THUMBNAIL, SUBTITLE, BRAND_LOGO, BROLL
    val title: String,
    val filePathOrUri: String,
    val mimeType: String,
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)
