package com.example.data

import android.content.Context
import android.net.Uri
import com.example.ai.AiOrchestrator
import com.example.ai.AiResult
import com.example.ai.CreatorInsightsResult
import com.example.ai.HighlightAnalysisRequest
import com.example.ai.MetadataAndHooksResult
import com.example.ai.TranslatedSegmentDto
import com.example.core.PreferencesManager
import com.example.core.SecureVault
import com.example.data.cloud.CloudSyncRepository
import com.example.data.local.AiProviderConfigEntity
import com.example.data.local.BrandKitEntity
import com.example.data.local.ClipFreeDatabase
import com.example.data.local.CreatorTemplateEntity
import com.example.data.local.ExportStatus
import com.example.data.local.GeneratedClipEntity
import com.example.data.local.LibraryAssetEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.ProjectStatus
import com.example.data.local.TranscriptSegmentEntity
import com.example.data.model.AspectRatioOption
import com.example.data.model.CaptionStyleConfig
import com.example.data.model.ClipEditTimeline
import com.example.data.model.DurationPreset
import com.example.data.model.ExportResolution
import com.example.data.model.SocialPlatform
import com.example.data.model.TimeRangeMs
import com.example.video.ClipExportWorker
import com.example.video.MediaAudioExtractor
import com.example.video.VideoInspector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

enum class AutoCreateStep(val label: String, val fraction: Float) {
    EXTRACTING_MEDIA("Inspecting media & extracting audio/frames...", 0.25f),
    AI_ANALYZING("Detecting highlights & speech with AI...", 0.55f),
    BUILDING_CLIPS("Validating timestamps & saving clips...", 0.85f),
    COMPLETED("Clips ready for preview & editing", 1.0f)
}

class ClipFreeRepository(
    private val context: Context,
    private val db: ClipFreeDatabase,
    val preferences: PreferencesManager,
    val vault: SecureVault,
    val aiOrchestrator: AiOrchestrator,
    private val cloudSync: CloudSyncRepository? = null
) {
    private val json = Json { ignoreUnknownKeys = true }

    val projectsFlow: Flow<List<ProjectEntity>> = db.projectDao().observeAllProjects()
    val allClipsFlow: Flow<List<GeneratedClipEntity>> = db.clipDao().observeAllClips()
    val brandKitsFlow: Flow<List<BrandKitEntity>> = db.brandKitDao().observeAllBrandKits()
    val templatesFlow: Flow<List<CreatorTemplateEntity>> = db.templateDao().observeAllTemplates()
    val providersFlow: Flow<List<AiProviderConfigEntity>> = db.aiProviderDao().observeProviders()
    val libraryAssetsFlow: Flow<List<LibraryAssetEntity>> = db.libraryAssetDao().observeAllAssets()

    fun observeProject(projectId: Long): Flow<ProjectEntity?> = db.projectDao().observeProject(projectId)
    fun observeClipsForProject(projectId: Long): Flow<List<GeneratedClipEntity>> =
        db.clipDao().observeClipsForProject(projectId)
    fun observeTranscript(projectId: Long): Flow<List<TranscriptSegmentEntity>> =
        db.transcriptDao().observeTranscript(projectId)
    fun observeClip(clipId: Long): Flow<GeneratedClipEntity?> = db.clipDao().observeClip(clipId)

    suspend fun initializeDefaults() {
        aiOrchestrator.ensureDefaultProvidersSeeded()
        if (db.templateDao().count() == 0) {
            db.templateDao().insertAll(
                listOf(
                    CreatorTemplateEntity(
                        name = "Podcast Highlight",
                        category = "Podcasts",
                        captionStyleId = "speaker_colored",
                        fontName = "Space Grotesk",
                        primaryColorHex = "#7652E8",
                        accentColorHex = "#9878FF",
                        aspectRatio = "9:16",
                        autoZoomEnabled = true,
                        introText = "Podcast Clip",
                        isBuiltIn = true
                    ),
                    CreatorTemplateEntity(
                        name = "Edu Breakdown",
                        category = "Education",
                        captionStyleId = "keywords",
                        fontName = "Plus Jakarta Sans",
                        primaryColorHex = "#2563EB",
                        accentColorHex = "#38BDF8",
                        aspectRatio = "9:16",
                        autoZoomEnabled = false,
                        isBuiltIn = true
                    ),
                    CreatorTemplateEntity(
                        name = "Gaming Clutch",
                        category = "Gaming",
                        captionStyleId = "word_by_word",
                        fontName = "Space Grotesk",
                        primaryColorHex = "#10B981",
                        accentColorHex = "#34D399",
                        aspectRatio = "9:16",
                        autoZoomEnabled = true,
                        isBuiltIn = true
                    ),
                    CreatorTemplateEntity(
                        name = "Interview Q&A",
                        category = "Interviews",
                        captionStyleId = "speaker_colored",
                        fontName = "Plus Jakarta Sans",
                        primaryColorHex = "#7652E8",
                        accentColorHex = "#F59E0B",
                        aspectRatio = "4:5",
                        autoZoomEnabled = false,
                        isBuiltIn = true
                    ),
                    CreatorTemplateEntity(
                        name = "Talking-Head Pro",
                        category = "Talking-head",
                        captionStyleId = "bold_creator",
                        fontName = "Space Grotesk",
                        primaryColorHex = "#7652E8",
                        accentColorHex = "#B9A6F6",
                        aspectRatio = "9:16",
                        autoZoomEnabled = true,
                        isBuiltIn = true
                    ),
                    CreatorTemplateEntity(
                        name = "Motivational Surge",
                        category = "Motivational",
                        captionStyleId = "karaoke",
                        fontName = "Space Grotesk",
                        primaryColorHex = "#EA580C",
                        accentColorHex = "#FBBF24",
                        aspectRatio = "9:16",
                        autoZoomEnabled = true,
                        isBuiltIn = true
                    ),
                    CreatorTemplateEntity(
                        name = "Business Brief",
                        category = "Business",
                        captionStyleId = "minimal",
                        fontName = "Plus Jakarta Sans",
                        primaryColorHex = "#1E293B",
                        accentColorHex = "#7652E8",
                        aspectRatio = "1:1",
                        autoZoomEnabled = false,
                        isBuiltIn = true
                    ),
                    CreatorTemplateEntity(
                        name = "Minimal Subtitles",
                        category = "Minimal",
                        captionStyleId = "minimal",
                        fontName = "Plus Jakarta Sans",
                        primaryColorHex = "#FFFFFF",
                        accentColorHex = "#B9A6F6",
                        aspectRatio = "9:16",
                        autoZoomEnabled = false,
                        isBuiltIn = true
                    ),
                    CreatorTemplateEntity(
                        name = "Bold Captions",
                        category = "Bold Captions",
                        captionStyleId = "bold_creator",
                        fontName = "Space Grotesk",
                        primaryColorHex = "#7652E8",
                        accentColorHex = "#9878FF",
                        aspectRatio = "9:16",
                        autoZoomEnabled = false,
                        isBuiltIn = true
                    )
                )
            )
        }
        if (db.brandKitDao().getAllBrandKits().isEmpty()) {
            db.brandKitDao().insert(
                BrandKitEntity(
                    name = "CLIPFREE Studio Default",
                    primaryColorHex = "#7652E8",
                    secondaryColorHex = "#B9A6F6",
                    fontName = "Space Grotesk",
                    captionStyleId = "bold_creator",
                    outroText = "Follow for more!",
                    ctaText = "Watch Full Video",
                    watermarkEnabled = false,
                    watermarkText = "@clipfree.creator",
                    isDefault = true
                )
            )
        }
    }

    suspend fun importVideo(
        uri: Uri,
        aspectRatio: AspectRatioOption = AspectRatioOption.RATIO_9_16,
        platform: SocialPlatform = SocialPlatform.YOUTUBE_SHORTS,
        durationPreset: DurationPreset = DurationPreset.MEDIUM_30_45,
        captionStyleId: String = "bold_creator"
    ): Result<ProjectEntity> {
        val initialInspected = VideoInspector.inspectVideo(context, uri)
            .getOrElse { return Result.failure(it) }

        val stableUri = persistPickedUriIfNeeded(
            uri = uri,
            preferredName = initialInspected.displayName,
            fileSizeBytes = initialInspected.fileSizeBytes
        )
        val inspected = if (stableUri != uri) {
            VideoInspector.inspectVideo(context, stableUri).getOrDefault(initialInspected)
        } else {
            initialInspected
        }

        val cleanTitle = inspected.displayName.substringBeforeLast('.').ifBlank { "Untitled Video" }
        val project = ProjectEntity(
            title = cleanTitle,
            sourceUri = stableUri.toString(),
            sourceDisplayName = inspected.displayName,
            durationMs = inspected.durationMs,
            width = inspected.width,
            height = inspected.height,
            rotationDegrees = inspected.rotationDegrees,
            hasAudio = inspected.hasAudio,
            fileSizeBytes = inspected.fileSizeBytes,
            thumbnailPath = inspected.thumbnailPath,
            aspectRatio = aspectRatio.id,
            targetPlatform = platform.id,
            durationPreset = durationPreset.id,
            captionStyleId = captionStyleId,
            status = ProjectStatus.IMPORTED
        )
        val id = db.projectDao().insertProject(project)
        val saved = project.copy(id = id)

        db.libraryAssetDao().insert(
            LibraryAssetEntity(
                projectId = id,
                assetType = "ORIGINAL_PROJECT",
                title = cleanTitle,
                filePathOrUri = stableUri.toString(),
                mimeType = "video/*",
                durationMs = inspected.durationMs,
                sizeBytes = inspected.fileSizeBytes
            )
        )
        cloudSync?.pushProjectAndClips(id)
        return Result.success(saved)
    }

    private suspend fun persistPickedUriIfNeeded(
        uri: Uri,
        preferredName: String,
        fileSizeBytes: Long
    ): Uri = withContext(Dispatchers.IO) {
        if (uri.scheme == "file") return@withContext uri
        val hasPersistedGrant = runCatching {
            context.contentResolver.persistedUriPermissions.any {
                it.uri == uri && it.isReadPermission
            }
        }.getOrDefault(false)
        if (hasPersistedGrant) return@withContext uri

        val maxCopyBytes = 250L * 1024L * 1024L
        if (fileSizeBytes > maxCopyBytes) return@withContext uri

        runCatching {
            val importDir = File(context.filesDir, "imported_media").apply { mkdirs() }
            val ext = preferredName.substringAfterLast('.', "mp4")
                .replace(Regex("[^a-zA-Z0-9]"), "")
                .take(8)
                .ifBlank { "mp4" }
            val base = preferredName.substringBeforeLast('.')
                .replace(Regex("[^a-zA-Z0-9_-]"), "_")
                .take(36)
                .ifBlank { "video" }
            val destFile = File(importDir, "${base}_${System.currentTimeMillis()}.$ext")
            context.contentResolver.openInputStream(uri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            if (destFile.exists() && destFile.length() > 0L) {
                Uri.fromFile(destFile)
            } else {
                runCatching { destFile.delete() }
                uri
            }
        }.getOrDefault(uri)
    }

    suspend fun verifySourceAccessibility() = withContext(Dispatchers.IO) {
        val all = db.projectDao().getProjectById(0) // no-op warm up
        // Checked per project when opened or listed if needed
    }

    suspend fun relinkProjectSource(projectId: Long, newUri: Uri): Result<ProjectEntity> {
        val existing = db.projectDao().getProjectById(projectId)
            ?: return Result.failure(IllegalArgumentException("Project not found."))
        val inspected = VideoInspector.inspectVideo(context, newUri)
            .getOrElse { return Result.failure(it) }
        val stableUri = persistPickedUriIfNeeded(
            uri = newUri,
            preferredName = inspected.displayName,
            fileSizeBytes = inspected.fileSizeBytes
        )
        val updated = existing.copy(
            sourceUri = stableUri.toString(),
            sourceDisplayName = inspected.displayName,
            durationMs = inspected.durationMs,
            width = inspected.width,
            height = inspected.height,
            hasAudio = inspected.hasAudio,
            fileSizeBytes = inspected.fileSizeBytes,
            thumbnailPath = inspected.thumbnailPath ?: existing.thumbnailPath,
            sourceMissing = false,
            lastError = null,
            updatedAt = System.currentTimeMillis()
        )
        db.projectDao().updateProject(updated)
        cloudSync?.pushProjectAndClips(projectId)
        return Result.success(updated)
    }

    suspend fun renameProject(project: ProjectEntity, newTitle: String) {
        if (newTitle.isBlank()) return
        db.projectDao().updateProject(
            project.copy(title = newTitle.trim(), updatedAt = System.currentTimeMillis())
        )
        cloudSync?.pushProjectAndClips(project.id)
    }

    suspend fun duplicateProject(project: ProjectEntity): Long {
        val now = System.currentTimeMillis()
        val copyId = db.projectDao().insertProject(
            project.copy(
                id = 0,
                title = "${project.title} (Copy)",
                createdAt = now,
                updatedAt = now
            )
        )
        val segments = db.transcriptDao().getTranscript(project.id)
        if (segments.isNotEmpty()) {
            db.transcriptDao().insertAll(segments.map { it.copy(id = 0, projectId = copyId) })
        }
        val clips = db.clipDao().getClipsForProject(project.id)
        if (clips.isNotEmpty()) {
            db.clipDao().insertClips(
                clips.map {
                    it.copy(
                        id = 0,
                        projectId = copyId,
                        exportedFilePath = null,
                        exportedUri = null,
                        exportStatus = ExportStatus.DRAFT,
                        exportProgress = 0,
                        createdAt = now,
                        updatedAt = now
                    )
                }
            )
        }
        cloudSync?.pushProjectAndClips(copyId)
        return copyId
    }

    suspend fun deleteProject(projectId: Long) {
        cloudSync?.deleteCloudProject(projectId)
        db.projectDao().deleteProjectById(projectId)
    }

    suspend fun runAutoCreateAnalysis(
        projectId: Long,
        minSeconds: Int,
        maxSeconds: Int,
        aspectRatio: AspectRatioOption,
        platform: SocialPlatform,
        captionStyle: CaptionStyleConfig,
        preferredLanguage: String,
        onStep: (AutoCreateStep) -> Unit
    ): Result<List<GeneratedClipEntity>> {
        val project = db.projectDao().getProjectById(projectId)
            ?: return Result.failure(IllegalArgumentException("Project not found."))

        val uri = Uri.parse(project.sourceUri)
        if (!VideoInspector.isUriAccessible(context, project.sourceUri)) {
            db.projectDao().updateProject(
                project.copy(sourceMissing = true, status = ProjectStatus.ERROR, lastError = "Source video missing.")
            )
            return Result.failure(IllegalStateException("Original source video cannot be accessed."))
        }

        db.projectDao().updateProject(
            project.copy(
                aspectRatio = aspectRatio.id,
                targetPlatform = platform.id,
                captionStyleId = captionStyle.styleId,
                status = ProjectStatus.ANALYZING,
                lastError = null,
                updatedAt = System.currentTimeMillis()
            )
        )

        onStep(AutoCreateStep.EXTRACTING_MEDIA)
        val audioFile = if (project.hasAudio) {
            MediaAudioExtractor.extractAudioTrackForAi(context, uri)
        } else null
        val audioBytes = audioFile?.let { runCatching { it.readBytes() }.getOrNull() }
        runCatching { audioFile?.delete() }

        val keyframes = VideoInspector.extractKeyframes(
            context = context,
            uri = uri,
            durationMs = project.durationMs,
            count = 6,
            maxDimension = 384
        )

        onStep(AutoCreateStep.AI_ANALYZING)
        val request = HighlightAnalysisRequest(
            videoTitle = project.title,
            videoDurationMs = project.durationMs,
            targetMinSeconds = minSeconds,
            targetMaxSeconds = maxSeconds,
            targetPlatformLabel = platform.label,
            aspectRatioLabel = aspectRatio.label,
            preferredLanguage = preferredLanguage,
            audioBytes = audioBytes,
            keyframes = keyframes
        )

        val aiOutcome = aiOrchestrator.executeWithFailover { provider ->
            provider.analyzeVideoForHighlights(request)
        }
        keyframes.forEach { (_, bmp) -> runCatching { bmp.recycle() } }

        return when (aiOutcome) {
            is AiResult.Success -> {
                onStep(AutoCreateStep.BUILDING_CLIPS)
                val analysis = aiOutcome.data

                if (analysis.transcript.isNotEmpty()) {
                    db.transcriptDao().deleteForProject(projectId)
                    db.transcriptDao().insertAll(
                        analysis.transcript.map { seg ->
                            TranscriptSegmentEntity(
                                projectId = projectId,
                                startMs = seg.startMs,
                                endMs = seg.endMs,
                                text = seg.text,
                                speakerLabel = seg.speakerLabel,
                                language = seg.language,
                                isFillerOrSilence = seg.isFillerOrSilence,
                                isRepeatedTake = seg.isRepeatedTake
                            )
                        }
                    )
                }

                val captionStyleJson = json.encodeToString(captionStyle)
                val newClips = analysis.clips.map { dto ->
                    val thumb = VideoInspector.extractClipThumbnail(
                        context = context,
                        uri = uri,
                        timestampMs = dto.startMs + ((dto.endMs - dto.startMs) / 3L)
                    )
                    val timeline = ClipEditTimeline(
                        trimStartMs = dto.startMs,
                        trimEndMs = dto.endMs
                    )
                    GeneratedClipEntity(
                        projectId = projectId,
                        title = dto.title,
                        startMs = dto.startMs,
                        endMs = dto.endMs,
                        viralityScore = dto.viralityScore,
                        scoreExplanation = dto.scoreExplanation,
                        openingHook = dto.openingHook,
                        reasonForSelection = dto.reasonForSelection,
                        description = dto.description,
                        suggestedCaption = dto.suggestedCaption,
                        hashtagsJson = json.encodeToString(dto.hashtags),
                        language = dto.language,
                        speakerLabel = dto.speakerLabel,
                        aspectRatio = aspectRatio.id,
                        captionStyleJson = captionStyleJson,
                        editTimelineJson = json.encodeToString(timeline),
                        previewThumbnailPath = thumb,
                        isAiGenerated = true
                    )
                }

                if (newClips.isNotEmpty()) {
                    db.clipDao().insertClips(newClips)
                }

                val chaptersJson = json.encodeToString(analysis.chapters)
                db.projectDao().updateProject(
                    project.copy(
                        aspectRatio = aspectRatio.id,
                        targetPlatform = platform.id,
                        captionStyleId = captionStyle.styleId,
                        status = ProjectStatus.READY,
                        summaryText = analysis.summary,
                        chaptersJson = chaptersJson,
                        activeProviderUsed = aiOutcome.providerName,
                        lastError = null,
                        updatedAt = System.currentTimeMillis()
                    )
                )

                val persisted = db.clipDao().getClipsForProject(projectId)
                cloudSync?.pushProjectAndClips(projectId)
                onStep(AutoCreateStep.COMPLETED)
                Result.success(persisted)
            }

            is AiResult.Failure -> {
                db.projectDao().updateProject(
                    project.copy(
                        status = ProjectStatus.LOCAL_ONLY,
                        lastError = aiOutcome.message,
                        updatedAt = System.currentTimeMillis()
                    )
                )
                Result.failure(IllegalStateException(aiOutcome.message))
            }
        }
    }

    /**
     * Local Mode clip creation — works completely offline or when all AI quotas are exhausted.
     */
    suspend fun createManualClip(
        projectId: Long,
        title: String,
        startMs: Long,
        endMs: Long,
        aspectRatio: AspectRatioOption,
        captionStyle: CaptionStyleConfig = CaptionStyleConfig()
    ): Result<GeneratedClipEntity> {
        val project = db.projectDao().getProjectById(projectId)
            ?: return Result.failure(IllegalArgumentException("Project not found."))

        val clampedStart = startMs.coerceIn(0L, (project.durationMs - 1000L).coerceAtLeast(0L))
        val clampedEnd = endMs.coerceIn(clampedStart + 1000L, project.durationMs)
        val thumb = VideoInspector.extractClipThumbnail(
            context,
            Uri.parse(project.sourceUri),
            clampedStart + ((clampedEnd - clampedStart) / 3L)
        )
        val timeline = ClipEditTimeline(trimStartMs = clampedStart, trimEndMs = clampedEnd)
        val entity = GeneratedClipEntity(
            projectId = projectId,
            title = title.ifBlank { "Manual Clip" },
            startMs = clampedStart,
            endMs = clampedEnd,
            viralityScore = 0,
            scoreExplanation = "Created manually in Local Mode (AI scoring not run).",
            openingHook = "",
            reasonForSelection = "Manually selected segment",
            description = "Manually trimmed clip",
            suggestedCaption = "",
            aspectRatio = aspectRatio.id,
            captionStyleJson = json.encodeToString(captionStyle),
            editTimelineJson = json.encodeToString(timeline),
            previewThumbnailPath = thumb,
            isAiGenerated = false
        )
        val insertedId = db.clipDao().insertClip(entity)
        db.projectDao().updateProject(
            project.copy(
                status = if (project.status == ProjectStatus.IMPORTED) ProjectStatus.LOCAL_ONLY else project.status,
                updatedAt = System.currentTimeMillis()
            )
        )
        cloudSync?.pushProjectAndClips(projectId)
        return Result.success(entity.copy(id = insertedId))
    }

    suspend fun saveClipChanges(clip: GeneratedClipEntity) {
        db.clipDao().updateClip(clip.copy(updatedAt = System.currentTimeMillis()))
        val project = db.projectDao().getProjectById(clip.projectId)
        if (project != null) {
            db.projectDao().updateProject(project.copy(updatedAt = System.currentTimeMillis()))
        }
        cloudSync?.pushProjectAndClips(clip.projectId)
    }

    suspend fun deleteClip(clipId: Long) {
        val existing = db.clipDao().getClipById(clipId)
        db.clipDao().deleteClipById(clipId)
        if (existing != null) {
            cloudSync?.deleteCloudClip(existing.projectId, clipId)
        }
    }

    suspend fun updateTranscriptSegment(segment: TranscriptSegmentEntity) {
        db.transcriptDao().updateSegment(segment)
    }

    suspend fun importSubtitles(projectId: Long, segments: List<TranscriptSegmentEntity>) {
        if (segments.isEmpty()) return
        db.transcriptDao().deleteForProject(projectId)
        db.transcriptDao().insertAll(segments)
    }

    suspend fun detectSilenceLocallyForProject(projectId: Long): List<TimeRangeMs> {
        val project = db.projectDao().getProjectById(projectId) ?: return emptyList()
        return MediaAudioExtractor.detectSilenceRangesLocally(context, Uri.parse(project.sourceUri))
    }

    suspend fun generateHooksAndMetadata(projectId: Long): AiResult<MetadataAndHooksResult> {
        val project = db.projectDao().getProjectById(projectId)
            ?: return AiResult.Failure(com.example.ai.AiFailureReason.INVALID_RESPONSE, "Project missing")
        val transcript = db.transcriptDao().getTranscript(projectId)
            .filter { !it.isRemoved }
            .joinToString(" ") { it.text }
        if (transcript.isBlank()) {
            return AiResult.Failure(
                com.example.ai.AiFailureReason.INVALID_RESPONSE,
                "No transcript available yet. Run AI Analysis first."
            )
        }
        return aiOrchestrator.executeWithFailover { provider ->
            provider.generateHooksAndMetadata(transcript, project.title)
        }
    }

    suspend fun translateProjectTranscript(
        projectId: Long,
        targetLanguage: String
    ): AiResult<List<TranslatedSegmentDto>> {
        val segments = db.transcriptDao().getTranscript(projectId).filter { !it.isRemoved }
        if (segments.isEmpty()) {
            return AiResult.Failure(
                com.example.ai.AiFailureReason.INVALID_RESPONSE,
                "No transcript segments available to translate."
            )
        }
        val res = aiOrchestrator.executeWithFailover { provider ->
            provider.translateTranscript(segments, targetLanguage)
        }
        if (res is AiResult.Success) {
            val mapByStart = res.data.associateBy { it.startMs }
            segments.forEach { seg ->
                val match = mapByStart[seg.startMs]
                    ?: res.data.firstOrNull { kotlin.math.abs(it.startMs - seg.startMs) < 500L }
                if (match != null && match.translatedText.isNotBlank()) {
                    db.transcriptDao().updateSegment(
                        seg.copy(text = match.translatedText, language = targetLanguage)
                    )
                }
            }
        }
        return res
    }

    suspend fun analyzeBRollAndRepeatedTakes(projectId: Long): AiResult<CreatorInsightsResult> {
        val segments = db.transcriptDao().getTranscript(projectId).filter { !it.isRemoved }
        if (segments.isEmpty()) {
            return AiResult.Failure(
                com.example.ai.AiFailureReason.INVALID_RESPONSE,
                "Transcript is required before analyzing B-roll and repeated takes."
            )
        }
        return aiOrchestrator.executeWithFailover { provider ->
            provider.suggestBRollAndTakes(segments)
        }
    }

    fun enqueueClipExport(clipId: Long, resolution: ExportResolution, saveToGallery: Boolean = true) {
        ClipExportWorker.enqueueClipExport(context, clipId, resolution, saveToGallery)
    }

    fun enqueueBatchExport(clipIds: List<Long>, resolution: ExportResolution) {
        clipIds.forEach { id ->
            ClipExportWorker.enqueueClipExport(context, id, resolution, saveToGallery = true)
        }
    }

    fun cancelClipExport(clipId: Long) {
        ClipExportWorker.cancelClipExport(context, clipId)
        com.example.video.VideoExportEngine.cancelActiveExport()
    }

    suspend fun saveBrandKit(kit: BrandKitEntity): Long {
        val id = db.brandKitDao().insert(kit)
        cloudSync?.pushBrandKit(kit.copy(id = id))
        return id
    }

    suspend fun deleteBrandKit(id: Long) {
        db.brandKitDao().deleteById(id)
        cloudSync?.deleteCloudBrandKit(id)
    }

    suspend fun saveCustomTemplate(template: CreatorTemplateEntity): Long {
        val clean = template.copy(isBuiltIn = false)
        val id = db.templateDao().insert(clean)
        cloudSync?.pushCustomTemplate(clean.copy(id = id))
        return id
    }

    suspend fun deleteCustomTemplate(id: Long) {
        db.templateDao().deleteCustomTemplate(id)
        cloudSync?.deleteCloudTemplate(id)
    }

    suspend fun addOrUpdateProvider(
        config: AiProviderConfigEntity,
        rawApiKey: String?
    ): Boolean {
        if (!rawApiKey.isNullOrBlank()) {
            vault.saveApiKey(config.id, rawApiKey)
        }
        aiOrchestrator.clearCooldown(config.id)
        db.aiProviderDao().upsert(config)
        val promoted = aiOrchestrator.onProviderSavedOrEnabled(config)
        if (!config.isEnabled) {
            aiOrchestrator.ensureActiveProviderValidAfterRemovalOrDisable()
        }
        return promoted
    }

    suspend fun setActiveProvider(id: String) {
        aiOrchestrator.clearCooldown(id)
        db.aiProviderDao().setActiveProvider(id)
        aiOrchestrator.refreshSnapshot()
    }

    suspend fun deleteProvider(id: String) {
        if (id == "builtin_firebase_ai") return
        aiOrchestrator.clearCooldown(id)
        vault.removeApiKey(id)
        db.aiProviderDao().deleteProvider(id)
        aiOrchestrator.ensureActiveProviderValidAfterRemovalOrDisable()
    }

    suspend fun addLibraryAsset(asset: LibraryAssetEntity): Long = db.libraryAssetDao().insert(asset)
    suspend fun deleteLibraryAsset(id: Long) = db.libraryAssetDao().deleteById(id)

    suspend fun calculateStorageUsageBytes(): Pair<Long, Long> = withContext(Dispatchers.IO) {
        val cacheBytes = dirSize(context.cacheDir)
        val appFilesBytes = dirSize(File(context.filesDir, "exports")) +
            dirSize(File(context.filesDir, "thumbnails")) +
            dirSize(File(context.filesDir, "covers")) +
            dirSize(File(context.filesDir, "subtitles")) +
            dirSize(File(context.filesDir, "imported_media"))
        cacheBytes to appFilesBytes
    }

    suspend fun clearTemporaryCache(): Long = withContext(Dispatchers.IO) {
        val freed = dirSize(context.cacheDir)
        context.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
        freed
    }

    private fun dirSize(dir: File): Long {
        if (!dir.exists()) return 0L
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }
}
