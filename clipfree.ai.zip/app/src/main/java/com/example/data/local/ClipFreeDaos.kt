package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun observeAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    suspend fun getAllProjects(): List<ProjectEntity>

    @Query("SELECT * FROM projects WHERE id = :id")
    fun observeProject(id: Long): Flow<ProjectEntity?>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProjectById(id: Long): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: Long)

    @Query("DELETE FROM projects")
    suspend fun deleteAllProjects()
}

@Dao
interface TranscriptDao {
    @Query("SELECT * FROM transcript_segments WHERE projectId = :projectId ORDER BY startMs ASC")
    fun observeTranscript(projectId: Long): Flow<List<TranscriptSegmentEntity>>

    @Query("SELECT * FROM transcript_segments WHERE projectId = :projectId ORDER BY startMs ASC")
    suspend fun getTranscript(projectId: Long): List<TranscriptSegmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(segments: List<TranscriptSegmentEntity>)

    @Update
    suspend fun updateSegment(segment: TranscriptSegmentEntity)

    @Query("DELETE FROM transcript_segments WHERE projectId = :projectId")
    suspend fun deleteForProject(projectId: Long)
}

@Dao
interface ClipDao {
    @Query("SELECT * FROM generated_clips ORDER BY createdAt DESC")
    fun observeAllClips(): Flow<List<GeneratedClipEntity>>

    @Query("SELECT * FROM generated_clips ORDER BY createdAt DESC")
    suspend fun getAllClips(): List<GeneratedClipEntity>

    @Query("SELECT * FROM generated_clips WHERE projectId = :projectId ORDER BY viralityScore DESC, startMs ASC")
    fun observeClipsForProject(projectId: Long): Flow<List<GeneratedClipEntity>>

    @Query("SELECT * FROM generated_clips WHERE id = :clipId")
    fun observeClip(clipId: Long): Flow<GeneratedClipEntity?>

    @Query("SELECT * FROM generated_clips WHERE id = :clipId")
    suspend fun getClipById(clipId: Long): GeneratedClipEntity?

    @Query("SELECT * FROM generated_clips WHERE projectId = :projectId")
    suspend fun getClipsForProject(projectId: Long): List<GeneratedClipEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClip(clip: GeneratedClipEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClips(clips: List<GeneratedClipEntity>)

    @Update
    suspend fun updateClip(clip: GeneratedClipEntity)

    @Query("DELETE FROM generated_clips WHERE id = :clipId")
    suspend fun deleteClipById(clipId: Long)

    @Query("DELETE FROM generated_clips WHERE projectId = :projectId")
    suspend fun deleteForProject(projectId: Long)
}

@Dao
interface BrandKitDao {
    @Query("SELECT * FROM brand_kits ORDER BY isDefault DESC, createdAt DESC")
    fun observeAllBrandKits(): Flow<List<BrandKitEntity>>

    @Query("SELECT * FROM brand_kits")
    suspend fun getAllBrandKits(): List<BrandKitEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(kit: BrandKitEntity): Long

    @Update
    suspend fun update(kit: BrandKitEntity)

    @Query("DELETE FROM brand_kits WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM brand_kits")
    suspend fun deleteAllBrandKits()
}

@Dao
interface CreatorTemplateDao {
    @Query("SELECT * FROM creator_templates ORDER BY isBuiltIn DESC, id ASC")
    fun observeAllTemplates(): Flow<List<CreatorTemplateEntity>>

    @Query("SELECT * FROM creator_templates ORDER BY isBuiltIn DESC, id ASC")
    suspend fun getAllTemplates(): List<CreatorTemplateEntity>

    @Query("SELECT COUNT(*) FROM creator_templates")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(template: CreatorTemplateEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(templates: List<CreatorTemplateEntity>)

    @Query("DELETE FROM creator_templates WHERE id = :id AND isBuiltIn = 0")
    suspend fun deleteCustomTemplate(id: Long)

    @Query("DELETE FROM creator_templates WHERE isBuiltIn = 0")
    suspend fun deleteAllCustomTemplates()
}

@Dao
interface AiProviderDao {
    @Query("SELECT * FROM ai_provider_configs ORDER BY priority ASC")
    fun observeProviders(): Flow<List<AiProviderConfigEntity>>

    @Query("SELECT * FROM ai_provider_configs ORDER BY priority ASC")
    suspend fun getProviders(): List<AiProviderConfigEntity>

    @Query("SELECT * FROM ai_provider_configs WHERE id = :id")
    suspend fun getProvider(id: String): AiProviderConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(provider: AiProviderConfigEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(providers: List<AiProviderConfigEntity>)

    @Query("UPDATE ai_provider_configs SET isActive = (id = :activeId)")
    suspend fun setActiveProvider(activeId: String)

    @Query("DELETE FROM ai_provider_configs WHERE id = :id")
    suspend fun deleteProvider(id: String)
}

@Dao
interface LibraryAssetDao {
    @Query("SELECT * FROM library_assets ORDER BY createdAt DESC")
    fun observeAllAssets(): Flow<List<LibraryAssetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(asset: LibraryAssetEntity): Long

    @Query("DELETE FROM library_assets WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM library_assets")
    suspend fun clearAll()
}
