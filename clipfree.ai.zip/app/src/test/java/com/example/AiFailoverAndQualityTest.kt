package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.ai.AiFailureReason
import com.example.ai.AiOrchestrator
import com.example.ai.AiOverallHealth
import com.example.ai.AiProvider
import com.example.ai.AiResult
import com.example.ai.CreatorInsightsResult
import com.example.ai.HighlightAnalysisRequest
import com.example.ai.MetadataAndHooksResult
import com.example.ai.ProviderStatus
import com.example.ai.ProviderType
import com.example.ai.ProviderValidationResult
import com.example.ai.TranslatedSegmentDto
import com.example.ai.VideoAnalysisResult
import com.example.core.PreferencesManager
import com.example.core.QuotaMode
import com.example.core.SecureVault
import com.example.data.local.AiProviderConfigEntity
import com.example.data.local.ClipFreeDatabase
import com.example.data.local.GeneratedClipEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.TranscriptSegmentEntity
import com.example.data.model.CaptionStyleConfig
import com.example.data.model.ClipEditTimeline
import com.example.data.model.DeviceCapabilities
import com.example.data.model.ExportResolution
import com.example.video.CheckSeverity
import com.example.video.ExportQualityChecker
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AiFailoverAndQualityTest {

    private lateinit var context: Context
    private lateinit var db: ClipFreeDatabase
    private lateinit var prefs: PreferencesManager
    private lateinit var vault: SecureVault
    private lateinit var orchestrator: AiOrchestrator

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, ClipFreeDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        prefs = PreferencesManager(context)
        runBlocking { prefs.setQuotaMode(QuotaMode.SMART_AI) }
        vault = InMemorySecureVault(context)
        orchestrator = AiOrchestrator(db.aiProviderDao(), vault, prefs)
    }

    @After
    fun tearDown() {
        vault.clearAllKeys()
        db.close()
    }

    private class InMemorySecureVault(context: Context) : SecureVault(context) {
        private val keys = mutableMapOf<String, String>()
        override fun saveApiKey(providerId: String, rawKey: String) {
            val trimmed = rawKey.trim()
            if (trimmed.isEmpty()) keys.remove(providerId) else keys[providerId] = trimmed
        }
        override fun getApiKey(providerId: String): String? = keys[providerId]
        override fun hasApiKey(providerId: String): Boolean = !keys[providerId].isNullOrBlank()
        override fun removeApiKey(providerId: String) {
            keys.remove(providerId)
        }
        override fun clearAllKeys() {
            keys.clear()
        }
    }

    @Test
    fun `default firebase ai logic provider is seeded and local mode blocks remote calls`() = runBlocking {
        orchestrator.ensureDefaultProvidersSeeded()
        val seeded = db.aiProviderDao().getProviders()
        assertEquals(1, seeded.size)
        assertEquals("builtin_firebase_ai", seeded[0].id)
        assertTrue(seeded[0].isActive)

        prefs.setQuotaMode(QuotaMode.LOCAL_MODE)
        val result = orchestrator.executeWithFailover {
            AiResult.Success("should-not-run", "id", "name")
        }
        assertTrue(result is AiResult.Failure)
        assertEquals(AiFailureReason.QUOTA_EXHAUSTED, (result as AiResult.Failure).reason)
    }

    @Test
    fun `when active api points run out, next valid api is automatically selected to continue`() = runBlocking {
        val testOrchestrator = AiOrchestrator(
            providerDao = db.aiProviderDao(),
            vault = vault,
            preferencesManager = prefs,
            customProviderFactory = { cfg -> FakeAiProvider(cfg) }
        )

        val primary = AiProviderConfigEntity(
            id = "builtin_firebase_ai",
            providerType = ProviderType.FIREBASE_AI_LOGIC.id,
            displayName = "Primary Gemini API",
            modelName = "gemini-3.8-flash",
            endpointUrl = ProviderType.FIREBASE_AI_LOGIC.defaultEndpoint,
            priority = 0,
            isEnabled = true,
            isActive = true,
            status = ProviderStatus.AVAILABLE
        )
        val backup = AiProviderConfigEntity(
            id = "custom_groq_1",
            providerType = ProviderType.GROQ.id,
            displayName = "Backup Groq API",
            modelName = "llama-3.3-70b-versatile",
            endpointUrl = ProviderType.GROQ.defaultEndpoint,
            priority = 1,
            isEnabled = true,
            isActive = false,
            status = ProviderStatus.AVAILABLE
        )
        vault.saveApiKey(backup.id, "gsk_test_backup_key_1234")
        db.aiProviderDao().upsertAll(listOf(primary, backup))

        val triedIds = mutableListOf<String>()
        val result = testOrchestrator.executeWithFailover { provider ->
            triedIds += provider.config.id
            if (provider.config.id == primary.id) {
                AiResult.Failure(AiFailureReason.QUOTA_EXHAUSTED, "API points exhausted (HTTP 402)", 402)
            } else {
                AiResult.Success("continued-ok", provider.config.id, provider.config.displayName)
            }
        }

        assertTrue(result is AiResult.Success)
        assertEquals("continued-ok", (result as AiResult.Success).data)
        assertEquals(listOf(primary.id, backup.id), triedIds)

        val updatedPrimary = db.aiProviderDao().getProvider(primary.id)!!
        val updatedBackup = db.aiProviderDao().getProvider(backup.id)!!
        assertFalse(updatedPrimary.isActive)
        assertEquals(ProviderStatus.QUOTA_EXHAUSTED, updatedPrimary.status)
        assertTrue(updatedBackup.isActive)
        assertEquals(ProviderStatus.AVAILABLE, updatedBackup.status)
        assertEquals(1, updatedBackup.requestsUsedSession)

        val snapshot = testOrchestrator.snapshot.value
        assertEquals(AiOverallHealth.AI_AVAILABLE, snapshot.health)
        assertEquals("Backup Groq API", snapshot.activeProviderName)
        assertTrue(snapshot.lastSwitchingEvent?.contains("Backup Groq API") == true)
    }

    @Test
    fun `adding a new backup api when active api is exhausted promotes it to active immediately`() = runBlocking {
        val testOrchestrator = AiOrchestrator(
            providerDao = db.aiProviderDao(),
            vault = vault,
            preferencesManager = prefs,
            customProviderFactory = { cfg -> FakeAiProvider(cfg) }
        )
        val exhaustedPrimary = AiProviderConfigEntity(
            id = "builtin_firebase_ai",
            providerType = ProviderType.FIREBASE_AI_LOGIC.id,
            displayName = "Primary Gemini API",
            modelName = "gemini-3.8-flash",
            endpointUrl = ProviderType.FIREBASE_AI_LOGIC.defaultEndpoint,
            priority = 0,
            isEnabled = true,
            isActive = true,
            status = ProviderStatus.QUOTA_EXHAUSTED
        )
        db.aiProviderDao().upsert(exhaustedPrimary)

        val newBackup = AiProviderConfigEntity(
            id = "custom_openrouter_2",
            providerType = ProviderType.OPENROUTER.id,
            displayName = "OpenRouter Backup",
            modelName = "google/gemini-2.0-flash-001",
            endpointUrl = ProviderType.OPENROUTER.defaultEndpoint,
            priority = 1,
            isEnabled = true,
            isActive = false,
            status = ProviderStatus.AVAILABLE
        )
        vault.saveApiKey(newBackup.id, "sk-or-v1-test-key-9999")
        db.aiProviderDao().upsert(newBackup)

        val promoted = testOrchestrator.onProviderSavedOrEnabled(newBackup)
        assertTrue(promoted)

        val activeList = db.aiProviderDao().getProviders().filter { it.isActive }
        assertEquals(1, activeList.size)
        assertEquals(newBackup.id, activeList[0].id)
        assertEquals(AiOverallHealth.AI_AVAILABLE, testOrchestrator.snapshot.value.health)
        assertEquals("OpenRouter Backup", testOrchestrator.snapshot.value.activeProviderName)
    }

    @Test
    fun `export quality checker flags invalid duration, 4k mismatch, and safe-zone violation`() {
        val project = ProjectEntity(
            id = 1L,
            title = "Sample",
            sourceUri = "content://nonexistent/video.mp4",
            sourceDisplayName = "video.mp4",
            durationMs = 20_000L,
            width = 1280,
            height = 720,
            hasAudio = true
        )
        val clip = GeneratedClipEntity(
            id = 1L,
            projectId = 1L,
            title = "Short",
            startMs = 0L,
            endMs = 500L, // invalid (<1000ms)
            viralityScore = 80,
            scoreExplanation = "Good",
            openingHook = "Hook",
            reasonForSelection = "Hook",
            description = "Desc",
            suggestedCaption = "Cap"
        )
        val timeline = ClipEditTimeline(trimStartMs = 0L, trimEndMs = 500L)
        val style = CaptionStyleConfig(enabled = true, positionYFraction = 0.92f)
        val caps = DeviceCapabilities(
            supports4kEncode = false,
            supportsHevc = true,
            maxSupportedWidth = 1920,
            maxSupportedHeight = 1080,
            availableStorageBytes = 500L * 1024L * 1024L
        )

        val issues = ExportQualityChecker.runChecks(
            context = context,
            project = project,
            clip = clip,
            timeline = timeline,
            captionStyle = style,
            resolution = ExportResolution.RES_4K,
            transcript = emptyList(),
            deviceCaps = caps
        )

        assertTrue(issues.any { it.severity == CheckSeverity.ERROR && it.title.contains("Invalid clip duration") })
        assertTrue(issues.any { it.title.contains("4K resolution unsupported") })
        assertTrue(issues.any { it.title.contains("safe zone") })
    }

    private class FakeAiProvider(override val config: AiProviderConfigEntity) : AiProvider {
        override suspend fun validateConnection(): ProviderValidationResult =
            ProviderValidationResult(true, ProviderStatus.AVAILABLE, "OK")

        override suspend fun analyzeVideoForHighlights(request: HighlightAnalysisRequest): AiResult<VideoAnalysisResult> =
            AiResult.Success(VideoAnalysisResult(""), config.id, config.displayName)

        override suspend fun generateHooksAndMetadata(transcriptText: String, videoTitle: String): AiResult<MetadataAndHooksResult> =
            AiResult.Success(MetadataAndHooksResult(), config.id, config.displayName)

        override suspend fun translateTranscript(segments: List<TranscriptSegmentEntity>, targetLanguage: String): AiResult<List<TranslatedSegmentDto>> =
            AiResult.Success(emptyList(), config.id, config.displayName)

        override suspend fun suggestBRollAndTakes(segments: List<TranscriptSegmentEntity>): AiResult<CreatorInsightsResult> =
            AiResult.Success(CreatorInsightsResult(), config.id, config.displayName)
    }
}
