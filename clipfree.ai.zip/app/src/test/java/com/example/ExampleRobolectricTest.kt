package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import com.example.ai.FirebaseAiLogicProvider
import com.google.firebase.FirebaseApp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule(order = 0)
    val activityRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `app name matches CLIPFREE AI`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("CLIPFREE.AI", context.getString(R.string.app_name))
    }

    @Test
    fun `unauthenticated launch gates on Google Sign In screen`() {
        activityRule.waitForIdle()
        activityRule.onNodeWithText("Welcome to CLIPFREE Studio").assertIsDisplayed()
        activityRule.onNodeWithTag("google_sign_in_button").assertIsDisplayed()
    }

    @Test
    fun `ai json parser clamps out-of-bounds timestamps to real video duration`() {
        val rawJson = """
            {
              "summary": "Podcast discussion on mobile performance.",
              "chapters": [
                {"title": "Intro", "startMs": 0, "endMs": 15000, "summary": "Opening"}
              ],
              "transcript": [
                {"startMs": 500, "endMs": 4500, "text": "Here is the key insight.", "speakerLabel": "Speaker 1"}
              ],
              "clips": [
                {
                  "title": "Mobile Insight",
                  "startMs": 1000,
                  "endMs": 999999,
                  "description": "Strong insight",
                  "openingHook": "Here is the key insight.",
                  "reasonForSelection": "Clear hook",
                  "viralityScore": 140,
                  "scoreExplanation": "Strong opening hook.",
                  "suggestedCaption": "Watch this!",
                  "hashtags": ["#shorts"]
                }
              ]
            }
        """.trimIndent()
        val parsed = FirebaseAiLogicProvider.parseAnalysisJson(rawJson, maxDurationMs = 30_000L)
        assertEquals(1, parsed.clips.size)
        assertEquals(30_000L, parsed.clips[0].endMs)
        assertEquals(100, parsed.clips[0].viralityScore)
        assertTrue(parsed.transcript[0].startMs in 0L..30_000L)
    }
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AuthenticatedNavigationRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Before
    fun setUpFirebase() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(context)
        }
    }

    @Test
    fun `authenticated studio navigates across all five main tabs and shows account controls`() {
        composeRule.setContent {
            ClipFreeAppRoot(currentUserId = "test_creator_uid")
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("import_video_button").assertIsDisplayed()
        composeRule.onNodeWithTag("auto_create_button").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_projects").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("projects_new_button").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_create").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Auto Create Shorts").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_library").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Creator Library").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_profile").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Profile & Studio Settings").assertIsDisplayed()
        composeRule.onNodeWithTag("account_card").assertIsDisplayed()
        composeRule.onNodeWithTag("sync_now_button").assertIsDisplayed()
        composeRule.onNodeWithTag("sign_out_button").assertIsDisplayed()

        composeRule.onNodeWithTag("profile_list").performScrollToNode(hasTestTag("theme_chip_dark"))
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("theme_chip_dark").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("theme_chip_light").performClick()
        composeRule.waitForIdle()
    }

    @Test
    fun `profile log out button shows confirmation and invokes logout callback`() {
        var loggedOut = false
        composeRule.setContent {
            ClipFreeAppRoot(
                currentUserId = "test_creator_uid",
                onLoggedOut = { loggedOut = true }
            )
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("nav_profile").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("sign_out_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Log Out of CLIPFREE.AI?").assertIsDisplayed()
        composeRule.onNodeWithTag("confirm_sign_out_button").performClick()
        composeRule.waitUntil(timeoutMillis = 3000L) { loggedOut }
        assertTrue(loggedOut)
    }
}
