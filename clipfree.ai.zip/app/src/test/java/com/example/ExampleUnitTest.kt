package com.example

import com.example.core.TimeUtils
import com.example.data.local.TranscriptSegmentEntity
import com.example.data.model.TimeRangeMs
import com.example.video.SubtitleExporter
import com.example.video.VideoExportEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `computeKeptSegments removes excluded ranges accurately`() {
        val kept = VideoExportEngine.computeKeptSegments(
            clipStartMs = 10_000L,
            clipEndMs = 40_000L,
            excludedRanges = listOf(
                TimeRangeMs(15_000L, 18_000L),
                TimeRangeMs(28_000L, 31_000L)
            )
        )
        assertEquals(
            listOf(
                10_000L to 15_000L,
                18_000L to 28_000L,
                31_000L to 40_000L
            ),
            kept
        )
    }

    @Test
    fun `srt export and parse roundtrip preserves timestamps and text`() {
        val segments = listOf(
            TranscriptSegmentEntity(
                id = 1,
                projectId = 10,
                startMs = 1_500L,
                endMs = 4_200L,
                text = "First viral hook line."
            ),
            TranscriptSegmentEntity(
                id = 2,
                projectId = 10,
                startMs = 4_500L,
                endMs = 8_000L,
                text = "Second explanation sentence."
            )
        )
        val srt = SubtitleExporter.buildSrt(segments)
        assertTrue(srt.contains("00:00:01,500 --> 00:00:04,200"))
        val parsed = SubtitleExporter.parseSrt(srt, projectId = 10)
        assertEquals(2, parsed.size)
        assertEquals(1_500L, parsed[0].startMs)
        assertEquals(4_200L, parsed[0].endMs)
        assertEquals("First viral hook line.", parsed[0].text)
    }

    @Test
    fun `vtt export includes WEBVTT header and speaker labels`() {
        val segments = listOf(
            TranscriptSegmentEntity(
                projectId = 1,
                startMs = 0L,
                endMs = 2_000L,
                text = "Welcome back",
                speakerLabel = "Speaker 1"
            )
        )
        val vtt = SubtitleExporter.buildVtt(segments)
        assertTrue(vtt.startsWith("WEBVTT"))
        assertTrue(vtt.contains("[Speaker 1] Welcome back"))
    }

    @Test
    fun `timecode formatting handles minutes and hours`() {
        assertEquals("01:05", TimeUtils.formatDuration(65_000L))
        assertEquals("1:01:01", TimeUtils.formatDuration(3_661_000L))
    }
}
