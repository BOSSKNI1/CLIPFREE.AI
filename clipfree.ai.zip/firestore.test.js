const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_creator_123";
const BOB_UID = "bob_creator_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function sampleUserProfile(uid, ts) {
  return {
    uid,
    displayName: "Alice Creator",
    email: "alice@example.com",
    preferredLanguage: "English",
    defaultResolution: "1080p",
    defaultAspectRatio: "9:16",
    autosaveEnabled: true,
    createdAt: ts,
    updatedAt: ts,
  };
}

function sampleProject(uid, ts) {
  return {
    userId: uid,
    localProjectId: 1,
    title: "Podcast Episode 42",
    sourceDisplayName: "podcast_ep42.mp4",
    durationMs: 185000,
    width: 1920,
    height: 1080,
    rotationDegrees: 0,
    hasAudio: true,
    fileSizeBytes: 52428800,
    aspectRatio: "9:16",
    targetPlatform: "youtube_shorts",
    durationPreset: "30-45s",
    captionStyleId: "bold_creator",
    status: "READY",
    summaryText: "Highlights from episode 42 covering AI workflows.",
    chapters: ["00:00 Intro", "01:15 Core Hook"],
    activeProviderUsed: "Firebase AI Logic (Gemini)",
    clientCreatedAtMs: 1730000000000,
    clientUpdatedAtMs: 1730000005000,
    createdAt: ts,
    updatedAt: ts,
  };
}

function sampleClip(uid, projectId, ts) {
  return {
    userId: uid,
    projectId,
    title: "Strongest Opening Hook",
    startMs: 12000,
    endMs: 47000,
    viralityScore: 91,
    scoreExplanation: "High clarity and immediate curiosity hook.",
    openingHook: "Most creators miss this one timeline setting.",
    reasonForSelection: "Strong opening hook",
    description: "Explains timeline pacing.",
    suggestedCaption: "Watch how pacing doubles retention.",
    hashtags: ["#shorts", "#creator", "#editing"],
    language: "English",
    speakerLabel: "Speaker 1",
    aspectRatio: "9:16",
    captionStyleId: "bold_creator",
    trimStartMs: 12000,
    trimEndMs: 47000,
    aiGenerated: true,
    exportStatus: "DRAFT",
    clientCreatedAtMs: 1730000000000,
    clientUpdatedAtMs: 1730000005000,
    createdAt: ts,
    updatedAt: ts,
  };
}

test("Unauthenticated user: cannot read or write any user profile or subcollections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const ts = new Date(Date.now() - 1000);

  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).set(sampleUserProfile(ALICE_UID, ts))
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("projects").get()
  );
});

test("User profile: owner can create and partially update; cross-user and ghost fields fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = new Date(Date.now() - 5000);

  // Create without @DocumentId "id" key
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(sampleUserProfile(ALICE_UID, ts))
  );

  // Partial update preserves uid and createdAt
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      preferredLanguage: "Spanish",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject ghost field on create (Shadow Update test)
  await assertFails(
    bobDb.collection("users").doc(BOB_UID).set({
      ...sampleUserProfile(BOB_UID, ts),
      isAdmin: true,
    })
  );

  // Reject future timestamp spoofing
  await assertFails(
    bobDb.collection("users").doc(BOB_UID).set(
      sampleUserProfile(BOB_UID, new Date(Date.now() + 60000))
    )
  );

  // Reject immutable createdAt modification
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject cross-user PII read/write
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      displayName: "Hijacked",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject listing root /users collection
  await assertFails(aliceDb.collection("users").get());
});

test("Projects and Clips: valid Kotlin payloads, parent existence check, updates, and queries succeed", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = new Date(Date.now() - 10000);

  // Orphan clip creation without parent project must fail
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .collection("clips")
      .doc("clip_1")
      .set(sampleClip(ALICE_UID, "proj_1", ts))
  );

  // Create project
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .set(sampleProject(ALICE_UID, ts))
  );

  // Create child clip now that parent project exists
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .collection("clips")
      .doc("clip_1")
      .set(sampleClip(ALICE_UID, "proj_1", ts))
  );

  // Partial update on project
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .update({
        title: "Podcast Episode 42 (Edited)",
        clientUpdatedAtMs: 1730000010000,
        updatedAt: new Date(Date.now() - 1000),
      })
  );

  // Partial update on clip
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .collection("clips")
      .doc("clip_1")
      .update({
        trimStartMs: 14000,
        trimEndMs: 45000,
        exportStatus: "COMPLETED",
        clientUpdatedAtMs: 1730000010000,
        updatedAt: new Date(Date.now() - 1000),
      })
  );

  // Invalid viralityScore > 100 fails
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .collection("clips")
      .doc("clip_1")
      .update({
        viralityScore: 150,
        updatedAt: new Date(Date.now() - 1000),
      })
  );

  // Owner list queries succeed (even on empty subcollection for another user)
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").get()
  );
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .collection("clips")
      .get()
  );
  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).collection("projects").get()
  );

  // Cross-user access fails
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("projects").get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .collection("clips")
      .get()
  );
});

test("BrandKits and Templates: valid create, update, delete, and cross-user isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = new Date(Date.now() - 8000);

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("brandKits")
      .doc("kit_1")
      .set({
        userId: ALICE_UID,
        name: "Studio Purple",
        primaryColorHex: "#7652E8",
        secondaryColorHex: "#B9A6F6",
        fontName: "Space Grotesk",
        captionStyleId: "bold_creator",
        introText: "",
        outroText: "Follow for more!",
        ctaText: "Subscribe",
        watermarkEnabled: true,
        watermarkText: "@alice",
        defaultKit: true,
        clientCreatedAtMs: 1730000000000,
        createdAt: ts,
        updatedAt: ts,
      })
  );

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("templates")
      .doc("tpl_1")
      .set({
        userId: ALICE_UID,
        name: "My Podcast Template",
        category: "Podcasts",
        captionStyleId: "speaker_colored",
        fontName: "Space Grotesk",
        primaryColorHex: "#7652E8",
        accentColorHex: "#9878FF",
        aspectRatio: "9:16",
        autoZoomEnabled: true,
        introText: "Podcast Highlight",
        outroText: "",
        createdAt: ts,
        updatedAt: ts,
      })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("brandKits").get()
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("templates").get()
  );

  // Cross-user delete fails
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("brandKits")
      .doc("kit_1")
      .delete()
  );

  // Owner delete succeeds
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("brandKits")
      .doc("kit_1")
      .delete()
  );
});
